<?php

$MYSQL_HOST="192.168.65.230";
$MYSQL_LOGIN="root";
$MYSQL_PASSWORD="foxlink";
$mysqli1 = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"swipecard");
$mysqli1->query("SET NAMES 'utf8'");	 
$mysqli1->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli1->query('SET CHARACTER_SET_RESULTS=utf8');
$sql = "Select id,name,costID,depName,Direct,overTimeDate,WorkContent,overtimeHours,overtimeType,overtimeInterval,rid from `notes_overtime_state` where notesStates = 0";

$rows = $mysqli1->query($sql);
// $dev_map_array = array();
$temp_array=array();
// id	name		costID  	depName	Direct				overTimeDate	WorkContent	overtimeHours	overtimeType	overtimeInterval	application_person	application_id	application_dep	application_tel	notesStates
$i=0;
//獲取notesStates為0的數據，準備拋轉到table_new
if(mysqli_num_rows($rows)>0){
	while($row = $rows->fetch_row())
	{
		$temp_array[$i]['sort'] = $row[5]."_".$row[2]."_".$row[8];
		$temp_array[$i]['id']= $row[0];
		$temp_array[$i]['name'] = $row[1];
		$temp_array[$i]['costID'] = $row[2];
		$temp_array[$i]['depName'] = $row[3];
		$temp_array[$i]['Direct'] = $row[4];
		$temp_array[$i]['overTimeDate'] = $row[5];
		$temp_array[$i]['WorkContent'] = $row[6];
		$temp_array[$i]['overtimeHours'] = $row[7];
		$temp_array[$i]['overtimeType'] = $row[8];
		$temp_array[$i]['overtimeInterval'] = $row[9];
		$temp_array[$i]['rid'] = $row[10];
		$i++;
	}
	mysqli_free_result($rows);

	$con = count($temp_array);
	//拆分字段
	for($i=0;$i<$con;$i++){
		$val = $temp_array[$i]['overtimeInterval'];
		$temp = explode('-',$val);
		$temp_array[$i]['overtimeStart'] = $temp[0];
		$temp_array[$i]['overtimeEnd'] = $temp[1];
		unset($temp);
	}

	// var_dump($temp_array);
	$t = $temp_array;

	//進行二維排序 以temp_array[$i]['sort']為基準
	for($i=0;$i<$con;$i++){
		$tempa[] = $t[$i]['sort'];
	}

	array_multisort($tempa, SORT_ASC, $t);
	$application_person="鄢小翠";
	$application_id	="432879";
	$application_dep = "6251";
	$application_tel ="33542";


	// print_r($temp_array['sort']);
	// print_r($t); 
	for($i=0;$i<$con;$i++){
		$sql1 = "insert into notes_overtime_state_new (rid,group_sort,id,name,costID,depName,Direct,overTimeDate,overtimeHours,overtimeType,overtimeStart,overtimeEnd,application_person	,application_id	,application_dep,application_tel,WorkContent) values (".$t[$i]['rid'].", '".$t[$i]['sort']."','".$t[$i]['id']."','".$t[$i]['name']."','".$t[$i]['costID']."','".$t[$i]['depName']."','".$t[$i]['Direct']."','".$t[$i]['overTimeDate']."','".$t[$i]['overtimeHours']."','".$t[$i]['overtimeType']."','".$t[$i]['overtimeStart']."','".$t[$i]['overtimeEnd']."','".$application_person."',".$application_id.",".$application_dep.",".$application_tel.", '".$t[$i]['WorkContent']."')";
		// echo $sql1."<br>";
		$rows = $mysqli1->query($sql1);
	}
	
}


?>
 <script type="text/javascript">setTimeout("window.opener = null;window.open('','_self');window.close();",2000)</script>