package com.yihaomen.test;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
public class Qualification extends Frame {
    JLabel lb1 = new JLabel("您的学历为：");
    CheckboxGroup cg = new CheckboxGroup();
    JCheckBox r1 = new JCheckBox("专科", false);
    JCheckBox r2 = new JCheckBox("本科", false);
    JCheckBox r3 = new JCheckBox("硕士", false);
    JCheckBox r4 = new JCheckBox("博士", true);
    
    JLabel lb2 = new JLabel("您精通的语言为：");
    JCheckBox t1 = new JCheckBox("Visual Basic");
    JCheckBox t2 = new JCheckBox("Visual C++");
    JCheckBox t3 = new JCheckBox("Java");
    public Qualification(String s) {
        super(s);
        setLayout(new GridLayout(10, 1));
        add(lb1);
        add(r1);
        
        add(r2);
        add(r3);
        add(r4);
        add(lb2);
        
        add(t1);
        add(t2);
        add(t3);
        
        t1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				boolean tt = t1.isSelected();
				System.out.println("狀態： "+tt);
			}
		});
    }
    
    
    public static void main(String args[]) {
        Qualification q = new Qualification("学识！");
        q.setSize(400, 250);
        q.setLocation(200, 300);
        q.setVisible(true);
    }
    
   
}