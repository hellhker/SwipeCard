package com.yihaomen.test;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.io.Reader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.yihaomen.mybatis.model.User;


/**
 * 用於向線長展示昨天線別人員刷卡情況
 * @author 132911
 *
 */
public class JLableC extends JFrame {
	private static final long serialVersionUID = -4892684184268025880L;
	private static final Timer time = new Timer("test");
	private Vector<Vector<Object>> rowData = new Vector<Vector<Object>>();
	private JTable table;
	private int count = 0;

	static JTabbedPane tabbedPane;
	static JLabel label1, label3;
	static JLabel labelS1, labelS2, labelS3;
	static JPanel panel1, panel2, panel3;
	static ImageIcon image;
	static JLabel labelT2_1, labelT2_2, labelT1_2, labelT2_3, labelT1_3,
			labelT1_4, labelT1_5, labelT1_6, labelT1_1;
	static JComboBox comboBox;
	static MyJButton butT1_1, butT1_2, butT1_3, butT1_4, butT1_5, butT1_6,
			butT2_1, butT2_2, butT2_3, butT1_7;
	static JTextArea jtextT1_1, jtextT1_2;
	static TextField textT2_1, textT1_2, textT2_2, textT1_3, textT1_4,
			textT1_5, textT1_1, textT1_7;
	static JTextField jtf;
	static JScrollPane jspT1_1, jspT2_2, JspTable;
	final Object[] str1 = getItems();

	Textc textc = null;
	String LineNo = "";

	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;
	static {
		try {
			reader = Resources.getResourceAsReader("Configuration.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SqlSessionFactory getSession() {
		return sqlSessionFactory;
	}

	public JLableC(String WorkshopNo,String LineNo) {
//		public JLableC() {

		super("產線端刷卡程式");
		setBounds(350, 130, 900, 600);
		setResizable(false);

		Container c = getContentPane();
		// JTabbedPane jp = new JTabbedPane(JTabbedPane.LEFT);
		tabbedPane = new JTabbedPane(JTabbedPane.LEFT); // 创建选项卡面板对象
		// 创建标签
		labelS1= new JLabel("指示單號");
		labelS2= new JLabel("料號");
		labelS3= new JLabel("標準人數");
		// label3 = new JLabel("第三个标签的面板", SwingConstants.CENTER);
		// 创建面板
		panel1 = new JPanel();
		panel1.setLayout(null);
		// panel1.setSize(800, 600);
		// int a = panel1.getHeight();
		// int b = panel1.getWidth();
		// System.out.println("Height: " + a+"   " + "Width: " + b);
		panel2 = new JPanel();
		panel2.setLayout(null);
		panel3 = new JPanel();

		labelT2_1 = new JLabel("指示單號：");//指示單號
		labelT2_1.setFont(new Font("微软雅黑", Font.BOLD, 13));

//		comboBox = new JComboBox(getItems());0313199858
		
		comboBox = new JComboBox(str1);
		
		
		
		comboBox.setEditable(true);
		
		comboBox.setFont(new Font("微软雅黑", Font.PLAIN, 13));
		jtf = (JTextField) comboBox.getEditor().getEditorComponent();
//		jtf.setEnabled(false);

		textT1_1 = new TextField(15);//車間
		textT1_2 = new TextField(15);//線別
		textT1_3 = new TextField(15);//上班
		textT1_4 = new TextField(15);//下班
		textT1_5 = new TextField(15);//實際人數
		textT1_7 = new TextField(15);//換線上班
		
		
		jtextT1_1 = new JTextArea();//刷卡人員信息
		jtextT1_2 = new JTextArea();//備註

		textT2_1 = new TextField(15);//"料號"
		textT2_2 = new TextField(15);//"標準人數"
		
		

		// text3 = new JTextArea(2, 20);
		
		labelT1_1 = new JLabel("車間");
		labelT1_2 = new JLabel("線別：");
		labelT1_3 = new JLabel("上班：");
		labelT1_4 = new JLabel("下班：");
		labelT1_5 = new JLabel("實際人數：");
		labelT1_6 = new JLabel("備註：");
		
		labelT2_2 = new JLabel("料號：");
		labelT2_3 = new JLabel("標準人數：");
		
		
		
		
		//未補充指示單號人員信息
		Vector<String> columnNames = new Vector<String>();
//		columnNames.add("统计项");
		columnNames.add("工號");
		columnNames.add("姓名");
		columnNames.add("刷卡時間1");
		columnNames.add("刷卡時間2");
		columnNames.add("指示單號");
//		columnNames.add("確認");
		table = new JTable(new DefaultTableModel(rowData, columnNames));
		JspTable = new JScrollPane(table);
		JspTable.setBounds(40,40,700,400);

		int x1 = 40, x2 = 120, x3 = 200, x4 = 340, x5 = 100, x6 = 400, x7 = 80;
		int y1 = 40, y2 = 30, y3 = 40, y4 = 120, y5 = 150;

		labelT2_1.setBounds(x1, 3 * y1, x7, y2);
		comboBox.setBounds(x1 + x7, 3 * y3, x6 / 2, y2);//指示單號
		// text1.setBounds(x, y, width, height) x,y,寬 高
		labelT2_2.setBounds(x1, 1 * y3, x7, y2);
		
		labelT1_1.setBounds(x1, y1, x7, y2);
		labelT1_2.setBounds(x1, 2 * y3, x7, y2);
		labelT1_3.setBounds(x1, 3 * y3, x7, y2);
		labelT1_4.setBounds(x1, 4*y3, x7, y2);
		
		labelT1_5.setBounds(x1, 8 * y3, x7, y2);
		labelT1_6.setBounds(x1, 9 * y3, x7, y2);
		
		labelT2_3.setBounds(x1, 2 * y3, x7, y2);
		
		textT1_1.setBounds(x1 + x7, 1 * y3, y4, y2);
		textT1_2.setBounds(x1 + x7, 2 * y3, y4, y2);
		textT1_3.setBounds(x1 + x7, 3 * y3, y4, y2);
		textT1_7.setBounds(x1 + x7, 3 * y3, y4, y2);
		
		textT1_4.setBounds(x1+x7, 4*y3, y4, y2);
		textT1_5.setBounds(x1 + x7, 8 * y3, y4, y2);
		jtextT1_2.setBounds(x1 + x7, 11 * y3, x4, y2);
		
		textT2_1.setBounds(x1 + x7, 1 * y3, y4, y2);
		textT2_2.setBounds(x1 + x7, 2 * y3, y4, y2);

		jspT1_1 = new JScrollPane(jtextT1_1);
		jspT1_1.setBounds(400, y3, x4, y5);

		jspT2_2 = new JScrollPane(jtextT1_2);
		jspT2_2.setBounds(x1, 10* y3, x3+x7, x5);
		int cc = 240;
		Color d = new Color(cc, cc, cc);// 这里可以设置颜色的rgb

		textT1_1.setEditable(false);
		textT1_2.setEditable(false);
		textT1_3.setEditable(false);
		textT1_4.setEditable(false);
		textT1_5.setEditable(false);
		textT1_7.setEditable(false);
		
		jtextT1_1.setEditable(false);
		jtextT1_2.setEditable(false);
		
		textT2_1.setEditable(false);
		textT2_2.setEditable(false);

		jtextT1_1.setLineWrap(true);
		jtextT1_2.setLineWrap(true);

		textT1_3.setBackground(Color.GRAY);
		textT1_4.setBackground(Color.GRAY);
		jtextT1_2.setBackground(d);
		
		butT1_1 = new MyJButton(" 上班刷卡模式 ", 2);
		butT1_2 = new MyJButton(" 下班刷卡模式 ", 2);
		
		butT1_3 = new MyJButton(" 加班刷卡模式 ", 2);
		butT1_4 = new MyJButton("提交加班單", 2);
		
		butT1_5 = new MyJButton("登出(切換帳號)",2);
		butT1_6 = new MyJButton(" 退出程式", 2);
		butT1_7 = new MyJButton("換線上班刷卡",2);
		
		butT2_1 = new MyJButton(" 換料 ", 2);
		butT2_2 = new MyJButton("確認提交", 2);
		butT2_3 = new MyJButton("測試綁定", 2);

		butT1_1.setBounds(x6, 260, x5, y2);
		butT1_2.setBounds(x6 + 110, 260, x5, y2);
		butT1_7.setBounds(x6 + 220, 260, x5, y2);
		
		butT1_3.setBounds(x1, 13*y3, x5, y2);
		butT1_4.setBounds(x1+x2, 13*y3, x5, y2);
		
		butT1_5.setBounds(x6, 260+y2+10, x5, y2);
		butT1_6.setBounds(x6 + 110, 300, x5, y2);
		butT2_1.setBounds(x4, 400, x5, y2);
		butT2_2.setBounds(x3+20, 4*y3, x5, y2);
		butT2_3.setBounds(x6 + 110, 12*y3, x5, y2);

//		butT1_1.addActionListener(textc);
//		butT1_2.addActionListener(textc);
//		butT1_1.setActionCommand("上班刷卡模式");
//		butT1_2.setActionCommand("下班刷卡模式");
		
		panel1.add(JspTable);
		
		time.schedule(new TimerTask() {;
			@Override
			public void run() {
				update();
			}
		}, 0, 1000*10*60);
		
		panel1.setBackground(Color.WHITE);
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(Color.lightGray);
		// 将标签面板加入到选项卡面板对象上
		tabbedPane.addTab("刷卡詳情", null, panel1, "First panel");

		update();
		comboBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO 
				
				if(e.getStateChange()==ItemEvent.SELECTED){
					// System.out.println("-----------e.getItem():"+e.getStateChange()+"-------------");
					String RC_NO = jtf.getText();
					SqlSession session = sqlSessionFactory.openSession();
					try {
						User eif = (User) session.selectOne(
								"selectUserByRCNo", RC_NO);
						textT2_1.setText(eif.getPRIMARY_ITEM_NO());
						textT2_2.setText(eif.getSTD_MAN_POWER());
					} finally {
						if(session != null){  
			                session.close();  
			            }  
					}
				}
			}
		});
		
		// TODO 工单号
		jtf.addKeyListener(new KeyListener() {
			
			public void keyTyped(KeyEvent e) {
			}

			public void keyReleased(KeyEvent e) {
				System.out.println("jtfListen->");
				String key = jtf.getText();
				comboBox.removeAllItems();
//				for (Object item : getItems()) {
					for (Object item : str1) {
						// 这里是以key開頭的项目都筛选出来0313240578

						// 可以把contains改成startsWith就是筛选以key开头的项目
						// contains(key)/startsWith(key)
						if (((String) item).startsWith(key)) {
							comboBox.addItem(item);
						}
					}
					jtf.setText(key);
			}

			public void keyPressed(KeyEvent e) {}
		});
		
		

		butT1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});

		butT1_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int cc = 240;
				Color d = new Color(cc, cc, cc);// 这里可以设置颜色的rgb
				// 進入批量刷卡下班模式
				textT1_3.setEditable(false);
				textT1_4.setEditable(true);
				textT1_5.setEditable(false);
				jtextT1_2.setEditable(false);
				textT1_3.setBackground(Color.GRAY);
				textT1_4.setBackground(Color.WHITE);
				textT1_5.setBackground(d);
				jtextT1_2.setBackground(d);
			}
		});

		butT1_3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {// TODO 彈出新窗口
				textT1_3.setEditable(false);
				textT1_4.setEditable(false);
				textT1_5.setEditable(true);
				jtextT1_2.setEditable(true);
				textT1_5.setBackground(Color.WHITE);
				jtextT1_2.setBackground(Color.WHITE);
				textT1_3.setBackground(Color.GRAY);
				textT1_4.setBackground(Color.GRAY);

			}
		});

		butT1_4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// 中途刷卡原因
				int cc = 240;
				Color d = new Color(cc, cc, cc);// 这里可以设置颜色的rgb
				jtf.setEditable(false);
				textT1_3.setEditable(false);
				textT1_4.setEditable(false);
				textT1_5.setEditable(false);
				jtextT1_2.setEditable(false);
				textT1_3.setBackground(Color.GRAY);
				textT1_4.setBackground(Color.GRAY);
				textT1_5.setBackground(d);
				jtextT1_2.setBackground(d);
				// TODO Auto-generated method stub
				addUser();
			}
		});
		
		butT1_5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				InitGlobalFont(new Font("微软雅黑", Font.BOLD, 13));
				dispose();
				Login d = new Login();
			}
		});

		butT1_6.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO
				System.exit(0);
			}
		});
		
		butT1_7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				int cc = 240;
				Color d = new Color(cc, cc, cc);// 这里可以设置颜色的rgb

				
//				　panel1.remove(textT1_3);
//				　　panel1.add(text);
			
//				　　panel1.repaint();
				// 1、進入批量刷卡上班模式2、做一個判斷
//				textT1_3.setVisible(false);
				textT1_4.setEditable(false);
				textT1_5.setEditable(false);
				textT1_7.setEditable(true);
				jtextT1_2.setEditable(false);
				textT1_3.setBackground(Color.WHITE);
				textT1_4.setBackground(Color.GRAY);
				textT1_7.setBackground(Color.WHITE);
				panel1.remove(textT1_3);
				panel1.updateUI();	
				panel1.repaint();
				
			}
		});
		
		butT2_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// 中途刷卡原因
				jtf.setEditable(true);
			}
		});

		

		butT2_2.addActionListener(new ActionListener() {
			//TODO
			public void actionPerformed(ActionEvent e) {
				SqlSession session = sqlSessionFactory.openSession();
				try{
					User user1 = new User();
					System.out.println("jtf: " + jtf.getText()+"\t"+"PRIMARY_ITEM_NO:" + textT2_1.getText());
					user1.setRC_NO(jtf.getText());
					user1.setPRIMARY_ITEM_NO(textT2_1.getText());
					user1.setPROD_LINE_CODE(textT1_2.getText());
					session.update("UpdateRC_NOByLineNO",user1);
					session.commit();
				}finally{
					if(session != null){  
		                session.close();  
		            }  
				}
				
			}
		});
		
		butT2_3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				String a = checkFill();
//				System.out.println(a);
				update();
				
			}
		});
		
		// TODO 上班刷卡模式
		textT1_3.addTextListener(new TextListener() {

			@Override
			public void textValueChanged(TextEvent e) {
				SqlSession session = sqlSessionFactory.openSession();

				String CardID = textT1_3.getText();

				// text1.setText("");
				String pattern = "^[0-9]\\d{9}$";
				Pattern r = Pattern.compile(pattern, Pattern.DOTALL);
				Matcher m = r.matcher(CardID);

				String time = DateGet.getTime();
				String WorkshopNo = textT1_1.getText();
				String PROD_LINE_CODE = textT1_2.getText();
				// 驗證是否為10位整數，是則繼續執行，否則提示
				// System.out.println(m.matches());
				if (m.matches() == true) {
					// String[] a = CardID.split("\\s+");
					
					// Arrays.sort(a);
					// for (int i = 0; i < a.length; i++) {
					// text2.append("CardID2: " + a[i] + "\n");
					// }

					try {
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("CardID", CardID);
						param.put("PROD_LINE_CODE", PROD_LINE_CODE);
						param.put("WorkshopNo", WorkshopNo);
						System.out.println("CardID1: " + CardID + " LineNo: "
								+ PROD_LINE_CODE+"WorkshopNo: "+WorkshopNo);
						User rows = (User) session
								.selectOne("selectCountAByCardID",
										param);
						System.out.println("param: " + param);
						// 通過卡號查詢員工個人信息
						// 1、判斷是否今天第一次刷卡
//						System.out.println("getRowsa: " + rows.getRowsa());
						User havUser = (User) session
						.selectOne("selectUserByCardID",
								CardID);
						
						if(havUser==null){
							String swipeDate = DateGet.getDate();
							User selEmp = new User();
							selEmp.setCardID(CardID);
							selEmp.setSwipeDate(swipeDate);
							User rows1 = (User) session.selectOne("selectLoseEmployee",selEmp);
							int loseCount = rows1.getLostCon();
							if(loseCount>0){
								JOptionPane.showMessageDialog(null, "已記錄當前異常刷卡人員，今天不用再次刷卡！");
								textT1_3.setText("");
								return;
								
							}
							JOptionPane.showMessageDialog(null, "當前刷卡人員不存在；可能是新進人員，或是舊卡丟失補辦，人員資料暫時未更新，請線長記錄，協助助理走原有簽核流程！");
							String[] inputIDName=null; 
							String inputID = null;
							String inputName = null;
							inputIDName = showIDDialog();
							if(inputIDName!=null){
								inputID = inputIDName[0];
								inputName = inputIDName[1];
								System.out.println("ID1："+inputID);
								System.out.println("Name1："+inputName);
								User user1 = new User();
								user1.setCardID(CardID);
								user1.setName(inputName);
								user1.setId(inputID);
								
								//user1.setSwipeCardTime(swipeCardTime);
								user1.setSwipeDate(swipeDate);
								user1.setPROD_LINE_CODE(PROD_LINE_CODE);
								user1.setWorkshopNo(WorkshopNo);
								session.insert(
										"insertUserByNoCard",
										user1);
								session.commit();
							}
							
							/**
							String inputID = JOptionPane.showInputDialog("Please input a id");
							System.out.println("ID："+inputID.length());
							
							if(inputID.isEmpty()){
								JOptionPane.showMessageDialog(null, "請輸入員工工號");
							}
							
							if(inputID!=null){
								String inputName = JOptionPane.showInputDialog("Please input a name");
								if(inputName==""){
									JOptionPane.showMessageDialog(null, "請輸入員工姓名");
								}
								if(inputName!=null){
									System.out.println("ID："+inputID);
									System.out.println("姓名："+inputName);
									User user1 = new User();
									user1.setCardID(CardID);
									user1.setName(inputName);
									user1.setId(inputID);
									
									//user1.setSwipeCardTime(swipeCardTime);
									user1.setSwipeDate(swipeDate);
									user1.setPROD_LINE_CODE(PROD_LINE_CODE);
									user1.setWorkshopNo(WorkshopNo);
									session.insert(
											"insertUserByNoCard",
											user1);
									session.commit();
								}
								
							}
							*/
							//改寫sql語句，一天只會執行一次，是不是應該先檢測一下
							//JOptionPane.showMessageDialog(null, "當前刷卡人員不存在；可能是新進人員，或是舊卡丟失補辦，人員資料暫時未更新，請線長記錄，走原有簽核流程！");
						}else if (rows.getRowsa() == 0) {
							// /**
							// text2.append();
							User eif = (User) session
									.selectOne(
											"selectUserByCardID",
											CardID);
							// String cardid = eif.getCardID();
						
							String name = eif.getName();
							String RC_NO = jtf.getText();
							
							String PRIMARY_ITEM_NO = textT2_1.getText();

							jtextT1_1.setText("第一次刷卡\n" + "ID: " + eif.getId()
									+ "\nName: " + eif.getName() + "\n刷卡時間： "
									+ time + "\n" + "員工上班刷卡成功！\n------------\n");
							User user1 = new User();
							user1.setCardID(CardID);
							user1.setName(name);
							String swipeCardTime = time;
							user1.setSwipeCardTime(swipeCardTime);
							user1.setRC_NO(RC_NO);
							user1.setPRIMARY_ITEM_NO(PRIMARY_ITEM_NO);
							user1.setPROD_LINE_CODE(PROD_LINE_CODE);
							user1.setWorkshopNo(WorkshopNo);
							session.insert(
									"insertUserByOnDuty",
									user1);
							session.commit();
							// System.out.println("HH!");
							// text2.append("員工上班刷卡成功！\n------------\n");
							// */
							// System.out.println("呵呵");
						} else if (rows.getRowsa() > 0) {
							User eif = (User) session
									.selectOne(
											"selectUserByCardID",
											CardID);
							System.out.println("row.getRowsA: "
									+ rows.getRowsa());
							jtextT1_1.append("Name: " + eif.getName() + "\n"
									+ "第二次刷卡了！\n\n");
						}
					} finally {
						if(session != null){  
			                session.close();  
			            }  
					}
					textT1_3.setText("");
				} else {
					System.out.println("無輸入內容或輸入錯誤!");
				}
				// text2.setText("");
				// if(rows.getRowsa)
				// System.out.println("This is methodA!");

			}
		});

		// TODO 下班刷卡模式
		textT1_4.addTextListener(new TextListener() {

			@Override
			public void textValueChanged(TextEvent e) {
				SqlSession session = sqlSessionFactory.openSession();
				String CardID = textT1_4.getText();

				// 驗證是否為10位整數，是則繼續執行，否則提示
				String pattern = "^[0-9]\\d{9}$";
				Pattern r = Pattern.compile(pattern, Pattern.DOTALL);
				Matcher m = r.matcher(CardID);
				String time = DateGet.getTime();
				String WorkshopNo = textT1_1.getText();
				String PROD_LINE_CODE = textT1_2.getText();
				// System.out.println(m.matches());
				if (m.matches() == true) {
					System.out.println("CardID: " + CardID);
					try {
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("CardID", CardID);
						param.put("PROD_LINE_CODE", PROD_LINE_CODE);
						param.put("WorkshopNo", WorkshopNo);
						User rows = (User) session.selectOne("selectCountBByCardID",param);
//						User rows = (User) session
//						.selectOne(
//								"com.yihaomen.mybatis.models.UserMapper.selectCountBByCardID",
//								param);
						// 通過卡號查詢員工個人信息
						// 1、判斷是否今天第一次刷卡
						if (rows.getRowsb() == 0) {
							// /**
							// text2.append();
							System.out.println("row.getRowsB: "
									+ rows.getRowsb());
							User eif = (User) session
									.selectOne(
											"selectUserByCardID",
											CardID);
							String name = eif.getName();
							if(jtf!=null){
								String RC_NO = jtf.getText();//TODO
							}
							String RC_NO = jtf.getText();
							String PRIMARY_ITEM_NO = textT2_1.getText();
							jtextT1_1.setText("第一次刷卡\n" + "ID: " + eif.getId()
									+ "\nName: " + eif.getName() + "\n刷卡時間： "
									+ time + "\n" + "員工下班刷卡成功！\n------------\n");
							User user1 = new User();
							String SwipeCardTime2 = time;
							user1.setSwipeCardTime2(SwipeCardTime2);
							user1.setCardID(CardID);
//							user1.setReason("下班");
//							 System.out.println("user1: "+user1);
							session.update("updateUserByOffDuty", user1);
							session.commit();
							// System.out.println("HH!");
							// text2.append("員工上班刷卡成功！\n------------\n");
							// */frog man`````````
							// System.out.println("呵呵");

						} else if (rows.getRowsb() > 0) {
							User eif = (User) session
									.selectOne(
											"selectUserByCardID",
											CardID);
							System.out.println("row.getRowsB: "
									+ rows.getRowsb());
							jtextT1_1.append("Name: " + eif.getName() + "\n"
									+ "第二次刷卡了！\n\n");
						}
					} finally {
						if(session != null){  
			                session.close();  
			            }  
					}
					textT1_4.setText("");
				} else {
					System.out.println("無輸入內容或輸入錯誤!");
				}
				// System.out.println("This is methodA!"); 
			}
		});

		textT1_7.addTextListener(new TextListener() {

			@Override
			public void textValueChanged(TextEvent e) {
				SqlSession session = sqlSessionFactory.openSession();
				String CardID = textT1_7.getText();
				// text1.setText("");
				String pattern = "^[0-9]\\d{9}$";
				Pattern r = Pattern.compile(pattern, Pattern.DOTALL);
				Matcher m = r.matcher(CardID);

				String time = DateGet.getTime();
				String WorkshopNo = textT1_1.getText();
				String PROD_LINE_CODE = textT1_2.getText();
				// 驗證是否為10位整數，是則繼續執行，否則提示
				// System.out.println(m.matches());
				if (m.matches() == true) {
					// String[] a = CardID.split("\\s+");
					
					// Arrays.sort(a);
					// for (int i = 0; i < a.length; i++) {
					// text2.append("CardID2: " + a[i] + "\n");
					// }

					try {
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("CardID", CardID);
						param.put("PROD_LINE_CODE", PROD_LINE_CODE);
						param.put("WorkshopNo", WorkshopNo);
						System.out.println("CardID1: " + CardID + " LineNo: "
								+ PROD_LINE_CODE+"WorkshopNo: "+WorkshopNo);
						User rows = (User) session.selectOne("selectCountAByCardID",param);
						System.out.println("param: " + param);
						// 通過卡號查詢員工個人信息
						// 1、判斷是否今天第一次刷卡
//						System.out.println("getRowsa: " + rows.getRowsa());
						if(rows.getRowsa()==0){
							User line = (User) session .selectOne("selectChangeLineByCardID",param);
							System.out.println("param: " + param);
							String preline = line.getPROD_LINE_CODE();
							// 通過卡號查詢員工個人信息
							if (preline!=null) {
								// /**
								// text2.append();
								User eif = (User) session
										.selectOne(
												"selectUserByCardID",
												CardID);
								// String cardid = eif.getCardID();
								jtextT1_1.setText("第一次刷卡\n" + "ID: " + eif.getId()
										+ "\nName: " + eif.getName() + "\n刷卡時間： "
										+ time + "\n" + "員工換線上班刷卡成功！\n------------\n");
								User user1 = new User();
								String name = eif.getName();
								user1.setCardID(CardID);
								String swipeCardTime2 = time;
								user1.setSwipeCardTime2(swipeCardTime2);
	//							user1.set("上班");
								user1.setPROD_LINE_CODE(preline);
								
								session.update(
										"updateChangeLineUserByOnDuty",
										user1);
								session.commit();
								User user2=new User();
								
								String RC_NO = jtf.getText();
								String PRIMARY_ITEM_NO = textT2_1.getText();
								String swipeCardTime = time;
								
								user2.setCardID(CardID);
								user2.setName(name);
								user2.setSwipeCardTime(swipeCardTime);
								user2.setRC_NO(RC_NO);
								user2.setPRIMARY_ITEM_NO(PRIMARY_ITEM_NO);
								user2.setPROD_LINE_CODE(PROD_LINE_CODE);
								user2.setWorkshopNo(WorkshopNo);
								session.insert("insertUserByOnDuty",user2);
								session.commit();
								// System.out.println("HH!");
								// text2.append("員工上班刷卡成功！\n------------\n");
								// */
								// System.out.println("呵呵");
							}
						} else if (rows.getRowsa() > 0) {
							User eif = (User) session
									.selectOne(
											"selectUserByCardID",
											CardID);
							System.out.println("row.getRowsA: "
									+ rows.getRowsa());
							jtextT1_1.append("Name: " + eif.getName() + "\n"
									+ "第二次刷卡了！\n\n");
						}
					} finally {
						if(session != null){  
			                session.close();  
			            }  
					}
					textT1_7.setText("");
				} else {
					System.out.println("無輸入內容或輸入錯誤!");
				}
				// text2.setText("");
				// if(rows.getRowsa)
				// System.out.println("This is methodA!");

			}
		});
		
		/**
		 * 
		 
		
		text9.addTextListener(new TextListener() {
			@Override
			public void textValueChanged(TextEvent e) {

				SqlSession session = sqlSessionFactory.openSession();

				String CardID = text9.getText();

				// text1.setText("");
				String pattern = "^[0-9]\\d{9}$";
				Pattern r = Pattern.compile(pattern, Pattern.DOTALL);
				Matcher m = r.matcher(CardID);

				String time = DateGet.getTime();
				String PROD_LINE_CODE = text2.getText();
				// 驗證是否為10位整數，是則繼續執行，否則提示
				// System.out.println(m.matches());
				if (m.matches() == true) {
					// String[] a = CardID.split("\\s+");
					// Arrays.sort(a);
					// for (int i = 0; i < a.length; i++) {
					// text2.append("CardID2: " + a[i] + "\n");
					// }

					try {
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("CardID", CardID);
						param.put("PROD_LINE_CODE", PROD_LINE_CODE);
						System.out.println("CardID1: " + CardID + " LineNo: "
								+ PROD_LINE_CODE);
						User rows = (User) session
								.selectOne(
										"com.yihaomen.mybatis.models.UserMapper.selectCountCByCardID",
										param);
						System.out.println("param: " + param);
						// 通過卡號查詢員工個人信息
						// 1、判斷是否今天第一次刷卡
						System.out.println("getRowsa: " + rows.getRowsc());
						if (rows.getRowsc() == 0) {
							// /**
							// text2.append();
							User eif = (User) session
									.selectOne(
											"com.yihaomen.mybatis.models.UserMapper.selectUserByCardID",
											CardID);
							// String cardid = eif.getCardID();
							String name = eif.getName();
							String RC_NO = jtf.getText();
							String PRIMARY_ITEM_NO = text1.getText();

							text6.setText("第一次刷卡\n" + "ID: " + eif.getId()
									+ "\nName: " + eif.getName() + "\n刷卡時間： "
									+ time + "\n" + "員工加班刷卡成功！\n------------\n");
							User user1 = new User();
							user1.setCardID(CardID);
							user1.setName(name);
							String swipeCardTime = time;
							user1.setSwipeCardTime(swipeCardTime);
							user1.setReason("加班");
							user1.setRC_NO(RC_NO);
							user1.setPRIMARY_ITEM_NO(PRIMARY_ITEM_NO);
							user1.setPROD_LINE_CODE(PROD_LINE_CODE);
							session.insert(
									"com.yihaomen.mybatis.models.UserMapper.insertUser",
									user1);
							session.commit();
							// System.out.println("HH!");
							// text2.append("員工上班刷卡成功！\n------------\n");
							// System.out.println("呵呵");
						} else if (rows.getRowsc() > 0) {
							User eif = (User) session
									.selectOne(
											"com.yihaomen.mybatis.models.UserMapper.selectUserByCardID",
											CardID);
							System.out.println("row.getRows: "
									+ rows.getRowsc());
							text6.append("Name: " + eif.getName() + "\n"
									+ "第二次刷卡了！\n\n");
						}
					} finally {
						session.close();
					}
					text9.setText("");
				} else {
					System.out.println("無輸入內容或輸入錯誤!");
				}
				// text2.setText("");
				// if(rows.getRowsa)
				// System.out.println("This is methodA!");

			}
		});
		*/

		c.add(tabbedPane);
		c.setBackground(Color.lightGray);
		
		
		textT1_1.setText(WorkshopNo);//綁定車間
		textT1_2.setText(LineNo);//綁定線別
		
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	/**
	 * TODO
	 * 
	 * @return 指示單號
	 */
	public static Object[] getItems() {
		List<User> user;
		SqlSession session = sqlSessionFactory.openSession();
		try {
			user = session.selectList("selectRCNo");
			System.out.println(user.size());
			int con = user.size();
			Object[] a = new Object[con];
			a[0] = "";
			for (int i = 0; i < con - 1; i++) {
				// System.out.println(user.get(i).getRC_NO());
				a[i + 1] = user.get(i).getRC_NO();
				// a.add(user.get(i).getRC_NO());
			}
			final Object[] s = a;
			return a;
		} finally {
			if (session != null) {
				session.close();
			}
			// System.out.println("123"); 小米手環2
		}
	}


	/**
	 * 員工刷入卡號判斷是否無記錄，並作出相應對策
	 */
	private String[] showIDDialog(){
		String[] aArray = new String[2];
		String inputID = JOptionPane.showInputDialog("Please input a id");
		String inputName = null;
		aArray[0]=inputID;
		
		if(inputID==null){
			
			return null;
		}else if(inputID.isEmpty()){
			showIDDialog();
		}else {
			inputName = showNameDialog();
			aArray[1]=inputName;
		}
		//return aArray;
		return aArray;
		
	}
	
	private  void breakShow(){
		return;
	}
	
	private String showNameDialog(){
		String inputName = JOptionPane.showInputDialog("Please input a Name");
		if(inputName==null){
			return null;
		}
		if(inputName.isEmpty()){
			showNameDialog();
		}
		return inputName;
	}
	
	
	public void update() {
		new SwingWorker<Object, Object>() { // TODO 待添加查詢條件-
			//String WorkshopNo = textT1_1.getText();
			String PROD_LINE_CODE = "3L-13";

			SqlSession session = sqlSessionFactory.openSession();

			List<User> eif = session.selectList(
					"selectUserByLastDay", PROD_LINE_CODE);

			protected Object doInBackground() throws Exception {
				rowData.clear();
				for (int i = 0; i < eif.size(); i++) {
					Vector<Object> info = new Vector<Object>();
					// info.add("测试");
					// info.add(dd);
					info.add(eif.get(i).getId());
					info.add(eif.get(i).getName());
					System.out.println(eif.get(i).getName());
					info.add(eif.get(i).getSwipeCardTime());
					info.add(eif.get(i).getSwipeCardTime2());
					info.add(eif.get(i).getRC_NO());
					// info.add(new Boolean(true));

					rowData.add(info);
				}
				count++;
				return null;
			}

			protected void done() {
				((DefaultTableModel) table.getModel()).fireTableDataChanged();
			}
		}.execute();

	}

	public String checkFill() {
		SqlSession session = sqlSessionFactory.openSession();
		String WorkshopNo = textT1_1.getText();
		String PROD_LINE_CODE = textT1_2.getText();
		User user1 = new User();
		user1.setWorkshopNo(WorkshopNo);
		user1.setPROD_LINE_CODE(PROD_LINE_CODE);
		User rows = (User) session.selectOne("checkFill", user1);
		session.commit();
		String message;
		if (rows.getFillRows() == 0) {
			// System.out.println("未綁定指示單號");
			JOptionPane.showMessageDialog(null, "請補充指示單號");
			message = "未綁定指示單號";
		} else {
			// System.out.println("已綁定指示單號");
			message = "綁定指示單號";
		}

		return message;

	}

	public void addUser() {// TODO
		SqlSession session = sqlSessionFactory.openSession();
		String WorkshopNo = textT1_1.getText();
		String PROD_LINE_CODE = textT1_2.getText();
		String ACTUAL_POWER = textT1_5.getText();
		String REMARK = jtextT1_2.getText();
		String RC_NO = jtf.getText();
		String PRIMARY_ITEM_NO = textT2_1.getText();
		String STD_MAN_POWER = textT2_2.getText();

		User user1 = new User();

		user1.setRC_NO(RC_NO);
		user1.setPRIMARY_ITEM_NO(PRIMARY_ITEM_NO);
		user1.setPROD_LINE_CODE(PROD_LINE_CODE);
		user1.setWorkshopNo(WorkshopNo);
		user1.setSTD_MAN_POWER(STD_MAN_POWER);
		user1.setACTUAL_POWER(ACTUAL_POWER);
		user1.setREMARK(REMARK);
		session.insert("com.yihaomen.mybatis.models.UserMapper.insertInfor",
				user1);
		session.commit();
	}

	// public void paint(Graphics g) {
	//
	// g.drawImage(image.getImage(), 0, 20, this);
	//
	// }

	protected void methodC() {
		textT2_1.setEditable(false);
		jtextT1_1.setEditable(false);
		textT2_1.setText("");
		textT1_2.setText("");
		jtextT1_1.setText("");
	}

	private static void InitGlobalFont(Font font) {
		FontUIResource fontRes = new FontUIResource(font);
		for (Enumeration<Object> keys = UIManager.getDefaults().keys(); keys
				.hasMoreElements();) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof FontUIResource) {
				UIManager.put(key, fontRes);
			}
		}
	}

	public static void main(String args[]) {
		// InitGlobalFont(new Font("alias", Font.PLAIN, 12));
		InitGlobalFont(new Font("微软雅黑", Font.BOLD, 13));
		String WorkShopNo = "第一車間";
		String LineNo = "1L-01";
		JLableC d = new JLableC(WorkShopNo, LineNo);
		// JLableC d = new JLableC();

	}

	public void setNameValue(String valueString) {
		// TODO Auto-generated method stub
		textT1_2.setText(valueString);
	}
}

class Texte implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("上班刷卡模式")) {// 多态的思想
			System.out.println("A");
		}

		if (e.getActionCommand().equals("下班刷卡模式")) {// 多态的思想
			System.out.println("B");
		}
	}
}
 