package com.yihaomen.test;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener;
import javax.swing.JButton; 
import javax.swing.JFrame;
import javax.swing.JPanel; 
import javax.swing.JTextField; 

public  class MyPanel extends JPanel implements ActionListener{
	/** * 定义面板的宽和高 */ 
	private int width=300; 
	private int height=300; 
	/** * 两组件 */ 
	private JButton button; 
	private JTextField textField; 
	/** * 构造方法 */ 
	public MyPanel(){ 
		this.setSize(width, height); 
		this.setLayout(null); 
		this.setVisible(true); 
		this.button=new JButton("点击我会变成一个文本框！");
		this.button.setBounds(60, 120, 180, 30); 
		this.button.addActionListener(this); 
		this.add(button); this.textField=new JTextField(); 
		this.textField.setBounds(60, 120, 180, 30);
		this.add(textField);
		this.textField.setVisible(false); 
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub if(e.getSource()==button){ this.textField.setVisible(true); this.button.setVisible(false); } } } public class AAA extends JFrame{ private MyPanel panel; public AAA(){ this.panel=new MyPanel(); this.add(panel); this.setSize(300, 300); this.setVisible(true); } public static void main(String[] args) { new AAA(); } } 看看是不是要的这种效果啊
	}
}
