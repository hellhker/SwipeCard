package com.yihaomen.test;

import java.util.ArrayList;

public class StudentDao {

	public ArrayList getAllStudent() {
		// TODO Auto-generated method stub
		return null;
	}

}
