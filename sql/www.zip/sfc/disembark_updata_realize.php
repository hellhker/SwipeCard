<?php
    
    $DepartmentCode=$_POST['DepartmentCode'];
    $ChineseName=$_POST['ChineseName'];
    $Name=$_POST['name'];
    $psw=$_POST['psw'];
    $UserID=$_POST['UserID'];
    $hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
    $mysqli = new mysqli($hostname,$username,$password,$database_name);
	$mysqli->query('SET NAMES utf8');	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');
    
    $sql="select modification_prove from user_data where UserID='$UserID' and Password='$psw' and ChineseName='$ChineseName'";
        $user_data=$mysqli->query($sql);
        $user_row=$user_data->fetch_row();
        $modification_prove=$user_row[0];
            
            if($modification_prove==1){
            
                echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
                echo "<SCRIPT Language=javascript type=\"text/javascript\">";
                echo "window.alert('已經修改過了喔!!')";
                echo "</SCRIPT>";
                echo "<script language=\"javascript\">";
                echo "location.href='disembark_updata.php?user=$UserID&password=$psw'";
                echo "</script>";
            }else{
                $sql_examine="SELECT name FROM `group_structure` WHERE `Depart_Code`='$DepartmentCode'";
                $name_data=$mysqli->query($sql_examine);
                $name=$name_data->fetch_row();
                if($name[0]==""){
                    echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
                    echo "<SCRIPT Language=javascript type=\"text/javascript\">";
                    echo "window.alert('沒有這個部門喔!!')";
                    echo "</SCRIPT>";
                    echo "<script language=\"javascript\">";
                    echo "location.href='disembark_updata.php?user=$UserID&password=$psw'";
                    echo "</script>";
                    exit;
                }
                $sql = "update user_data set DepartmentCode='$DepartmentCode' , modification_prove='1' where UserID='$UserID' and Password='$psw' and ChineseName='$ChineseName'";
    
                $mysqli->query($sql);
                echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
                echo "<SCRIPT Language=javascript type=\"text/javascript\">";
                echo "window.alert('修改成功!!')";
                echo "</SCRIPT>";
                echo "<script language=\"javascript\">";
                echo "location.href='disembark_updata.php?user=$UserID&password=$psw'";
                echo "</script>";
            }
    if($mysqli->query($sql)){
            
            $sql2="select modification_prove from user_data where UserID='$UserID' and Password='$psw' and ChineseName='$ChineseName'";
            $user_data=$mysqli->query($sql2);
            $user_num=$mysqli->num_rows($user_data);
            if($user_num >0){
                $user_row=$user_data->fetch_row();
                $modification_prove=$user_row[1];
            }
            if($modification_prove==1){
                echo $modification_prove;
                echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
                echo "<SCRIPT Language=javascript type=\"text/javascript\">";
                echo "window.alert('已經修改過了喔!!')";
                echo "</SCRIPT>";
                echo "<script language=\"javascript\">";
                echo "location.href='disembark_updata.php?user=$UserID&password=$psw'";
                echo "</script>";
            }else{
                
                $sql1 = "update user_data set modification_prove='1' where UserID='$UserID' and Password='$psw' and ChineseName='$ChineseName'";
                $mysqli->query($sql1);
                echo $modification_prove;
                echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
                echo "<SCRIPT Language=javascript type=\"text/javascript\">";
                echo "window.alert('修改成功!!')";
                echo "</SCRIPT>";
                echo "<script language=\"javascript\">";
                echo "location.href='disembark_updata.php?user=$UserID&password=$psw'";
                echo "</script>";
            }

    }
?>