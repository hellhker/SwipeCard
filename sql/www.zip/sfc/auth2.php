<?php
session_start();
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";

$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 

if((strcmp($_SESSION["ssn_usr"],"")!=0)&& (strcmp($_SESSION["ssn_psd"],"")!=0))
{
    $username = $_SESSION["ssn_usr"];
	$password = $_SESSION["ssn_psd"];
    
    $user_sql = "SELECT a.ID,a.UserID,a.ChineseName,a.EMail,a.DepartmentCode,b.name,a.Division,b.fac_code,a.GroupName FROM `user_data` a left join `group_structure` b on a.DepartmentCode=b.Depart_Code Where a.UserID='$username' And a.Password = '$password'";
	$user_rows = $mysqli->query($user_sql);
	$user_num = $user_rows->num_rows;
	if($user_num > 0)
    {
        $user_row = $user_rows->fetch_row();
		$groupname = $user_row[8];
        mysqli_free_result($user_rows);
        $mysqli->close();
    }
    else 
	{
        mysqli_free_result($user_rows);
        $mysqli->close();
        unset($_SESSION["ssn_usr"]);
        unset($_SESSION["ssn_psd"]);
        echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
        echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
        echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
        echo "</SCRIPT>";
?>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
        <script language="JavaScript">
        function show_window()
        {
        	var newtab = window.open("forget_pwd.php", 'SFC',config='height=200px,width=430px,scrollbars=no,resizable=no,status=no');
        	newtab.focus(); 
        }
        function show_window1()
        {
        	var newtab = window.open("register.php", 'SFC',config='height=500px,width=500px,scrollbars=no,resizable=yes,status=no');
        	newtab.focus(); 
        }
        </script>
        </head>
        <body>
        <form name="form1" method="POST" action="<?=$page?>">
        <p><font color="red" size="4" face="新細明體"><b>請輸入帳號密碼進行驗證</b></font></p>
        <p>
        帳號：<input name="username" type="text" maxlength="20" value="" size="15" /><br />
        密碼：<input name="password" type="password" maxlength="20" value="" size="16" />
        </p>
        <input class="darkbutton" type="submit" name="submit" value="登入" /><br /><br />
        <a onclick="show_window()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">忘記密碼？</a><BR>
<a onclick="show_window1()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">帳號申請</a>
        </form>
        </body>
        </html>
<?
        session_write_close();
        exit;
	}
}
else
{
    if(isset($_POST['submit']))
    {
        unset($_POST['submit']);
        $username = $_POST['username'];  
    	$password = $_POST['password'];
        
        $user_sql = "SELECT a.ID,a.UserID,a.ChineseName,a.EMail,a.DepartmentCode,b.name,a.Division,b.fac_code,a.GroupName FROM `user_data` a left join `group_structure` b on a.DepartmentCode=b.Depart_Code Where a.UserID='$username' And a.Password = '$password'";
    	$user_rows = $mysqli->query($user_sql);
    	$user_num = $user_rows->num_rows;
    	if($user_num > 0)
        {
            $user_row = $user_rows->fetch_row();
    		$groupname = $user_row[8];
            $_SESSION["ssn_usr"]= $username;
            $_SESSION["ssn_psd"]= $password;
            mysqli_free_result($user_rows);
            $mysqli->close();
        }
        else
        {
            mysqli_free_result($user_rows);
            $mysqli->close();
            unset($_SESSION["ssn_usr"]);
            unset($_SESSION["ssn_psd"]);
            echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
            echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
            echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
            echo "</SCRIPT>";
    ?>
            <html>
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
            <script language="JavaScript">
            function show_window()
            {
            	var newtab = window.open("forget_pwd.php", 'SFC',config='height=200px,width=430px,scrollbars=no,resizable=no,status=no');
            	newtab.focus(); 
            }
            function show_window1()
            {
            	var newtab = window.open("register.php", 'SFC',config='height=500px,width=500px,scrollbars=no,resizable=yes,status=no');
            	newtab.focus(); 
            }
            </script>
            </head>
            <body>
            <form name="form1" method="POST" action="<?=$page?>">
            <p><font color="red" size="4" face="新細明體"><b>請輸入帳號密碼進行驗證</b></font></p>
            <p>
            帳號：<input name="username" type="text" maxlength="20" value="" size="15" /><br />
            密碼：<input name="password" type="password" maxlength="20" value="" size="16" />
            </p>
            <input class="darkbutton" type="submit" name="submit" value="登入" /><br /><br />
            <a onclick="show_window()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">忘記密碼？</a><BR>
<a onclick="show_window1()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">帳號申請</a>
            </form>
            </body>
            </html>
    <?
            session_write_close();
            exit;
        }
    }
    else
    {
?>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
        <script language="JavaScript">
        function show_window()
        {
        	var newtab = window.open("forget_pwd.php", 'SFC',config='height=200px,width=430px,scrollbars=no,resizable=no,status=no');
        	newtab.focus(); 
        }
        function show_window1()
        {
        	var newtab = window.open("register.php", 'SFC',config='height=500px,width=500px,scrollbars=no,resizable=yes,status=no');
        	newtab.focus(); 
        }
        </script>
        </head>
        <body>
        <form name="form1" method="POST" action="<?=$page?>">
        <p><font color="red" size="4" face="新細明體"><b>請輸入帳號密碼進行驗證</b></font></p>
        <p>
        帳號：<input name="username" type="text" maxlength="20" value="" size="15" /><br />
        密碼：<input name="password" type="password" maxlength="20" value="" size="16" />
        </p>
        <input class="darkbutton" type="submit" name="submit" value="登入" /><br /><br />
        <a onclick="show_window()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">忘記密碼？</a><BR>
<a onclick="show_window1()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">帳號申請</a>
        </form>
        </body>
        </html>
<?
        session_write_close();
        exit;
    }
}
session_write_close();
?>