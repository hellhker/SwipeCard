<?php 
//ob_start();
putenv("TZ=Asia/Taipei");
$ORACLE_LOGIN = "denil";
$ORACLE_PASSWORD = "denil";
$ORACLE_HOST = "192.168.244.35/scbgt";

$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";

?>