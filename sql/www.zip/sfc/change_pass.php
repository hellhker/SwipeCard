<?php
include("auth.php");
?>
<HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="includes/class.css"  rel="stylesheet" type="text/css" />
</head>
<BODY bgcolor="#FFFFFF">
<CENTER>
<H3>變更密碼</h3>   
<HR>   
<FORM action="change_pass1.php" method=post>   
<INPUT Type="Hidden"  Name="Unit"   value="<?php echo $ShowID;?>">
<table border="2"  bgcolor="#FCFBE0">   
  <tr>   
    <td >使用者帳號 </td>   
    <td ><?php echo $ShowID;?></td>   
</tr>
<tr>   
    <td >舊密碼 </td>   
    <td ><INPUT Type="Password"  Name="oldpass"  Size="6" ></td>   
</tr>
<tr>   
    <td >新密碼 </td>   
    <td ><INPUT Type="Password"  Name="pass1"  Size="6" ></td>   
</tr>
 <tr>   
    <td >新密碼(請再輸入一次)</td>   
    <td ><INPUT Type="Password"  Name="pass2"  Size="6" ></td>   
</tr>
   </table>   
<p><p>
<input type="submit" class="groovybutton" name="Send" value="確定更改">
<input type="reset" class="groovybutton" value="重寫">
</Form>
   
</BODY>     
</HTML>
