<script language="JavaScript" type="text/javascript">
// function set(id)
// {
//     if(id=="user_query")
//     {
//         document.getElementById("user_query").className = "current";
//         document.getElementById("group_setting").className = "";
//         document.getElementById("module_setting").className = "";
//         document.getElementById("group_module_setting").className = "";
//         document.getElementById("mail_to_all").className = "";
//     }else if(id=="group_setting"){
//         document.getElementById("user_query").className = "";
//         document.getElementById("group_setting").className = "current";
//         document.getElementById("module_setting").className = "";
//         document.getElementById("group_module_setting").className = "";
//         document.getElementById("mail_to_all").className = "";
//     }else if(id=="module_setting"){
//         document.getElementById("user_query").className = "";
//         document.getElementById("group_setting").className = "";
//         document.getElementById("module_setting").className = "current";
//         document.getElementById("group_module_setting").className = ""; 
//         document.getElementById("mail_to_all").className = "";   
//     }else if(id=="group_module_setting"){
//         document.getElementById("user_query").className = "";
//         document.getElementById("group_setting").className = "";
//         document.getElementById("module_setting").className = "";
//         document.getElementById("group_module_setting").className = "current";
//         document.getElementById("mail_to_all").className = "";
//     }
//     else
//     {
//         document.getElementById("user_query").className = "";
//         document.getElementById("group_setting").className = "";
//         document.getElementById("module_setting").className = "";
//         document.getElementById("group_module_setting").className = "";
//         document.getElementById("mail_to_all").className = "current";
//     }
// }
// </script>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="includes/tabs.css" rel="stylesheet" type="text/css" />
    <script src="jquery-1.7.1.js">
    </script>
    <script>
    $(function(){
        $("ol>li").click(function(){
            $("ol>li").removeClass("current");
            $(this).addClass("current");
        })
    })
    </script>
</head>
<body>
<ol id="toc" style="margin-left:70px; margin-top: 0px;">
    <li id="user_query"><a target="context" href="user_query.php"><span>使用者管理</span></a></li>
    <li id="group_setting"><a target="context" href="group_module/role_info.php"><span>分組信息</span></a></li>
    <li id="module_setting"><a target="context" href="group_module/module_info.php" onclick="set('module_setting')"><span>模块信息設定</span></a></li>
    <li id="group_module_setting"><a target="context" href="group_module/role_module_set.php"><span>分組權限設定</span></a></li>
    <li id="mail_to_all"><a target="context" href="mail_to_all.php"><span>全體信件</span></a></li>
     <li><a target="context" href="wechat_mail_to_all.php"><span>企業微信公告</span></a></li>
     <li><a target="context" href="group_module/prod_state.php"><span>組織圖</span></a></li>
</ol>
<hr width="100%" size="1" color="#4488ff" style="FILTER: alpha(opacity=100,finishopacity=0,style=3);"/>
</body>
</html>
