<?php 
//ob_start();
putenv("TZ=Asia/Taipei");
session_start();
$ORACLE_LOGIN = "denil";
$ORACLE_PASSWORD = "denil";
$ORACLE_HOST = "192.168.244.35/scbgt";

$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";

$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 

if((strcmp($_SESSION["ssn_usr"],"")!=0)&& (strcmp($_SESSION["ssn_psd"],"")!=0))
{
	$username = $_SESSION["ssn_usr"];
	$password = $_SESSION["ssn_psd"];
			
	$user_sql = "SELECT a.ID,a.UserID,a.ChineseName,a.EMail,a.DepartmentCode,b.name,a.Division,b.fac_code,a.GroupName FROM `user_data` a left join `group_structure` b on a.DepartmentCode=b.Depart_Code Where a.UserID='$username' And a.Password = '$password'";
	$user_rows = $mysqli->query($user_sql);
	$user_num = $user_rows->num_rows;
	if($user_num > 0)
	{
			$user_row = $user_rows->fetch_row();
			$ShowID = $user_row[1];
			$ChName = $user_row[2];
			$emailaddr = $user_row[3];
            $dept_code = $user_row[4];
			$dpment = $user_row[5];
			$division = $user_row[6];
			$factory = $user_row[7];
			$groupname = $user_row[8];
			
			$group_sql = "SELECT * FROM `group_table` where GroupName='$groupname'";
			$group_rows = $mysqli->query($group_sql);
			$group_row = $group_rows->fetch_row();
			
			$sfc_wip_query = $group_row[3];
			$sfc_wip_modify = $group_row[4];
			$sfc_repair_query = $group_row[5];
			$sfc_repair_modify = $group_row[6];
			$sfc_product_query = $group_row[7];
			$sfc_product_modify = $group_row[8];
			$sfc_yield_query = $group_row[9];
			$sfc_yield_modify = $group_row[10];
			$sfc_alert_query = $group_row[11];
			$sfc_alert_modify = $group_row[12];
			$sfc_clipboard_query = $group_row[13];
			$sfc_clipboard_modify = $group_row[14];
			$aoi_product_query = $group_row[15];
            $aoi_product_modify = $group_row[16];
			$aoi_detect_query = $group_row[17];
            $aoi_setting_query = $group_row[18];
            $aoi_setting_modify = $group_row[19];
            $erp_fq_conn_query = $group_row[20];
            $erp_ks_conn_query = $group_row[21];
            $erp_igbu_query = $group_row[22];
            $erp_lk_cable_query = $group_row[23];
            $erp_ks_cable_query = $group_row[24];
            $erp_qy_cable_query = $group_row[25];
            $fab_query = $group_row[26];
            $user_add = $group_row[27];
            $dept_modify = $group_row[28];
            mysqli_free_result($group_rows);
            mysqli_free_result($user_rows);
            $mysqli->close();
	}
    else 
	{
	        $mysqli->close();
            session_write_close();
	        echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
	        echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
            echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
            echo "</SCRIPT>";
            echo "<script language=\"javascript\">"; 
            echo "top.location.href='http://".$_SERVER['HTTP_HOST']."/welcome.php'";
            echo "</script>"; 
	}
}
else
{
    $mysqli->close();
    session_write_close();
    echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
    echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
    echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
    echo "</SCRIPT>";
    echo "<script language=\"javascript\">";
    echo "top.location.href='http://".$_SERVER['HTTP_HOST']."/welcome.php'";
    echo "</script>";
}
session_write_close();
//關閉輸出暫存器
//ob_end_flush();
?>