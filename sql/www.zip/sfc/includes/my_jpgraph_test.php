﻿<?php
$color_array = array("AntiqueWhite3","azure2","brown1","blueviolet","burlywood1","coral","chartreuse","deeppink2","darkturquoise","gray8","gold3","hotpink","lightblue","lemonchiffon3","khaki1","magenta");
$group1_array = array("#9BBB59","#00BFFF");
$group2_array = array("#FFFFFF","#00BFFF");
$group3_array = array("#009900","#C0504D","#8064A2","#9BBB59","burlywood1","brown1","gold3","darkturquoise","coral","gray8","deeppink2","AntiqueWhite3","azure2","chartreuse","hotpink","blueviolet","lemonchiffon3","khaki1","magenta");

function Draw_PiePlot($width,$height,$title,$ydata,$legend_array,$value_type)
{
    global $color_array;
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($width,$height);
    
    // Set A title for the plot
    $graph->title->SetFont(FF_CHINESE,FS_NORMAL,8);
    $graph->title->Set($title);
    $graph->SetBox(false);
    $graph->legend->SetFrameWeight(1);
	$graph->legend->SetFont(FF_CHINESE,FS_NORMAL,8);
	$graph->legend->SetColumns(2);
    $graph->legend->Pos(0.1,0.78,"left","top");
    
    // Create
    $p1 = new PiePlot($ydata);
    $graph->Add($p1);
    
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.5,0.34);
    $p1->SetLegends($legend_array);
    
    if($value_type=="percent")
        $p1->value->SetFormat('%0.1f%%');
    else
        $p1->value->SetFormat('%0.1f%');
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_AccBarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata1,$ydata2,$legend_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->SetMargin(50,15,20,90); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.88,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL);
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL);
    $graph->xaxis->title->SetColor('red');
    
    $barplot1 = new BarPlot($ydata1);
    $barplot2 = new BarPlot($ydata2);
    $accbplot = new AccBarPlot(array($barplot1,$barplot2));
    $graph->Add($accbplot);
    
    $barplot1->SetColor("#4BFB05");
    $barplot1->SetFillColor("#4BFB05");
    $barplot1->SetLegend($legend_array[0]); 
    $barplot1->SetValuePos('top');
	$barplot1->value->SetFormat('%d');
	$barplot1->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
    $barplot1->value->SetColor("#867DEC");
	$barplot1->value->Show(); 
    
    $barplot2->SetColor("gray");
    $barplot2->SetFillColor("gray");
    $barplot2->SetLegend($legend_array[1]);

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_BarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata,$legend_array,$bar_color)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.9,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $barplot = new BarPlot($ydata);
    $graph->Add($barplot);
    
    $barplot->SetColor($bar_color);
    $barplot->SetFillColor($bar_color);
    $barplot->SetLegend($legend_array[0]); 
    $barplot->SetValuePos('top');
	$barplot->value->SetFormat('%d');
	$barplot->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
    $barplot->value->SetColor("#867DEC");
	$barplot->value->Show();

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_GroupBarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$bar_count,$ydata_array,$legend_array,$color_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.86,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $bplot_array = array();
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i} = new BarPlot($ydata_array[$i]);
        array_push($bplot_array,${"barplot".$i});
    }
    $gbplot = new GroupBarPlot($bplot_array);
    $graph->Add($gbplot);
    
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i}->SetColor($color_array[$i]);
        ${"barplot".$i}->SetFillColor($color_array[$i]);
        ${"barplot".$i}->SetLegend($legend_array[$i]); 
        ${"barplot".$i}->SetValuePos('top');
    	${"barplot".$i}->value->SetFormat('%d');
    	${"barplot".$i}->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
        ${"barplot".$i}->value->SetColor($color_array[$i]);
    	${"barplot".$i}->value->Show();
    }

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_GroupBarPlot2($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$bar_count,$ydata_array,$legend_array,$color_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,5,35,55); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array('0%','20%','40%','60%','80%','100%'));
    $graph->SetBox(false);
    
    //$graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.83,'center','top');
    $graph->legend->SetColumns(1);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    //$graph->yaxis->title->SetMargin(0);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $bplot_array = array();
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i} = new BarPlot($ydata_array[$i]);
        array_push($bplot_array,${"barplot".$i});
    }
    $gbplot = new GroupBarPlot($bplot_array);
    $graph->Add($gbplot);
    
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i}->SetColor($color_array[$i]);
        ${"barplot".$i}->SetFillColor($color_array[$i]);
        ${"barplot".$i}->SetLegend($legend_array[$i]); 
        ${"barplot".$i}->SetValuePos('top');
    	${"barplot".$i}->value->SetFormat('%0.1f%%');
    	${"barplot".$i}->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
        ${"barplot".$i}->value->SetColor("black");
        
        if(($i%2)==0)
    	    ${"barplot".$i}->value->Show(false);
        else
            ${"barplot".$i}->value->Show(true);
    }

    @unlink($filename);
    $graph->legend->Pos(0.58,0.99,"center","bottom"); 	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

//繪製兩條LinePlot
function Draw_DoubleLinePlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata,$ydata1,$legend_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.9,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $line1 = new LinePlot($ydata);
    $graph->Add($line1);
    
    $line2 = new LinePlot($ydata1);
    $graph->Add($line2);
    
    $line1->SetColor("red");
    $line1->SetLegend($legend_array[0]);
    $line1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line1->mark->SetColor('red');
	$line1->mark->SetFillColor('red');
	$line1->SetCenter();
    
    $line2->SetColor("green");
    $line2->SetLegend($legend_array[1]);
    $line2->mark->SetType(MARK_SQUARE,'',1.0);
	$line2->mark->SetColor('green');
	$line2->mark->SetFillColor('green');
	$line2->SetCenter();

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_Sector($size,$title,$ydata,$color_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($size,$size);
    
    // Set A title for the plot
    $graph->title->SetFont(FF_CHINESE,FS_NORMAL,8);
    $graph->SetFrame(true,'gray',1);
    
    // Create
    $p1 = new PiePlot($ydata);
    $graph->Add($p1);
    
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.5,0.5);
    $p1->value->Show(false);
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_PiePlot3D($size,$title,$ydata,$legend_array,$color_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    require_once('../jpgraph/src/jpgraph_pie3d.php');
    
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($size*1.14,$size);
    //$graph->SetFrame(true,array(0,0,0),1);
    $graph->SetShadow();
    // Set A title for the plot
    $graph->title->SetFont(FF_CHINESE,FS_NORMAL,8);
    $graph->title->Set($title);
    $graph->SetBox(false);
    //$graph->legend->SetFrameWeight(1);
	$graph->legend->SetFont(FF_CHINESE,FS_NORMAL,8);
	$graph->legend->SetColumns(1);
    $graph->legend->Pos(0.22,0.63,"left","top");
    
    // Create
    $p1 = new PiePlot3D($ydata);
    $graph->Add($p1);
    $p1->SetSize(round($size*0.32));
    $p1->SetLabelMargin(0);
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.5,0.34);
    $p1->SetLegends($legend_array);
    $p1->value->SetFormat('%0.1f%%');
    $p1->value->SetFont(FF_VERDANA,FS_NORMAL,7);
    $p1->value->SetColor("black");
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function chartGroup_byPie($l_size,$l_title,$l_data,$l_legend,$m_size,$r_size,$r_title,$r_data,$r_legend)
{
    global $group1_array,$group2_array,$group3_array;
    $filename = Draw_PiePlot3D($l_size,$l_title,$l_data,$l_legend,$group1_array);
    $cch = "<table>";
    $cch .= "<tr>";
    $cch .= "<td><img src=\"".$filename."\" ISMAP USEMAP=\"#map_links\" border=\"0\" /></td>";
    
    $filename = Draw_Sector($m_size,"",$l_data,$group2_array);
    $cch .= "<td width=50 align='center'><img src=\"".$filename."\" ISMAP USEMAP=\"#map_links\" border=\"0\" /><br><font size=\"2px\">".$l_legend[1]."</font></td><td width=40><img src=\"../img/r_forward.png\" width=\"40\" /></td>";
    
    $ydata1 = array();
    $legend1 = array();
    $ydata1[0] = "20";
    $ydata1[1] = "60";
    $legend1[0]="分子1";
    $legend1[1]="分子2";
    $filename = Draw_PiePlot3D($r_size,$r_title,$r_data,$r_legend,$group3_array);
    $cch .= "<td><img src=\"".$filename."\" ISMAP USEMAP=\"#map_links\" border=\"0\" /></td>";
    $cch .= "</tr>";
    $cch .= "</table>";
    return $cch;
}

function chartGroup_byBar($l_width,$l_height,$l_title,$l_data,$l_legend,$r_size,$r_title,$r_data,$r_legend)
{
    global $group1_array,$group2_array,$group3_array;
    $ydata_array = array(array($l_data[0]/($l_data[0]+$l_data[1])*100),array($l_data[1]/($l_data[0]+$l_data[1])*100));
    $filename = Draw_GroupBarPlot2($l_width,$l_height,0,100,20,$l_title,"","％",array(""),2,$ydata_array,$l_legend,$group1_array);
    $cch = "<table >";
    $cch .= "<tr>";
    $cch .= "<td style=\"padding: 0px;\"><img src=\"".$filename."\" ISMAP USEMAP=\"#map_links\" border=\"0\" /></td>";
    $cch .= "<td width=40 align='center' style=\"padding: 0px;\"><span style=\"background:".$group1_array[1]."; display:inline-block; width:25px; height:65px\"></span><br><img src=\"../img/r_forward.png\" width=\"40\" /></td>";
    
    $filename = Draw_PiePlot3D($r_size,$r_title,$r_data,$r_legend,$group3_array);
    $cch .= "<td style=\"padding: 0px;\"><img src=\"".$filename."\" ISMAP USEMAP=\"#map_links\" border=\"0\" /></td>";
    $cch .= "</tr>";
    $cch .= "</table>";
    return $cch;
} 
function Draw_DoubleBarPlotAndLinePlot($width,$height,$ticks,$yman2,$title,$xtitle,$ytitle,$ytitle1,$xdata,$ydata,$ydata1,$ydata2,$legend_array)
{
require_once('../jpgraph/src/jpgraph.php');
require_once('../jpgraph/src/jpgraph_line.php');
require_once('../jpgraph/src/jpgraph_bar.php');

$graph = new Graph($width,$height,"auto"); //创建新的Graph对象 
$graph->SetScale("textlin"); //設置刻度值類型
$graph->SetY2Scale("lin",0,$yman2); //設置y軸的值，這裡是從0-$yman
$graph->SetY2OrderBack(false);       //Y2軸顯示在上層
$graph->img->SetMargin(40,30,10,0); //设置图像边距 ,順序為：左右上下  60,50,20,40:正好不會蓋到“數量”，“時間”，“%”
$graph->yscale->ticks->Set($ticks);
$map_links = "map_links";
//$graph->img->SetAntiAliasing(false); //設置線的寬度之前要先調用這個函數

$BarPlot=new BarPlot($ydata); //$ydata:有效產能
$BarPlot2=new BarPlot($ydata1); //$ydata1:投入數量，產出數量
$BarPlots = new GroupBarPlot(array($BarPlot,$BarPlot2));
$graph->Add($BarPlots); //将曲线放置到图像上 ，創建測量點
$lineplot = new LinePlot($ydata2); //创建BarPlot对象 
$lineplot->SetBarCenter(); //折綫顯示在柱條中間
$graph->AddY2($lineplot); //将曲线放置到图像上 

//$graph->title->Set($title);
//$graph->title->SetFont(FF_CHINESE,FS_NORMAL,10);//設置圖標標題類型 
/*$graph->xaxis->title->Set($xtitle); //设置坐标轴名称 
$graph->xaxis->title->SetFont(FF_CHINESE,FS_NORMAL,8);
$graph->xaxis->title->SetColor('red');
$graph->xaxis->title->SetMargin(0);*/

$graph->yaxis->title->Set($ytitle);   //xaxis:x軸名稱，yaxis:y軸名稱
$graph->yaxis->title->SetMargin(25);
$graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,8);
$graph->yaxis->title->SetColor('red');
//$graph->yaxis->title->SetOrientation(0);//改變y軸標題方向

$graph->y2axis->title->Set($ytitle1); 
$graph->y2axis->title->SetMargin(6);
$graph->y2axis->title->SetFont(FF_CHINESE,FS_NORMAL,8);
$graph->y2axis->title->SetColor('red');

$graph->xaxis->SetTickLabels($xdata);
$graph->y2axis->SetFont(FF_TIMES,FS_NORMAL,9); 
$graph->xaxis->SetFont(FF_TIMES,FS_NORMAL,9);
$graph->yaxis->SetFont(FF_TIMES,FS_NORMAL,9);
//$line->SetColor("#FF8C00"); //设置颜色 
$lineplot->SetColor("red");
$lineplot->SetLegend($legend_array[2]);
$lineplot->SetStyle(1);
$lineplot->SetWeight(1);

$BarPlot->SetColor("#5080B8"); 
$BarPlot->SetFillColor("#5080B8"); 
$BarPlot->SetLegend($legend_array[0]); //设置图例名称 
/*$BarPlot->SetValuePos('top');
$BarPlot->value->SetFormat('%d');
$BarPlot->value->SetFont(FF_TIMES, FS_NORMAL,7); 
$BarPlot->value->SetColor("#1D1D1D");
$BarPlot->value->Show();*/

$BarPlot2->SetColor("#B4E069"); 
$BarPlot2->SetFillColor("#B4E069"); 
$BarPlot2->SetLegend($legend_array[1]);
$BarPlot2->SetValuePos('top');
$BarPlot2->value->SetFormat('%d');
$BarPlot2->value->SetFont(FF_TIMES, FS_NORMAL,7); 
$BarPlot2->value->SetColor("#1D1D1D");
$BarPlot2->value->Show(); 

$graph->legend->SetColor('#4E4E4E');
$graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);//設置圖例字體類型
//$graph->legend->SetLayout(LEGEND_HOR);
//$graph->legend->Pos(0.4, 0.95, 'center', 'bottom');//图例的位置 0.4，0.95是以右上角为基准的，0.4是距左右距离，0.95是上下距离。
$graph->legend->Pos(0.50,0.95,"center","bottom"); 
$filename = "../img1/".rand().".png";
@unlink($filename);
$graph->Stroke($filename);//輸出圖像
return $filename;
}
      
?>