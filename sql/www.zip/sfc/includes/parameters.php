<?php
// Date          Version         Author
// 2016/10/13    1               Created by Denil
// 備註：給 tab_aoi_resume_old / tab_auto_resume_old 使用

class resume_para
{
    //****定義Event事件代碼****
    public $event_produce="201";          //生產中
    public $event_stop="202";             //緊急停止
    public $event_repair="210";           //調機維修
    public $event_error="211";            //異常警報
    public $event_wait_material="205";    //待料停機
    public $event_restart="215";          //開機損失
    public $event_change_material="216";  //換盤換料
    public $event_rest="217";             //休息停機
    public $event_pre_connect="218";      //前段連機
    public $event_aft_connect="219";      //後段連機
    
    //****定義Data判別代碼****
    public $aoi_good="1";
    
    public $param_arr=array();
    //****定義全域變數****
    public $g_standard_time = 0; //標準工時
    //public $g_exclude_time = 0;
    public $g_wait_material_time = 0;
    public $g_restart_time = 0;
    public $g_change_material_time = 0;
    public $g_rest_time = 0;
    public $g_pre_connect_time = 0;
    public $g_aft_connect_time = 0;
    public $g_prod_time = 0;
    //public $g_actual_time = 0;
    //public $g_loss_time = 0;
    public $g_stop_time = 0;
    public $g_repair_time = 0;
    public $g_error_time = 0;
    //public $g_input_time = 0;
    //public $g_manage_time = 0;
    public $g_alarm_time = 0;
    
    public $g_stop_happen_times = 0;
    public $g_repair_happen_times = 0;
    public $g_wait_material_happen_times = 0;
    public $g_restart_happen_times = 0;
    public $g_change_material_happen_times = 0;
    public $g_rest_happen_times = 0;
    public $g_pre_connect_happen_times = 0;
    public $g_aft_connect_happen_times = 0;
    //public $g_exclude_happen_times = 0;
    
    public $g_loss_group = array("202","210","211");
    public $g_exclude_group = array("205","215","216","217","218","219");

    function __construct() //建構子
    {
        $this->param_arr[0]="aoi_good";
    }
    
    //****定義公式****
    //計算除外工時
    public function exclude_time()
    {
        return $this->g_wait_material_time + $this->g_restart_time + $this->g_change_material_time + $this->g_rest_time + $this->g_pre_connect_time + $this->g_aft_connect_time;
    }
    
    //計算損失時間
    public function loss_time()
    {
        return $this->g_stop_time + $this->g_repair_time + $this->g_error_time;
    }
    
    //計算實際工時
    public function actual_time()
    {
        return $this->g_prod_time - $this->g_pre_connect_time - $this->g_aft_connect_time;
    }
    
    //計算投入工時
    public function input_time()
    {
        return $this->loss_time() + $this->exclude_time() + $this->actual_time();
    }
    
    //計算管理損失
    function manage_time()
    {
        return $this->g_standard_time - $this->input_time();
    }
    
    //除外發生次數
    public function exclude_happen_times()
    {
        return $this->g_wait_material_happen_times + $this->g_restart_happen_times + $this->g_change_material_happen_times + $this->g_rest_happen_times + $this->g_pre_connect_happen_times + $this->g_aft_connect_happen_times;
    }
    
    //計算管理稼動率
    public function manage_availability()
    {
        return ($this->g_standard_time==0)?0:($this->input_time()/$this->g_standard_time);
        //return ($this->g_standard_time==0)?0:round(($this->input_time()/$this->g_standard_time)*100,1);        
    }
    
    //計算生產稼動率
    public function produce_availability()
    {
        return ($this->input_time()==0)?0:($this->actual_time()/$this->input_time());
        //return ($this->input_time()==0)?0:round(($this->actual_time()/$this->input_time())*100,1);
    }
}
?>