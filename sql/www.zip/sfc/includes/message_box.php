<?
$ORACLE_LOGIN = "alarmdblinker";
$ORACLE_PASSWORD = "f0xlink";
$ORACLE_HOST = "10.8.91.122/AlarmTestDB";
    
//***** Message_Box($fab,$content,$send_type) *****//
/*
$fab: (String)廠區(如FD,FQ,KS...)
$content: (String)message content
$send_type: (Integer)message send type. (1)簡訊 (2)E-mail (3)Push Notification
*/
function Message_Box($fab,$content,$send_type)
{
    global $ORACLE_LOGIN,$ORACLE_PASSWORD,$ORACLE_HOST;
    $conn = oci_new_connect($ORACLE_LOGIN,$ORACLE_PASSWORD,$ORACLE_HOST,'TRADITIONAL CHINESE_TAIWAN.ZHT16MSWIN950');
    $insert_sql = "INSERT INTO ALARM_MESSAGE_TMP(system_name,app_name,factory_code,message_title,message_content,"
                 ."message_send_type,message_sender,send_by_department,received_group_name)VALUES ("
                 ."'Others','MsgBox','$fab','製造即時系統公告','$content',$send_type,'7575',6267,'SCBG測試群組')";
                 
    $stmt = oci_parse($conn, $insert_sql);
    oci_execute($stmt, OCI_COMMIT_ON_SUCCESS);
    oci_close($conn);
}
?>