<?php
// Date          Version         Author
// 2016/10/13    1               Created by Denil
// 2017/02/01    2               edit by hsin
// 備       註： 拿 parameters.php 增修為 parameters1.php

#AOI規則==========================================================================
#良品數        ：最後一站良品數(code2=1)
#不良數        ：各站的不良數(code2=0)  
#良品數(複判)  ：最後一站良品數(code2=5)
#不良品數(複判)：各站的不良數(code2=4)    
#模穴號良品數  ：最後一站良品數(code2=1) & code5 不為空 & code6 不為空
#模穴號不良品數：各站的不良數(code2=0) & code5 不為空 & code6 不為空    
#投入數        ：良品數+不良品數
#投入數複判)   ：良品數+不良品數+良品數(複判)+不良品數(複判)        

#HMI規則==========================================================================
#投入數        ：各站投入量(Code11)
#不良數        ：各站的不良數(code7)    
#產出數         :投入數-不良品數(Code11-code7)
#==============================================================================

class resume_para
{   
    /** 定義資料庫相關全域變數**/
    public $g_dbname1="sfc";
    public $g_dbname2="aoi";  
    public $g_dbname3="hmi";
    public $g_now_dbname="";        #用來判別此網頁要走哪一個資料庫
    
    
    /** 定義Event事件代碼 (以下將由Array取代，請不要再使用它)**/
    public $event_produce="201";          #生產中
    public $event_stop="202";             #緊急停止
    public $event_repair="210";           #調機維修
    public $event_error="211";            #異常警報
    public $event_wait_material="205";    #待料停機
    public $event_restart="215";          #開機損失
    public $event_change_material="216";  #換盤換料
    public $event_rest="217";             #點檢停機
    public $event_pre_connect="218";      #前段連機
    public $event_aft_connect="219";      #後段連機
    public $event_alarm="1-199";          #異常警報
        
    
    /** 定義AOI-Data判別代碼 **/
    public $o_project_exception="n56;n71 aj;n71 e75;";                              #早期舊的已結束的專案，都搬去old資料庫 
    //public $o_project_exception_on="n66 aj;";                                     #早期舊的專案預存格式和現在不同，但還ON再線上
    public $o_project_exception_statistical="n56;n71 aj;n71 e75;n66 aj;";           #早期舊的專案預存格式和現在不同，所以不能跑預存
    
    public $aoi_good="Code2;1";                                                     #Code2=1良品
    public $aoi_good_repeat="Code2;5";                                              #Code2=5良品複判      
    public $aoi_bad="Code2;0";                                                      #Code2=1不良品
    public $aoi_bad_repeat="Code2;4";                                               #Code2=4不良品複判             
    public $aoi_good_identify="Code5;Code6;";                                       #模穴號辨識是否為空值用
    public $aoi_bad_identify="Code5;Code6;";                                        #模穴號辨識是否為空值用    
    public $aoi_column="Line,device_name,Code2,Code5,Code6,Code3,Code4";            #sql select
    public $aoi_orderby="Line,Code3,Code4";                                         #sql order by 
    
    /** 定義HMI-Data判別代碼 **/
    public $hmi_input="Code11;";                                        #code11投入  
    public $hmi_bad="Code7;";                                           #code7不良排出         
    public $hmi_column="Line,Code11,Code7,Code1,Code2";                 #sql select
    public $hmi_orderby="Line,Code1,Code2";                             #sql order by     
     
      
    /** 定義Event全域變數 **/
    public $g_Unit_Per_Hour = 3600;
    public $g_standard_time_Day = 44400;        #標準工時-日
    public $g_standard_time_Night = 42000;      #標準工時-夜
    public $g_go_alarm=0;                       #用來判別要走1-199，預設不啟用
    
    public $g_standard_time = 0;                #標準工時
    //public $g_exclude_time = 0;
    public $g_wait_material_time = 0;
    public $g_restart_time = 0;
    public $g_change_material_time = 0;
    public $g_rest_time = 0;
    public $g_pre_connect_time = 0;
    public $g_aft_connect_time = 0;
    public $g_prod_time = 0;
    //public $g_actual_time = 0;
    //public $g_loss_time = 0;
    public $g_stop_time = 0;
    public $g_repair_time = 0;
    public $g_error_time = 0;
    //public $g_input_time = 0;
    //public $g_manage_time = 0;
    public $g_alarm_time = 0;
        
    public $g_stop_happen_times = 0;
    public $g_repair_happen_times = 0;
    public $g_wait_material_happen_times = 0;
    public $g_restart_happen_times = 0;
    public $g_change_material_happen_times = 0;
    public $g_rest_happen_times = 0;
    public $g_pre_connect_happen_times = 0;
    public $g_aft_connect_happen_times = 0;
    //public $g_exclude_happen_times = 0;
    
    public $g_cycle_time = 0;                   #標準C/T    
    public $g_range=0;                          #暫存
    public $g_U_range=0;                        #暫存
    public $g_L_range=0;                        #暫存

    
    
    /** 定義AOI-Data全域變數 **/
    public $o_start_time="07:40:00";
    public $o_end_time="20:00:00";
    public $g_aoi_good=0;
    public $g_aoi_bad=0;
    public $g_aoi_good_repeat=0;
    public $g_aoi_bad_repeat=0;
    public $g_aoi_good_identify=0;
    public $g_aoi_bad_identify=0;
    public $g_aoi_bad_station=0;                                                        #特定網頁才使用:不良(依工站區分)
    public $g_aoi_input_include_repeat=0;                                               #特定網頁才使用:直接從上一層接投入數
    public $update_statistics_record1="update_statistics_record1";                      #有預存的網頁才使用-未上線暫用
    public $update_statistics_record="update_statistics_record";                        #有預存的網頁才使用-已上線使用
   
    /** 定義HMI-Data全域變數 **/
    public $g_hmi_input=0;
    public $g_hmi_bad=0;
    
    
    
    /** 定義Event全域陣列 **/
    public $g_loss_group = array("202","210","211");
    public $g_loss_group1 = array("201","202","205","210","211","215","216","217");
    public $g_exclude_group = array("205","215","216","217","218","219");
    public $g_actual_group = array("201","218","219");
        
    public $g_cate_array_flip_name=array(0=>"molecular",1=>"denominator");      #特定網頁才使用 e.g.稼動分析-稼動指標分析-工時損失率(%)    
       
    public $c_event_param_arr=array();              #必要
    public $c_event_param_arr1=array();             #必要
    public $g_cycle_time_arr=array();               #特定網頁才使用    
    public $g_s_day_array=array();                  #特定網頁才使用  
    public $g_e_day_array=array();                  #特定網頁才使用    
    public $g_event_arr=array();                    #專用於event rawdata暫存用的     
    public $g_event_arr1=array();                   #專用於event rawdata暫存用的 e.g.稼動分析-閒置區間分析-損失工時分析-進階查詢
    public $g_tmp_event_rawdata_array=array();      #專用於event rawdata暫存用的，供各format function呼叫
    public $g_debug_msg_array=array();              #只是用來做DEBUG暫存用的
    
    /** 定義AOI-Data全域陣列 **/
    public $g_shift_arr=array("D","N","DN","F");   #必要 e.g.日班、夜班、日夜(後續可以再拆日、夜)、整日
    public $c_aoi_param_arr=array();               #必要
    public $c_aoi_param_arr1=array();              #必要   
    public $g_measure_info=array();                #必要
    
    public $g_final_arr=array();                   #專用於aoi rawdata暫存用的    
    public $g_final_arr1=array();                  #專用於aoi rawdata暫存用的          
    public $g_final_arr2=array();                  #專用於aoi rawdata暫存用的                
    public $g_final_arr3=array();                  #專用於aoi rawdata暫存用的
    public $g_final_arr4=array();                  #專用於aoi rawdata暫存用的
    public $g_final_arr5=array();                  #專用於aoi rawdata暫存用的

    public $g_idle_ragne_arr=array();     
    public $g_bad_include_repeat_group = array("1","3");    #指 c_aoi_param_arr[1],c_aoi_param_arr[3]
    public $g_bad_group = array("1");                       #指 c_aoi_param_arr[1]
    

    function __construct() #建構子
    {   
        /** 參數名稱命名規則: 全域變數的第3碼後要同以下參數名稱 **/ 
                
        
        /** Event:定義事件代碼: **/     
        $this->c_event_param_arr[0][1]="210";       #調機維修
        $this->c_event_param_arr[1][1]="202";       #緊急停止
        $this->c_event_param_arr[2][1]="211";       #異常警報 
        $this->c_event_param_arr[3][1]="205";       #待料停機
        $this->c_event_param_arr[4][1]="215";       #開機損失
        $this->c_event_param_arr[5][1]="216";       #換盤換料
        $this->c_event_param_arr[6][1]="217";       #點檢停機
        $this->c_event_param_arr[7][1]="218";       #前段連機
        $this->c_event_param_arr[8][1]="219";       #後段連機
        $this->c_event_param_arr[9][1]="201";       #生產中
        $this->c_event_param_arr[10][1]="1-199";    #異常警報..........1~199 (明細必須用這個)          

        /** Event:定義事件代碼中文: **/
        $this->c_event_param_arr[0][3]="調機維修";       
        $this->c_event_param_arr[1][3]="緊急停止";       
        $this->c_event_param_arr[2][3]="異常警報";        
        $this->c_event_param_arr[3][3]="待料停機";       
        $this->c_event_param_arr[4][3]="開機損失";       
        $this->c_event_param_arr[5][3]="換盤換料";       
        $this->c_event_param_arr[6][3]="點檢停機";       
        $this->c_event_param_arr[7][3]="前段連機損失";       
        $this->c_event_param_arr[8][3]="後段連機損失";       
        $this->c_event_param_arr[9][3]="生產中";         
        $this->c_event_param_arr[10][3]="異常警報";

        /** EVENT:單一參數名稱-工時 **/
        $this->c_event_param_arr[0][0]="repair_time";   
        $this->c_event_param_arr[1][0]="stop_time";
        $this->c_event_param_arr[2][0]="error_time";   
        $this->c_event_param_arr[3][0]="wait_material_time";
        $this->c_event_param_arr[4][0]="restart_time";
        $this->c_event_param_arr[5][0]="change_material_time";
        $this->c_event_param_arr[6][0]="rest_time";
        $this->c_event_param_arr[7][0]="pre_connect_time";
        $this->c_event_param_arr[8][0]="aft_connect_time";
        $this->c_event_param_arr[9][0]="prod_time";
        $this->c_event_param_arr[10][0]="alarm_time";            
        
        /** EVENT:單一參數名稱-次數 **/
        $this->c_event_param_arr[0][2]="repair_happen_times";   
        $this->c_event_param_arr[1][2]="stop_happen_times";
        $this->c_event_param_arr[2][2]="error_happen_times";   
        $this->c_event_param_arr[3][2]="wait_material_happen_times";
        $this->c_event_param_arr[4][2]="restart_happen_times";
        $this->c_event_param_arr[5][2]="change_material_happen_times";
        $this->c_event_param_arr[6][2]="rest_happen_times";
        $this->c_event_param_arr[7][2]="pre_connect_happen_times";
        $this->c_event_param_arr[8][2]="aft_connect_happen_times";
        $this->c_event_param_arr[9][2]="prod_times";
        $this->c_event_param_arr[10][2]="alarm_times";
                
                
        /** AOI:單一參數名稱 **/ 
        $this->c_aoi_param_arr[0]="aoi_good";                       #良品
        $this->c_aoi_param_arr[1]="aoi_bad";                        #不良       
        $this->c_aoi_param_arr[2]="aoi_good_repeat";                #良品複判
        $this->c_aoi_param_arr[3]="aoi_bad_repeat";                 #不良複判       
        $this->c_aoi_param_arr[4]="aoi_good_identify";              #良品(模穴號) 
        $this->c_aoi_param_arr[5]="aoi_bad_identify";               #不良(模穴號)
        $this->c_aoi_param_arr[6]="aoi_bad_station";                #不良(依工站區分)        
                   
        /** AOI:由多參數組合而成 **/
        $this->c_aoi_param_arr1[1]="aoi_input_include_repeat_qty";      #投入含複判
        $this->c_aoi_param_arr1[2]="aoi_input_qty";                     #投入
        $this->c_aoi_param_arr1[3]="aoi_good_include_repeat_qty";       #良品+良品複判 
        $this->c_aoi_param_arr1[4]="aoi_identify_percent";              #模穴號辨識率               
        $this->c_aoi_param_arr1[5]="aoi_bad_percent_qty";               #不良率
        $this->c_aoi_param_arr1[6]="aoi_process_percent";               #製程良率
        $this->c_aoi_param_arr1[7]="aoi_effect_capacity";               #有效產能         
        $this->c_aoi_param_arr1[8]="aoi_input_repeat_qty";              #投入複判


        /** HMI:單一參數名稱 **/ 
        $this->c_hmi_param_arr[0]="hmi_input";                      #投入
        $this->c_hmi_param_arr[1]="hmi_bad";                        #不良       
        //$this->c_hmi_param_arr[2]="hmi_good";                     #不良->由FUN產生       
        

        /** HMI:由多參數組合而成 **/
        $this->c_hmi_param_arr1[0]="hmi_good";                  #良品
        $this->c_hmi_param_arr1[1]="hmi_effect_capacity";       #有效產能   
        
        ##是用來暫存陣列中某一個名稱用的
        $this->c_event_param_arr1[0]="periods";              #eg: 時間 
        $this->c_event_param_arr1[1]="happen_times";         #eg: 次數 
        $this->c_event_param_arr1[2]="row_count"; 
        $this->c_event_param_arr1[3]="s";                   #start time
        $this->c_event_param_arr1[4]="e";                   #end time
        $this->c_event_param_arr1[5]="msg";
        
        
        ##閒置區間分析
        $this->c_idle_ragne_arr[0][0]="2-5";             #以下暫未使用 
        $this->c_idle_ragne_arr[1][0]="5-10";       
        $this->c_idle_ragne_arr[2][0]="10-20";       
        $this->c_idle_ragne_arr[3][0]="20up";
        ##閒置區間分析      
        $this->c_idle_ragne_arr[0][1]="2~5";             #以下暫未使用      
        $this->c_idle_ragne_arr[1][1]="5~10";       
        $this->c_idle_ragne_arr[2][1]="10~20";       
        $this->c_idle_ragne_arr[3][1]=">20";  
         

    }
    //解構子
    function __destruct()
    {        
        unset($this->c_aoi_param_arr);
        unset($this->c_aoi_param_arr1);        
        unset($this->g_measure_info);
        unset($this->g_shift_arr);        
        unset($this->c_hmi_param_arr);
        unset($this->c_hmi_param_arr1);        
                
        unset($this->c_event_param_arr);
        unset($this->c_event_param_arr1);
        unset($this->g_cycle_time_arr);
        unset($this->g_cate_array_flip_name);
        unset($this->g_event_arr);
        unset($this->g_event_arr1);
        
        unset($this->g_final_arr);
        unset($this->g_final_arr1);
        unset($this->g_final_arr2); 
        unset($this->g_final_arr3); 
               
        unset($this->g_final_identify_arr);
        unset($this->g_final_detail_arr);
        unset($this->g_prodarray);
        unset($this->g_tmp_event_rawdata_array);
        
        unset($this->g_debug_msg_array);
        unset($this->c_idle_ragne_arr);
    } 
    
    
    /** 定義Event公式 **/
    //計算除外工時
    public function exclude_time()
    {
        return $this->g_wait_material_time + $this->g_restart_time + $this->g_change_material_time + $this->g_rest_time + $this->g_pre_connect_time + $this->g_aft_connect_time;
    }    
    //計算損失時間
    public function loss_time()
    {
        if($this->g_go_alarm==1)
            return $this->g_stop_time + $this->g_repair_time + $this->g_alarm_time;
        else
            return $this->g_stop_time + $this->g_repair_time + $this->g_error_time;
    }                   
    //計算實際工時
    public function actual_time()
    {
        return $this->g_prod_time - $this->g_pre_connect_time - $this->g_aft_connect_time;
    }    
    //計算投入工時
    public function input_time()
    {
        return $this->loss_time() + $this->exclude_time() + $this->actual_time();
    }    
    //計算管理損失(未開機生產工時)
    public function manage_time()
    {
        return $this->g_standard_time - $this->input_time();
    }    
    //除外發生次數-> 稼動分析 -> 稼動工時分析 -> 細項分析 
    public function exclude_happen_times()
    {
        return $this->g_wait_material_happen_times + $this->g_restart_happen_times + $this->g_change_material_happen_times + $this->g_rest_happen_times + $this->g_pre_connect_happen_times + $this->g_aft_connect_happen_times;
    }    
    //計算損失次數-> 稼動分析 -> 稼動工時分析 -> 細項分析 
    public function loss_happen_times()
    {
        if($this->g_go_alarm==1)
            return $this->g_stop_happen_times + $this->g_repair_happen_times + $this->g_alarm_times;
        else
            return $this->g_stop_happen_times + $this->g_repair_happen_times + $this->g_error_happen_times;
            
    }
    //計算管理稼動率(沒有做百分比&進位換算)=投入工時/標準工時
    public function manage_availability1()
    {
        return ($this->g_standard_time==0)?0:($this->input_time()/$this->g_standard_time);
    }    
    //計算生產稼動率(沒有做百分比&進位換算)
    public function produce_availability1()
    {
        return ($this->input_time()==0)?0:($this->actual_time()/$this->input_time());
    }           
    //目標產能
    public function target_productivity()
    {
        return ($this->g_cycle_time==0?0:($this->g_standard_time/$this->g_cycle_time));
    }     
    //目標UPH(pcs)
    public function target_UPH()
    {
        return ($this->g_cycle_time==0?0:($this->g_Unit_Per_Hour/$this->g_cycle_time));
    }    
    //產能效率= 投入數量/有效產能
    public function Performance()
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return (($this->effect_capacity()==0)?0:($this->g_hmi_input/$this->effect_capacity()));
        else
            return (($this->effect_capacity()==0)?0:($this->aoi_input_include_repeat_qty()/$this->effect_capacity()));        
    }
    //產能達成效率
    public function Reaching_rate_of_Production()
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return ($this->effect_capacity()==0?0:($this->hmi_good_qty()/$this->effect_capacity()));
        else
            return ($this->effect_capacity()==0?0:($this->aoi_good_include_repeat_qty()/$this->effect_capacity()));
    }
    //有效產能=實際工時/(標準C/T)
    public function effect_capacity()
    {
        return ($this->g_cycle_time==0?0:($this->actual_time()/$this->g_cycle_time));
    }
    //損失產能=損失工時/(標準C/T)
    public function loss_time_capacity()
    {
        return ($this->g_cycle_time==0?0:($this->loss_time()/$this->g_cycle_time));
    }
    //除外產能=除外工時/(標準C/T)
    public function exclude_time_capacity()
    {
        return ($this->g_cycle_time==0?0:($this->exclude_time()/$this->g_cycle_time));
    } 
    //未開機工時產能=(標準工時-投入工時)/(標準C/T)
    public function not_on_working_times_capacity() 
    {
        return ($this->g_cycle_time==0?0:($this->g_standard_time - $this->input_time())/$this->g_cycle_time);
    }    
    //實際 C/T 達成率
    public function Reaching_rate_of_actual_CT()   // 原名Reaching_rate_of_CT()
    {
        return ($this->actual_CT()==0?0:$this->g_cycle_time/$this->actual_CT() );
    }    
    //C/T 達成率 -- show_trend5
    public function Reaching_rate_of_CT() 
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return ($this->actual_CT()==0?0:($this->g_cycle_time*$this->g_hmi_input)/$this->actual_time() );
        else
            return ($this->actual_CT()==0?0:($this->g_cycle_time*$this->aoi_input_include_repeat_qty())/$this->actual_time() );        
    }
    //實際C/T
    public function actual_CT() 
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return ($this->g_hmi_input==0?0:$this->actual_time()/$this->g_hmi_input );        
        else
            return ($this->aoi_input_include_repeat_qty()==0?0:$this->actual_time()/$this->aoi_input_include_repeat_qty() );                
    }    
    //UPH
    public function UPH() 
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return (($this->g_standard_time==0?0:$this->g_standard_time)==0?0:$this->hmi_good_qty()*$this->g_Unit_Per_Hour / ($this->g_standard_time==0?0:$this->g_standard_time) );
        else
            return (($this->g_standard_time==0?0:$this->g_standard_time)==0?0:$this->aoi_good_include_repeat_qty()*$this->g_Unit_Per_Hour / ($this->g_standard_time==0?0:$this->g_standard_time) );
    }
    //實際工時效率
    public function actual_time_capacity()
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return ($this->g_hmi_input-$this->effect_capacity());
        else    
            return ($this->aoi_input_include_repeat_qty()-$this->effect_capacity());
    }
    //OEE=生產稼動率*產能效率*制程良率
    public function OEE()
    {
        if($this->g_now_dbname==$this->g_dbname3)
            return ($this->produce_availability1()*$this->Performance()*$this->hmi_good_percent());
        else
            return ($this->produce_availability1()*$this->Performance()*$this->aoi_process_good_percent());
    }
    //TEEP=管理稼動率(投入工時/標準工時)*OEE
    public function TEEP()
    {
        return ($this->manage_availability1()*$this->OEE());
    }     
    //工時損失率
    public function loss_availability()
    {
        return ($this->input_time()==0?0:($this->loss_time()/$this->input_time()));
    }
    //實際工時(分)
    public function actual_time1()
    {
        return ($this->g_Time_loss_rate_denominator==0?0:($this->g_Time_loss_rate_molecular/$this->g_Time_loss_rate_denominator));
    }
    
    /** 定義Aoi公式 **/
    public function aoi_good_include_repeat_qty() ##計算AOI 良品數(含複判)=良品數+良品數(複判)
    {
       return $this->g_aoi_good + $this->g_aoi_good_repeat ;
    }
    public function aoi_bad_include_repeat_qty() ##計算AOI 不良數(含複判)=不良數+不良數(複判)
    {
       return $this->g_aoi_bad + $this->g_aoi_bad_repeat ;
    }    
    public function aoi_input_qty() ##計算AOI: 投入數量=良品+不良品
    {
       return $this->g_aoi_good + $this-> g_aoi_bad ;
    }
    public function aoi_input_include_repeat_qty() ##計算AOI: 投入數量(含複判)=良品+良品(複判)+不良品+不良品(複判)
    {
       return $this->aoi_good_include_repeat_qty() + $this->aoi_bad_include_repeat_qty() ;
    }        
    public function aoi_input_only_repeat_qty() ##計算AOI: 投入數(複判)=良品數(複判)+不良品數(複判)
    {
       return $this->g_aoi_good_repeat + $this->g_aoi_bad_repeat ;
    }
    public function aoi_bad_percent() ##計算AOI: 不良率=不良/投入
    {
       return  ($this->aoi_input_qty()==0?0:($this->g_aoi_bad/$this->aoi_input_qty())) ;
    } 
    public function aoi_bad_station_percent() ##計算AOI: 不良率-by工站=某工站之不良品數/投入數
    {
       return ($this->aoi_input_qty()==0?0:($this->g_aoi_bad_station/$this->aoi_input_qty())) ;
    }
    public function aoi_bad_repeat_percent() ##計算AOI: 不良(複判)率=不良(複判)/投入(含複判)
    {
       return  ($this->aoi_input_include_repeat_qty()==0?0:($this->g_aoi_bad_repeat/$this->aoi_input_include_repeat_qty())) ;
    }
    public function aoi_bad_inclue_repeat_percent() ##計算AOI: 不率良(含複判)=不良(含複判)/投入(含複判) EX:檢測工站 -- 傳入分母投入(含複判)指定值
    {
       return  ($this->g_aoi_input_include_repeat==0?0:($this->aoi_bad_include_repeat_qty()/$this->g_aoi_input_include_repeat)) ;
    }      
    public function aoi_process_good_percent() ##計算AOI: 製程良率=良品數/投入數
    {
       return  ($this->aoi_input_qty()==0?0:($this->g_aoi_good/$this->aoi_input_qty())) ;
    }
    public function aoi_process_good_only_repeat_percent() ##計算AOI: 製程良率(複判)=良品數(複判)/投入數(複判)
    {
       return  ($this->aoi_input_only_repeat_qty()==0?0:($this->g_aoi_good_repeat/$this->aoi_input_only_repeat_qty())) ;
    }   
    public function aoi_process_good_include_repeat_percent() ##計算AOI: 製程良率(含複判)=(良品數+良品數(複判))/投入數(含複判)
    {
       return ($this->aoi_input_include_repeat_qty()==0?0:($this->aoi_good_include_repeat_qty()/$this->aoi_input_include_repeat_qty())) ;
    }
    public function aoi_identify() ##計算AOI: 模穴號辨識率(%)
    {
       return  ($this->aoi_input_qty()==0?0:($this->g_aoi_good_identify/$this->aoi_input_qty())) ;
    }
    
    /** 定義Hmi公式 **/
    public function hmi_good_qty() ##計算HMI: 良品=投入數量-不良品
    {
       return $this->g_hmi_input - $this->g_hmi_bad ;
    } 
    public function hmi_good_percent() ##計算HMI: 產能良率=良品/投入
    {
       return ($this->g_hmi_input==0?0:($this->hmi_good_qty()/$this->g_hmi_input)) ;
    }    
    public function hmi_bad_percent() ##計算HMI: 產能不良率=不良品/投入
    {
       return ($this->g_hmi_input==0?0:($this->g_hmi_bad/$this->g_hmi_input)) ;
    }       
        
        
        
    #--------------------------------------------------------
    # 取 cycle_time
    #--------------------------------------------------------       
    public function cycle_time_data($database_name,$fac,$project,$sele_date)
    {
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	//選擇連線資料庫
            die("無法使用資料庫");
            
        $sql = "select cycle_time from `cycle_time_setting` where project='" . $project . "' and date<='" . $sele_date . "' order by date desc limit 0,1";
        //echo  $sql;$this->g_debug_msg_array[0]=$sql;                 
        $rows       = $mysqli->query($sql);
        if ($rows->num_rows > 0) {
            $row        = $rows->fetch_assoc();
            $this->g_cycle_time= $row['cycle_time'];            
             
            mysqli_free_result($rows);
        }            
        $mysqli->close();
    }
    
    
    #--------------------------------------------------------
    # 取 cycle_time日期區間
    #--------------------------------------------------------       
    public function cycle_time_data_range($database_name,$fac,$project,$sele_date,$sele_date1)
    {
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";        
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	//選擇連線資料庫
            die("無法使用資料庫");
            
        $sql = "select date,cycle_time from `cycle_time_setting` where project='" . $project . "' and date >='" . $sele_date . "' and date <= '" . $sele_date1 . "' order by date desc";
        //echo  $sql."<br>"; ;       
        $rows       = $mysqli->query($sql);        
        //echo  "=".$rows->num_rows."<br>"; 
        if ($rows->num_rows > 0) {
          while($row = $rows->fetch_row())
              $this->g_cycle_time_arr[$row[0]] = $row[1];
          mysqli_free_result($rows);
        }
        $mysqli->close();
    }  

    #--------------------------------------------------------
    # AOI:  設備 
    # 備註: project+device_name+序號 => 檢測工站
    #-------------------------------------------------------- 
    public function measure_data1($fac,$project,$device_name,$measure_workno)
    {                
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
          	
        $username ="root";
        $password ="foxlink";
        $database_name = "aoi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	//選擇連線資料庫
            die("無法使用資料庫");
        
        if($project=="")
            $str_pro="";
        else
            $str_pro=" and project='".$project."' ";
        
        if($device_name=="")
            $str_device_name="";
        else
            $str_device_name=" and device_name='".$device_name."' ";
        
        if($measure_workno=="")
            $str_measure_workno="";
        else
            $str_measure_workno=" and measure_workno='".$measure_workno."' ";
        
        $sql = "select measure_workno,workno_chinese,project,device_name from measure_info where 1=1 ".$str_pro." ".$str_device_name." ".$str_measure_workno." order by project,device_name,workno_order asc  ";
        //echo $sql."<Br>";
       
        $rows = $mysqli->query($sql);         
        $index = 0;        
        while($row = $rows->fetch_row())
        {   
            if($index > 0 && $last_pro!=$row[2] || $last_dev!=$row[3])
               $index = 0;   
            
            $this->g_measure_info[$row[2]][$row[3]][$index]['measure_workno'] = $row[0];
            $this->g_measure_info[$row[2]][$row[3]][$index]['workno_chinese'] = $row[1];
            
            $last_pro=$row[2];
            $last_dev=$row[3];
            
            $index++;             
        }
        mysqli_free_result($rows);
        //print_r($this->g_measure_info);
        $mysqli->close();
    } 
 
        
    #-----------------------------------------------------------------------------------------------------------------------------------------------------
    # AOI-Data     
    # $choice      : 預設(1)
    # $extra_format: 如下
    #-----------------------------------------------------------------------------------------------------------------------------------------------------  
    /**  注  意：程式中format參數 不等於 table表的format
    #
    #    ※ $extra_format:0 => 要多呈現 [DN] 資料，目前只針對 $extra_format:1 有此功能
    #    
    #    ※ $extra_format:1 =>《TABLE: XXX_statistics_format:1》
    #        project + 日期 + 班別 + line + device_name + 工站 + 參數名稱(良品、不良、良品複判、不良品複判)
    #    
    #    ※ $extra_format:1 =>《TABLE: XXX_statistics_format:2》
    #        project + 日期 + 班別 + line + device_name + 工站 + 參數名稱(良品模穴號、不良模穴號)   
    #        
    #    ※ $extra_format:2 =>《TABLE: XXX_statistics_format:3》
    #        project + 日期 + 班別 + line + device_name + 工站 + 模號 + 參數名稱(良品、不良、良品複判、不良品複判) 
    #   
    #    ※ $extra_format:3 =>《TABLE: XXX_statistics_format:4》
    #        project + 日期 + 班別 + line + device_name + 工站 + [Day-Hour] + 參數名稱(良品、不良、良品複判、不良品複判)    
    #        
    #    ※ $extra_format:4 =>《TABLE: XXX_statistics_format:5/6/7》
    #        project + 日期 + 班別 + line + device_name + 工站 + 行號 + 參數名稱( periods / happen_times / {s、e} )
    # 
    #-----------------------------------------------------------------------------------------------------------------------------------------------------  
    **/
    public function aoi_project_rawdata_1($choice,$extra_format,$fac,$project,$device,$line,$shift,$sele1_date,$sele2_date,$findtable)
    {
        if(empty($this->g_measure_info))
            $this->measure_data1($fac,$project,$device); #查詢該設備所屬的檢測工站

        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";        
        $skip=0; 
        if(preg_match("/".$project."/i", $this->o_project_exception))    
            $database_name = "aoi_old";   
        else
            $database_name = "aoi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	#選擇連線資料庫
            die("無法使用資料庫");    
         
        $cdatetime = $this->aoi_sql_date_Statement($shift,$sele1_date,$sele2_date);
        $shift1=$this->aoi_shift_Statement($shift);
        //echo $cdatetime."=".$shift1."<br>";


        $aoi_good_arr = explode(";", $this->aoi_good);
        $aoi_bad_arr = explode(";", $this->aoi_bad);
        $aoi_column_arr= explode(",", $this->aoi_column);        
        $aoi_good_repeat_arr = explode(";", $this->aoi_good_repeat);
        $aoi_bad_repeat_arr = explode(";", $this->aoi_bad_repeat);        
        $aoi_good_identify_arr = explode(";", $this->aoi_good_identify);
        $aoi_bad_identify_arr = explode(";", $this->aoi_bad_identify);
                
        if(preg_match("/2/i", $extra_format) || preg_match("/3/i", $extra_format)){
            $old_date = "";
            $old_time = "";                              
        }
        if(preg_match("/4/i", $extra_format)){   //原5->4
            //$this->date_array_format_1($shift,$sele1_date); 
            $row_index = 0;
            $old_time = "";            
        }    
        
        if($line!="")
            $s_line=" and Line in (".$line.") ";
        else
            $s_line="";   
                
        $ct=count($this->g_measure_info[$project][$device]);
        //echo "=".$ct."<br>"; 
        
        for($i=0; $i<$ct; $i++)
        {  
            $sql = "select ".$this->aoi_column."
                    from `".$project."_".$this->g_measure_info[$project][$device][$i]['measure_workno']."_data".$findtable."` 
                    where device_name='".$device."' ".$s_line." and ".$cdatetime."   
                    order by ".$this->aoi_orderby."";
            //echo $sql."<br>";
            $this->g_debug_msg_array[1].=$sql."<br>";
            $shift2=$shift1;
            
            if(preg_match("/0/i", $extra_format)){
                $shift3=$this->g_shift_arr[2];  #需要有[DN]                
            }    
//            $shift4=$this->g_shift_arr[3];        
            $rows = $mysqli->query($sql); 
            //echo "=".$rows."<br>";
            if($rows)
            {    
                while($row = $rows->fetch_row())
                {
                    for($j=0; $j<count($aoi_column_arr); $j++)
                        ${$aoi_column_arr[$j]}=$row[$j];
                    $measure_workno=$this->g_measure_info[$project][$row[1]][$i]['measure_workno'];    
                    $now_date=$row[5]; 
                    $now_date_time=$row[5]." ".$row[6];
                    $hour=(int)date('H',  strtotime($row[5]." ".$row[6]));
                    $day=(int)date('d',  strtotime($row[5]." ".$row[6]));                    
                    
                    if($row[6] >= $this->o_start_time && $row[6] < $this->o_end_time ){     
                        if($shift1==$this->g_shift_arr[2])  #DN時要拆D和N
                            $shift2=$this->g_shift_arr[0];
                    }else{
                        if($shift1==$this->g_shift_arr[2])  #DN時要拆D和N
                            $shift2=$this->g_shift_arr[1];                        
                        if($row[6] >= "00:00:00" && $row[6] < $this->o_start_time ){
                            $now_date=date('Y-m-d',strtotime('-1 day',strtotime($now_date)));  #夜班若跨到隔天，所屬日期必須向前移一天                          
                        }
                    }
                    
                    #---------------------------------------------------------------------------------------------------------------------
                   
                    if(preg_match("/1/i", $choice)){                                
                        if(preg_match("/0|1/i", $extra_format))#宣告    
                        {
                            if(preg_match("/1/i", $extra_format)){
                                for($p=0;$p<6;$p++){ 
                                if(!isset($this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[$p]]))
                                        $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[$p]]=0;
                                }
                            }
                            if(preg_match("/0/i", $extra_format)){
                                for($p=0;$p<6;$p++){ 
                                    if(!isset($this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[$p]]))
                                            $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[$p]]=0;
                                }
                            }                          
                        }
                                                         
                        if(preg_match("/2/i", $extra_format) ){
                            if(preg_match("/2/i", $extra_format)){
                                if(strlen($row[3].$row[4]) < 2)
                                    $moldno = "無法辨識";
                                else
                                    $moldno = $row[3].$row[4];                                    
                            }                            
                            for($p=0;$p<4;$p++){
                                if(!isset($this->g_final_arr2[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$moldno][$this->c_aoi_param_arr[$p]]))
                                    $this->g_final_arr2[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$moldno][$this->c_aoi_param_arr[$p]]=0; 
                             }
                        } 
                        if(preg_match("/3/i", $extra_format) ){
                            for($p=0;$p<4;$p++){
                                if(!isset($this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[$p]]))
                                    $this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[$p]]=0;
                            }
                        }

                        if(preg_match("/4/i", $extra_format) && ($i==($ct-1)) ){                            
                            if($last_shift!=$shift2){
                                $row_index=0; 
                            }
                            if($last_date!=$now_date){
                                $row_index1=0; 
                            }
                            if($row_index!=0 && $row_index1!=0){
                                //echo $shift2."=".$old_time."=".$row[5]." ".$row[6]."<Br>";
                                $this->g_final_arr4[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$row_index-1]["s"] = $old_time;
                                $this->g_final_arr4[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$row_index-1]["e"] = $row[5]." ".$row[6];
                                $this->g_final_arr4[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$row_index-1][$this->c_event_param_arr1[0]] = strtotime($row[5]." ".$row[6]) - strtotime($old_time);                             
                            }                            
                            $old_time = $row[5]." ".$row[6];
                            $last_shift=$shift2;
                            $last_date=$now_date;
                            $row_index++; 
                            $row_index1++;                           
                        }
                           
                    } 
                       
                                      
                    ##----以下區塊是計算出該專案之良品、不良品數量等等---------------------------------------------------------------------------------------------------------------------
                    if(($i==($ct-1)) && ($aoi_column_arr[2]==$aoi_good_arr[0] && $row[2]==$aoi_good_arr[1])){
                       if(preg_match("/1/i", $choice)){
                            if(preg_match("/0|1/i", $extra_format)){
                                if(preg_match("/1/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[0]]+=1;
                                    if($aoi_good_identify_arr[0]==$aoi_column_arr[3] && $aoi_good_identify_arr[1]==$aoi_column_arr[4] && $row[3]!="" && $row[4]!=""){         
                                        $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;  
                                        #$this->g_final_identify_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;   
                                    }
                                }
                                if(preg_match("/0/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[0]]+=1;
                                    if($aoi_good_identify_arr[0]==$aoi_column_arr[3] && $aoi_good_identify_arr[1]==$aoi_column_arr[4] && $row[3]!="" && $row[4]!=""){         
                                        $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;  
                                        #$this->g_final_identify_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;   
                                    }
                                }
                            }
                            
                            if(preg_match("/2/i", $extra_format)){
                                if($row[2]!=2) ##不知道為什原程式要加這個判別
                                    $this->g_final_arr2[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$moldno][$this->c_aoi_param_arr[0]]+=1; 
                            } 
                            
                            if(preg_match("/3/i", $extra_format)){
                                $this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[0]]+=1;
                                 
                            }
                                                       
                        }                            
                    }else if($aoi_column_arr[2]==$aoi_bad_arr[0] && $row[2] == $aoi_bad_arr[1]){   

                        if(preg_match("/1/i", $choice)){                                
                            if(preg_match("/0|1/i", $extra_format)){
                                if(preg_match("/1/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[1]]+=1;
                                    if($aoi_good_identify_arr[0]==$aoi_column_arr[3] && $aoi_good_identify_arr[1]==$aoi_column_arr[4] && $row[3]!="" && $row[4]!=""){         
                                        $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1; 
                                        #$this->g_final_identify_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;   
                                    }                                        
                                } 
                                if(preg_match("/0/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[1]]+=1;
                                    if($aoi_good_identify_arr[0]==$aoi_column_arr[3] && $aoi_good_identify_arr[1]==$aoi_column_arr[4] && $row[3]!="" && $row[4]!=""){         
                                        $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1; 
                                        #$this->g_final_identify_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[4]]+=1;   
                                    }                                        
                                }     
                            }                           
                            
                            if(preg_match("/2/i", $extra_format)){
                                $this->g_final_arr2[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$moldno][$this->c_aoi_param_arr[1]]+=1; 
                            }
                            if(preg_match("/3/i", $extra_format)){
                                $this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[1]]+=1;
                                 
                            }                                 
                        }
                        
                    }else if(($i==($ct-1)) && ($aoi_column_arr[2]==$aoi_good_repeat_arr[0] && $row[2]==$aoi_good_repeat_arr[1])){
                    
                        if(preg_match("/1/i", $choice)){                                
                            if(preg_match("/0|1/i", $extra_format)){
                                if(preg_match("/1/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[2]]+=1;                           
                                    
                                }
                                if(preg_match("/0/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[2]]+=1;                           
                                    
                                }    
                            }                            
                            if(preg_match("/3/i", $extra_format)){
                                $this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[2]]+=1;
                                 
                            }                  
                        }
                                        
                    }else if($aoi_column_arr[2]==$aoi_bad_repeat_arr[0] && $row[2] == $aoi_bad_repeat_arr[1]){                    
                       
                        if(preg_match("/1/i", $choice)){
                            
                            if(preg_match("/0|1/i", $extra_format)){
                                if(preg_match("/1/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[3]]+=1;     
                               
                                }
                                if(preg_match("/0/i", $extra_format)){
                                    $this->g_final_arr1[$fac][$project][$now_date][$shift3][$row[0]][$row[1]][$measure_workno][$this->c_aoi_param_arr[3]]+=1;     
                               
                                }
                            }   
                            
                            if(preg_match("/3/i", $extra_format)){
                                $this->g_final_arr3[$fac][$project][$now_date][$shift2][$row[0]][$row[1]][$measure_workno][$day."-".$hour][$this->c_aoi_param_arr[3]]+=1;
                                 
                            }
                        }
                                         
                    }
                    
                    #--------------------------------------------------------------------------------------------------------------------                
                   
                }
                mysqli_free_result($rows);
            }
        }
        $mysqli->close();
    } 

    #------------------------------------------------------------------------------------------------------------------------------------------
    # AOI-Data       : 某工站之檢測NG項目 
    # $choice        :{ 暫無
    # $extra_format  :{ 0. 班別要做日+夜合併(DN)    
    # 使用範圍       : FOR 不良分析-檢測不良分析-細項分析
    #-------------------------------------------------------------------------------------------------------------------------------------------
    /**   
    #   ※ $extra_format: 無=>《TABLE: XXX_statistics_format:8》
    #        project + 日期 + 班別 + line + device_name + 工站 + 檢測名稱 + 參數名稱(良品、不良、良品複判、不良品複判)   
    #           
    # -----------------------------------------------------------------------------------------------------------------------------------------------------  
    **/
    public function aoi_project_rawdata_2($choice,$extra_format,$fac,$project,$device,$line,$shift,$sele1_date,$sele2_date,$findtable,$measure_workno,$item_coder_sql_arr,$item_order_arr)
    {        
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";
        $database_name = "aoi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	#選擇連線資料庫
            die("無法使用資料庫");
        
        //echo (empty($this->g_measure_info))."<Br>";        
        if(empty($this->g_measure_info))
            $this->measure_data1($fac,$project,$device); #查詢該設備所屬的檢測工站
  
        $cdatetime = $this->aoi_sql_date_Statement($shift,$sele1_date,$sele2_date);
        //echo $sele1_date."=".$sele2_date."=".$cdatetime."<Br>";
        $shift1=$this->aoi_shift_Statement($shift);  
        $shift2=$shift1;        
        if(preg_match("/0/i", $extra_format)){ //2->0
            $shift3=$this->g_shift_arr[2];  #特殊情況_傳回資料是日+夜合併             
        }
        $aoi_bad_arr = explode(";", $this->aoi_bad);
        $aoi_bad_repeat_arr = explode(";", $this->aoi_bad_repeat); 
        if($aoi_bad_arr[0]==$aoi_bad_repeat_arr[0]){
            $sql_1=" ".$aoi_bad_arr[0]." in (".$aoi_bad_arr[1].",".$aoi_bad_repeat_arr[1].")";            
        }        
        //print_r($this->g_measure_info)."<br>";
        //echo "line=".$line."<br>";
        
        $ct=count($item_order_arr[$project][$device]);//echo "=".$ct."<Br>";
        for($j=0; $j<$ct; $j++){   
            //echo $this->g_measure_info[$project][$device][$j]['measure_workno']."=".$device ."<Br>";
            if(isset($this->g_measure_info[$project][$device][$j]['measure_workno'])){
                $sub_sql=$item_coder_sql_arr[$project][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']];             
                $sql = "select  ".$sub_sql.",Code3,Code4,".$aoi_bad_arr[0]." ,line
                        from `".$project."_".$this->g_measure_info[$project][$device][$j]['measure_workno']."_Data".$findtable."` 
                        where device_name='".$device."' and Line in (".$line.")  and ".$sql_1." and ".$cdatetime;
                //echo $j."=".$sql."<Br>";                
                $item_order_ct=count($item_order_arr[$project][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']]);  
                $sub_sql_ct = (int)count(explode(",", $item_coder_sql_arr[$project][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']]));  
                $rows = $mysqli->query($sql);
                while($row = $rows->fetch_row()){
                    for($i=0; $i<$item_order_ct; $i++){ 
                        $measure_item = $item_order_arr[$project][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$i];  
                        if($measure_item=="")
                            break;
                        //echo $i."=".$this->g_measure_info[$project][$device][$j]['measure_workno']."=". $measure_item."<Br>";
                        $tmp_line=$row[$sub_sql_ct+3];                                                                          
                        $now_date=$row[$sub_sql_ct];                                
                        if($row[$sub_sql_ct+1] >= $this->o_start_time && $row[$sub_sql_ct+1] < $this->o_end_time ){     
                            if($shift1==$this->g_shift_arr[2])
                                $shift2=$this->g_shift_arr[0];
                        }else{
                            if($shift1==$this->g_shift_arr[2])
                                $shift2=$this->g_shift_arr[1];                    
                            if($row[$sub_sql_ct+1] >= "00:00:00" && $row[$sub_sql_ct+1] < $this->o_start_time ){
                                $now_date=date('Y-m-d',strtotime('-1 day',strtotime($now_date)));
                            }   
                        }
                         //echo $item_order_arr[$project][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$i]."=".$this->g_measure_info[$project][$device][$j]['measure_workno']."<Br>";
                         
                        if(!isset($this->g_final_arr[$fac][$project][$now_date][$shift2][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item])){    
                            $this->g_final_arr[$fac][$project][$now_date][$shift2][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]]=0;
                            $this->g_final_arr[$fac][$project][$now_date][$shift2][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[3]]=0;
                        }
                        
                        if(preg_match("/0/i", $extra_format)){ 
                            if(!isset($this->g_final_arr[$fac][$project][$now_date][$shift3][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]])){
                                $this->g_final_arr[$fac][$project][$now_date][$shift3][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]]=0;
                                $this->g_final_arr[$fac][$project][$now_date][$shift3][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[3]]=0;
                            }
                        }    
                        // echo $row[$sub_sql_ct]."=". $row[$sub_sql_ct+1]."=". $row[$sub_sql_ct+2]."=". $row[$sub_sql_ct+3]."<Br>"; 
                         
                		$flag=true;
                        if(!is_null($row[$i])){
                            $measure_result = (int)$row[$i];  #檢測結果，1:良品 , 0:不良品                    
                			if($measure_result == 0){        			                            
                				//echo $row[$sub_sql_ct]."=". $row[$sub_sql_ct+1]."=". $row[$sub_sql_ct+2]."=". $row[$sub_sql_ct+3]."<Br>"; 
                         
                                if($aoi_bad_arr[1]==$row[$sub_sql_ct+2]){        				     
                                    $this->g_final_arr[$fac][$project][$now_date][$shift2][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]]++;
                                    
                                    if(preg_match("/0/i", $extra_format)){
                                        $this->g_final_arr[$fac][$project][$now_date][$shift3][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]]++;
                                    }                                    
                                    //echo $j."=".$i."=". $this->g_final_arr[$fac][$project][$now_date][$shift2][$line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[1]]."<Br>";
                                }
                                if($aoi_bad_repeat_arr[1]==$row[$sub_sql_ct+2]){                            
                                    $this->g_final_arr[$fac][$project][$now_date][$shift2][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[3]]++;
                                    if(preg_match("/0/i", $extra_format)){
                                        $this->g_final_arr[$fac][$project][$now_date][$shift3][$tmp_line][$device][$this->g_measure_info[$project][$device][$j]['measure_workno']][$measure_item][$this->c_aoi_param_arr[3]]++;
                                    }                                    
                                
                                }                        
                				$flag=false;
                			}
                        }
                		if($flag==false){
                			$flag=true;
                			break;
                		}
                    }
                }
                mysqli_free_result($rows);
            }
         }
        $mysqli->close();
    }
    
    
    
    #------------------------------------------------------------------------------------------------------------
    # 來源EVENT 
    # $rawdata_type      :空  、 1.多專案
    # $choice            :暫無用
    # $extra_format      :暫無用
    # 備註：
    # -------------------------------------------------------------------------------------------------------------    
    public function event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$category,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {   
        //echo $shift."<br>";
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";
        //$database_name = "aoi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	#選擇連線資料庫
            die("無法使用資料庫");
        if($line==""){
            $str_line="";
            $orderbysql="order by line";
        }else{            
            if(preg_match("/'/i", $line)){
                $str_line=" and line in (".$line.") ";
                $orderbysql="order by line";
            }else
                $str_line=" and line = '".$line."' ";
        }
        
        if($category==""){
            $str_category="";
        }else{
            $category_exc_arr=explode("-",$this->c_event_param_arr[10][1]);
            if(strcmp($category,$this->c_event_param_arr[10][1])==0){
                $str_category=" and (category>=".$category_exc_arr[0]." and category<=".$category_exc_arr[1].") ";
            }else
                $str_category=" and category in (".$category.") ";
        }
        if($message==""){
            $str_message="";
        }else{
            $str_message=" and message = '".$message."' ";
        }
        
        if($device==""){
            $str_device="";
        }else{           
            $dev_ct=0;
            $dev_arr = explode(",", $device);
            foreach($dev_arr as $v => $k)
            {
                if($dev_ct==0)
                    $t_dev = "'".$k."'";
                else
                    $t_dev .= ",'".$k."'";
                $dev_ct++;  
            }
            //echo $t_dev."<br>";
            $str_device=" and device_name in (".$t_dev.") ";
        }
        //$str_device=" and device_name = '".$device."' ";
        
        $cdatetime = $this->event_sql_date_Statement($shift,$sele_date1,$sele_date2);
              
        $sql = "select line,category,start_time,end_time,message,device_name 
                from `".$project."_event".$findtable."` 
                where 1=1 ".$str_device."   ".$str_line." ".$str_category." ".$str_message."  
                and end_time is not null ".$cdatetime."  ".
                $orderbysql;
        // echo $sql."<br>";  
        $this->g_debug_msg_array[2]=$sql."<Br>".$database_name."<Br>";  
        $i=0;
        $event_rows = $mysqli->query($sql);
        if($event_rows->num_rows > 0)
        {
            while($row = $event_rows->fetch_row())
            {               
                if($rawdata_type==1){
                    
                    $this->g_tmp_event_rawdata_array[$project][$this->c_event_param_arr1[2]] = $i;                
                    $this->g_tmp_event_rawdata_array[$fac][$project][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[3]][$i]=$row[2];  #Start Time
                    $this->g_tmp_event_rawdata_array[$fac][$project][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[4]][$i]=$row[3];  #End Time
                    $this->g_tmp_event_rawdata_array[$fac][$project][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[5]][$i]=$row[4];  #Message
                }else{
                    
                    $this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]] = $i;                
                    $this->g_tmp_event_rawdata_array[$fac][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[3]][$i]=$row[2];  #Start Time
                    $this->g_tmp_event_rawdata_array[$fac][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[4]][$i]=$row[3];  #End Time
                    $this->g_tmp_event_rawdata_array[$fac][$row[0]][$row[5]][$row[1]][$this->c_event_param_arr1[5]][$i]=$row[4];  #Message
                        
                
                }
                
                $i++;
            }
            mysqli_free_result($event_rows);           
        }
        
         
        $mysqli->close();       
    }    
    
    #-------------------------------------------------------------------------------------------------------------------------------------------------
    # 來源為 event - 預存 
    # $choice        :{ 1.project+班別+日期+LINE+device_name+category+參數1(->秒數/次數)+參數2(->msg)          } 
    #                 { 2.project+班別+日期+LINE+device_name+category+參數1(->Day-Hour)+參數2(->秒數)          } 
    # $extra_format  : 
    # 使用範圍       :{目前預存使用} 
    #                 
    # --------------------------------------------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_7($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$start_time,$end_time,$date_array,$date_array1,$findtable)
    {   
        //$tmp_merge_cate="201";
        
        
        unset($this->g_tmp_event_rawdata_array);
        $this->event_rawdata($database_name,"1",$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
        //print_r($this->g_tmp_event_rawdata_array);echo "<hr>";
        
        unset($this->g_s_day_array);
        unset($this->g_e_day_array);   
        for($p=0;$p<2;$p++){
            if($sele_date2!=$sele_date1){
                $diff=round((strtotime($sele_date2)-strtotime($sele_date1))/3600/24)-1;
                if($diff<0)
                    $diff=0;     
            }else{
                $diff=0; 
            }            
            $this->date_array_format_5($this->g_shift_arr[$p],$sele_date1,$diff);
        }
       // echo $this->g_shift_arr[$p]."=". $sele_date1."=". $sele_date2."=".$diff."=".max($this->g_s_day_array) ."<br>";

//$this->g_debug_msg_array[10]=$this->g_s_day_array;
//$this->g_debug_msg_array[20]=$this->g_e_day_array;
//print_r($this->g_debug_msg_array[10]);echo "=><Br><hr>";
//print_r($this->g_debug_msg_array[20]);echo "=><Br><hr>";
//
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:             1         2         3        4
        #       project  line   device    category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉ 
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                $tmp_ct=$this->g_tmp_event_rawdata_array[$key][$this->c_event_param_arr1[2]]; 
                //echo $tmp_ct."<Br>";
                foreach($data_arr as $key1 => $data_arr1)  
                {
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {
                        foreach($data_arr2 as $key3 => $data_arr3)  
                        {   
                            if(preg_match("/1/i", $choice))
                            {
                                foreach($date_array as $k => $v)
                                {                            
                                    for($j=0;$j<=$tmp_ct;$j++)
                                    {
                                        if(isset($data_arr3["s"][$j]))
                                        {
                                            //if((int)$key3<200) -> 預存不要存
//                                                $strTF=1;                                    
//                                            else
//                                                $strTF=0; 
                                            $tmp_msg = strtoupper($data_arr3["msg"][$j]);
                                            for($s=0;$s<2;$s++){
                                                if(!isset($this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]]=0;
                                                }
                                                if(!isset($this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[1]])){
                                                    $this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[1]]=0;
                                                }                                            
                                                //if($strTF==1){
//                                                    if(!isset($this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]])){
//                                                        $this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]]=0;
//                                                    }
//                                                    if(!isset($this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[1]])){
//                                                        $this->g_event_arr[$fac][$key][$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[1]]=0;
//                                                    }  
//                                                }                                            
                                            }                                            
                                            
                                            #日-夜班起迄時間   
                                            $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                            $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                            $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                            $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;                                        
                                            
                                            for($p=0;$p<2;$p++){
                                                
                                                $t_date_time1=$t_datetime_arr[$p][0];
                                                $t_date_time2=$t_datetime_arr[$p][1];
                                                
                                                #期間秒數
                                                if( $data_arr3["e"][$j] > $t_date_time1 && $data_arr3["s"][$j] < $t_date_time2){
                                                    if($data_arr3["e"][$j] < $t_date_time2){                                                    
                                                        if($data_arr3["s"][$j] > $t_date_time1){             
                                                            
                                                            $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j]) - strtotime($data_arr3["s"][$j]);
                                                            //if($strTF==1){
//                                                                $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j]) - strtotime($data_arr3["s"][$j]);
//                                                            }
                                                            
                                                        }else{                                    			
                                                            
                                                            $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j]) - strtotime($t_date_time1);
                                                		    //if($strTF==1){
//                                                		      $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j]) - strtotime($t_date_time1);
//                                                		      
//                                                		    }
                                                        }        
                                                        
                                                	}else{
                                                       if($data_arr3["s"][$j] > $t_date_time1){   
                                                            
                                                            $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr3["s"][$j]);
                                               		        //if($strTF==1){
//                                                		      $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr3["s"][$j]);
//                                               		         
//                                                		    }
                                                        }else{                                    			
                                                            
                                                            $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                              		        //if($strTF==1){
//                                                                $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr[10][1]][$data_arr3["msg"][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
//                                              		          
//                                                		    }
                                                        }
                                                	}
                                                    
                                                    #次數
                                                    $this->g_event_arr[$fac][$key][$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$key3][$tmp_msg][$this->c_event_param_arr1[1]] += 1;
                                                   
                                                    
                                                }
                                                
                                            }                                        
                                            		  
                                                                               
                                        }
                                    }
                                }
                            }
                            
                            #BY Hour 期間秒數##############################################################################
                            if(preg_match("/2/i", $choice))
                            {   
                               //echo $tmp_ct."<Br>";
                               for($j=0;$j<=$tmp_ct;$j++){                                   
                                    if(isset($data_arr3["s"][$j])){
                                        for($p=0;$p<2;$p++){                                      
                                           foreach($this->g_s_day_array[$this->g_shift_arr[$p]] as $k => $day_array){
                                                //echo $this->g_shift_arr[$p]."==".$k."==". count($this->g_s_day_array[$this->g_shift_arr[$p]]) ."==".count($day_array)."==".max($this->g_s_day_array[$this->g_shift_arr[$p]][$k]) ."<hr>";
                                                $ct1=count($day_array);
                                                for($m=0;$m<$ct1;$m++){  
                                                    //echo $key3 ."=". $now_date  ."=".$this->g_shift_arr[$p] ."=".$k  ."=".$m ."=====".  $this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]."====".$this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m]."====".$data_arr3["s"][$j] ."====".$data_arr3["e"][$j]  ."<hr>";
                                                    $day=(int)date('d',  strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]));                    
                                                    $hr=(int)date('H',  strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]));
                                                    $now_date=$k;//date('Y-m-d',  strtotime($this->g_s_day_array[$k][$m]));                                                
                                                    //echo $this->g_shift_arr[$p]."0=". $hour."===".$data_arr3["e"][$j].">".$this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]."===". $data_arr3["s"][$j]."<". $this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m] ."<br>";
                                                    if(($data_arr3["e"][$j]>$this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]) && ($data_arr3["s"][$j]<$this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m])) #有跨越此鐘頭的才處理
                                                    {
                                                        //echo $this->g_shift_arr[$p]."0=". $hour."===". $data_arr3["s"][$j]."===".$data_arr3["e"][$j]."===".$this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]."===". $this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m] ."<br>";
                                                        
                                                        if($data_arr3["e"][$j]<$this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m]) #結束時間小於此鐘頭結束時間
                                                        {
                                                            if($data_arr3["s"][$j]>$this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]) #開始時間大於此鐘頭開始時間
                                                            {
                                                                $this->g_event_arr2[$fac][$key][$this->g_shift_arr[$p]][$now_date][$key1][$key2][$key3][$day."-".$hr][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j])-strtotime($data_arr3["s"][$j]);
                                                                //echo $this->g_shift_arr[$p]."1=". $hour."===". $data_arr3["s"][$j]."===".$data_arr3["e"][$j]."==data3e-data3s===".(strtotime($data_arr3["e"][$j])-strtotime($data_arr3["s"][$j]))."<br>";
                                                            }
                                                            else #以此鐘頭開始時間當開始時間
                                                            {                                                
                                                                $this->g_event_arr2[$fac][$key][$this->g_shift_arr[$p]][$now_date][$key1][$key2][$key3][$day."-".$hr][$this->c_event_param_arr1[0]] += strtotime($data_arr3["e"][$j])-strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]);   
                                                                //echo $this->g_shift_arr[$p]."2=". $data_arr3["s"][$j]."===".$data_arr3["e"][$j]."==data3e-s===".(strtotime($data_arr3["e"][$j])-strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]))."<br>";
                                                            }
                                                        }
                                                        else #以鐘頭結束時間當結束時間
                                                        {
                                                            if($data_arr3["s"][$j]>$this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]) #開始時間大於此鐘頭開始時間
                                                            {                                                
                                                                $this->g_event_arr2[$fac][$key][$this->g_shift_arr[$p]][$now_date][$key1][$key2][$key3][$day."-".$hr][$this->c_event_param_arr1[0]] += strtotime($this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m])-strtotime($data_arr3["s"][$j]);
                                                                //echo $this->g_shift_arr[$p]."3=". $data_arr3["s"][$j]."===".$data_arr3["e"][$j]."==e-data3s===".(strtotime($this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m])-strtotime($data_arr3["s"][$j]))."<br>"; 
                                                            }
                                                            else #以此鐘頭開始時間當開始時間
                                                            {
                                                                $this->g_event_arr2[$fac][$key][$this->g_shift_arr[$p]][$now_date][$key1][$key2][$key3][$day."-".$hr][$this->c_event_param_arr1[0]] += strtotime($this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m])-strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]);
                                                                //echo $this->g_shift_arr[$p]."4=". $hour."===". $data_arr3["s"][$j]."===".$data_arr3["e"][$j]."==e-s===".(strtotime($this->g_e_day_array[$this->g_shift_arr[$p]][$k][$m])-strtotime($this->g_s_day_array[$this->g_shift_arr[$p]][$k][$m]))."<br>";
                                                            }
                                                        }
                                                    }
                                                }   
                                            }
                                        }
                                    }
                                }                              
                                
                            }
                            
                        }   
                    }
                }       
            }
        }
    }
    
    
    #-------------------------------------------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式六 - 
    # $choice        :{ 1.班別+日期+LINE+category   2.班別+序號:日期(格式:小時)+category
    # $extra_format  : 暫無用
    # 使用範圍       :{  $choice=1.產能分析-產能標準表 / Official Report   
    #                    $choice=2. 產能分佈圖for hour / Official Report-產能效率     
    #                    
    #                 } 
    # --------------------------------------------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_6($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$start_time,$end_time,$date_array,$date_array1,$findtable)
    {   
        $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
        //print_r($this->g_tmp_event_rawdata_array);echo "==><Br><br>";        
          
        $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];        
        
        $tmp_shift = $this->aoi_shift_Statement($shift);    
        //$this->g_debug_msg_array[10]=   $tmp_shift; 
        if(preg_match("/2/i", $choice)){            
            $this->date_array_format_1($shift,$sele_date1);         
        }        
        //$this->g_debug_msg_array[0]= $this->g_s_day_array;
        
        if(preg_match("/3/i", $choice)){
             $tmp_s = strtotime($sele_date1." ".$start_time);
             $tmp_e = strtotime($sele_date2." ".$end_time);             
              //$this->g_event_arr[5] .=$tmp_s."=".$tmp_e ."=". $start_time."=".$end_time ."<br>";            
        }
        //if(preg_match("/0/i", $choice)){
//             $shift3="F";   
//        }
        
           
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:            1         2             3
        #       line   device    category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉ 
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach($data_arr as $key1 => $data_arr1)  
                {
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {   
                        if((int)$key2>=1&&(int)$key2<=199)
                            $strTF=1;                                    
                        else
                            $strTF=0;
                        if(preg_match("/1/i", $choice))
                        {
                            foreach($date_array as $k => $v)
                            {                            
                                for($j=0;$j<=$tmp_ct;$j++)
                                {
                                    if(isset($data_arr2["s"][$j]))
                                    {                                        
                                        for($s=0;$s<2;$s++){
                                            if(!isset($this->g_event_arr[1][$this->g_shift_arr[$s]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[1][$this->g_shift_arr[$s]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]]=0;
                                                if($strTF==1){
                                                    if(!isset($this->g_event_arr[1][$this->g_shift_arr[$s]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]))
                                                        $this->g_event_arr[1][$this->g_shift_arr[$s]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;
                                                }    
                                            }                                           
                                        }         
                                            
                                        $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                        $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                        $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                        $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;                                        
                                        
                                        for($p=0;$p<2;$p++){
                                            $t_date_time1=$t_datetime_arr[$p][0];
                                            $t_date_time2=$t_datetime_arr[$p][1];
                                                                                                              
                                            if( $data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){        
                                                //$this->g_debug_msg_array[1] .= $data_arr2["s"][$j]."===".$data_arr2["e"][$j].  "=========".$t_date_time1 ."====".$t_date_time2."<br>";
                                                    
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                            		    if($strTF==1){
                                                            $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]+= strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        }
                                                    }else{                                    			
                                                        $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                            		    if($strTF==1){                                            		      
                                                            $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                            		    }    
                                                    }
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                            		    if($strTF==1){
                                                            $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                            		      
                                            		    }
                                                    }else{                                    			
                                                        $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                          		        if($strTF==1){
                                                            $this->g_event_arr[1][$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                          		        
                                            		    }
                                                    }
                                            	} 
                                            }    
                                        }
                                        
                                                                              
                                    }
                                }
                            }    
                        } 
                        ###這一段還可以再優化
                        if(preg_match("/2/i", $choice))
                        {                             
                            foreach ($this->g_s_day_array as $k => $hour)
                            {
                                for($j=0;$j<=$tmp_ct;$j++)
                                {                                    
                                    if(isset($data_arr2["s"][$j]))
                                    {                                        
                                        if(($data_arr2["e"][$j]>$this->g_s_day_array[$k]) && ($data_arr2["s"][$j]<$this->g_e_day_array[$k])) #有跨越此鐘頭的才處理
                                        {
                                            if($data_arr2["e"][$j]<$this->g_e_day_array[$k]) #結束時間小於此鐘頭結束時間
                                            {
                                                if($data_arr2["s"][$j]>$this->g_s_day_array[$k]) #開始時間大於此鐘頭開始時間
                                                {
                                                    $this->g_event_arr[2][$tmp_shift][$k][$key2] += strtotime($data_arr2["e"][$j])-strtotime($data_arr2["s"][$j]);
                                                    if($strTF==1)
                                                        $this->g_event_arr[2][$tmp_shift][$k][$this->c_event_param_arr[10][1]] += strtotime($data_arr2["e"][$j])-strtotime($data_arr2["s"][$j]);
                                                        
                                                }
                                                else #以此鐘頭開始時間當開始時間
                                                {                                                
                                                    $this->g_event_arr[2][$tmp_shift][$k][$key2] += strtotime($data_arr2["e"][$j])-strtotime($this->g_s_day_array[$k]);   
                                                    if($strTF==1)
                                                        $this->g_event_arr[2][$tmp_shift][$k][$this->c_event_param_arr[10][1]] += strtotime($data_arr2["e"][$j])-strtotime($this->g_s_day_array[$k]);   
                                                    
                                                }
                                            }
                                            else #以鐘頭結束時間當結束時間
                                            {
                                                if($data_arr2["s"][$j]>$this->g_s_day_array[$k]) #開始時間大於此鐘頭開始時間
                                                {                                                
                                                    $this->g_event_arr[2][$tmp_shift][$k][$key2] += strtotime($this->g_e_day_array[$k])-strtotime($data_arr2["s"][$j]);
                                                    if($strTF==1)
                                                        $this->g_event_arr[2][$tmp_shift][$k][$this->c_event_param_arr[10][1]] += strtotime($this->g_e_day_array[$k])-strtotime($data_arr2["s"][$j]);
                                                     
                                                }
                                                else #以此鐘頭開始時間當開始時間
                                                {
                                                    $this->g_event_arr[2][$tmp_shift][$k][$key2] += strtotime($this->g_e_day_array[$k])-strtotime($this->g_s_day_array[$k]);
                                                    if($strTF==1)
                                                        $this->g_event_arr[2][$tmp_shift][$k][$this->c_event_param_arr[10][1]] += strtotime($this->g_e_day_array[$k])-strtotime($data_arr2["s"][$j]);
                                                    
                                                }
                                            }
                                            
                                        }                                    
                                    }
                                }
                             }
                         }                          
                         
                        ###這一段可用上面取代
//                        if(preg_match("/3/i", $choice))
//                        {   
//                            for($j=0;$j<=$tmp_ct;$j++)
//                            {
//                                $start_second = strtotime($data_arr2["s"][$j]);
//                                $end_second   = strtotime($data_arr2["e"][$j]);                                                               
//                                   
//                                if ($start_second < $tmp_s) {
//                                    $start_second = $tmp_s;                                                          
//                                }
//                                if ($end_second > $tmp_e) {
//                                    $end_second = $tmp_e;                                                         
//                                } 
//                                
//                               // $this->g_event_arr[5] .=   $start_second ."=". $end_second ."=". $data_arr2["s"][$j] ."=". strtotime($data_arr2["s"][$j]) ."=".  $data_arr2["e"][$j] ."=". strtotime($data_arr2["e"][$j])  . "<br>";
//                                                   
//                                $ts  = date('H', strtotime($data_arr2["s"][$j]));
//                                $te  = date('H', strtotime($data_arr2["e"][$j]));
//                                $ts_ = date('j-G', strtotime($data_arr2["s"][$j]));
//                                $te_ = date('j-G', strtotime($data_arr2["e"][$j]));                               
//                                
//                                
//                                if(!isset($this->g_event_arr[3][$tmp_shift][$ts_][$key2] ))
//                                {
//                                    $this->g_event_arr[3][$tmp_shift][$ts_][$key2] = 0;
//                                    $this->g_event_arr[3][$tmp_shift][$te_][$key2] = 0;
//                                }
//                            
//                                if ($ts != $te) {
//                                    $t1 = intval($ts);
//                                    $t3 = intval($te);
//                                    if (($t3 - $t1) == 1) {
//                                        $tm = strtotime(substr($data_arr2["e"][$j], 0, 11) . $te . ":00:00");
//                                        $this->g_event_arr[3][$tmp_shift][$ts_][$key2] += ($tm - $start_second);
//                                        $this->g_event_arr[3][$tmp_shift][$te_][$key2] += ($end_second - $tm);
//                                    } else {
//                                        
//                                        $t2 = $t1 + 1;
//                                        if ($t2 < 10)
//                                            $t2 = '0' . $t2;
//                                        $t1_tm = strtotime(substr($data_arr2["s"][$j], 0, 11) . $t2 . ":00:00");
//                                        $t3_tm = strtotime(substr($data_arr2["e"][$j], 0, 11) . $te . ":00:00");
//                                        $this->g_event_arr[3][$tmp_shift][$ts_][$key2] += ($t1_tm - $start_second);
//                                        $this->g_event_arr[3][$tmp_shift][$te_][$key2] += ($end_second - $t3_tm);
//                                        
//                                        //$cch1 .= $t1_tm."=". $data_arr2["s"][$j]."=".$data_arr2["e"][$j] ."=".$t3_tm. "<br>";
//                    
//                                        $t2_tm = $t1_tm;
//                                        for ($i = $t2; $i < $t3; $i++) {
//                                            $t2_ = date('j-G', $t2_tm);
//                                            $this->g_event_arr[3][$tmp_shift][$t2_][$key2] += $this->g_Unit_Per_Hour; 
//                                            $t2_tm += $this->g_Unit_Per_Hour;  
//                                        }
//                                        
//                                    }
//                                } else {
//                                    $this->g_event_arr[3][$tmp_shift][$ts_][$key2] += ($end_second - $start_second);
//                                    
//                                    //$this->g_event_arr[5] = $tmp_s ."=".$ts."=".$te ."=".  $data_arr2["s"][$j]."=".$data_arr2["e"][$j]."=". $start_second."=".$end_second. "<br>";
//                                }
//                            }
//                        }
                        
                        
                        
                    }
                }       
            }
        }
    }
  
    
    #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式五
    # $choice        :{   1.班別+日期+category+參數名稱(取秒數)、2.班別+日期+category+參數名稱(取次數)、3.班別+日期+category(1-199)+參數名稱(msg)+參數名稱(取秒數/取次數)->異常警報明細 } 
    #                     5.班別+日期+category+參數名稱(starttime)+參數名稱(endtime)+參數名稱(msg)+參數名稱(取秒數)
    #                     0.要多呈現 [DN] 資料，目前只針對 $choice:1/2 有此功能
    # $extra_format  : 暫無 
    # 使用範圍      ：稼動分析-稼動工時分析-實際工時.投入工時.損失工時.除外工時   
    # -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_5($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {   
         //print_r($cate_array);echo "<Br><br>";        
        if( !empty($merge_cate_array) && isset($merge_cate_array)){
             $p=0;
             foreach($merge_cate_array as $key => $data ) 
             {
                if($p==0)
                    $tmp_merge_cate=$data;
                else
                   $tmp_merge_cate.=",".$data; 
                $p++;
             }                
         }     
         // echo   $tmp_merge_cate."<Br><br>";      
        //echo   $project.$device."<Br><br>";      
        $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
          //print_r($this->g_tmp_event_rawdata_array);echo "==><Br><br>";//echo $tmp_merge_cate."<Br><br>";          
        if(preg_match("/0/i", $choice))
            $shift1 = $this->g_shift_arr[2];
            
        $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];        
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:            1         2             3
        #       line   device    category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉ 
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach($data_arr as $key1 => $data_arr1)  
                {
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {   
                        foreach($date_array as $k => $v)
                        {                            
                            for($j=0;$j<=$tmp_ct;$j++)
                            {
                                if(isset($data_arr2["s"][$j]))
                                {
                                    if((int)$key2>=1&&(int)$key2<=199)
                                        $strTF=1;                                    
                                    else
                                        $strTF=0;  
                                    // echo ((int)$key2<200) ."=". gettype($key2)  ."=".$ct ."=".$v ."=". $j ."=".$key1 ."=".$key2."=". $data_arr1["s"][$j] ."=".  $data_arr1["e"][$j] ."=".$this->g_event_arr[$this->g_shift_arr[0]][$date_array[$k]]."<br>";  
                                    for($s=0;$s<2;$s++){
                                        if(preg_match("/1/i", $choice)){
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]]=0;
                                                if(preg_match("/0/i", $choice))
                                                    $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[0]]=0;
                                            
                                                
                                            }
                                            if($strTF==1){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;
                                                    if(preg_match("/0/i", $choice))
                                                        $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;
                                                   
                                                }                                      
                                            }
                                        } 
                                        if(preg_match("/2/i", $choice)){
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$this->c_event_param_arr1[1]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$this->c_event_param_arr1[1]]=0;
                                            }
                                            if($strTF==1){
                                                //echo $ct ."=".$v ."=". $j ."=".$key1 ."=".$key2."=".((int)$key2<200) ."<br>";                                            
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]]=0;
                                                }    
                                            }     
                                        }
                                        if(preg_match("/3/i", $choice)){                                        
                                            if($strTF==1){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]]=0;
                                                } 
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[1]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[1]]=0;
                                                }  
                                            }     
                                        }
                                        if(preg_match("/15/i", $choice)){
                                            if($strTF==1){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]]=0;
                                                }    
                                            }    
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key2][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]]=0;
                                            }	        
                                        }                                              
                                    }
                                                                        
                                    $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                    $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;

                                    for($p=0;$p<2;$p++){
                                        $t_date_time1=$t_datetime_arr[$p][0];
                                        $t_date_time2=$t_datetime_arr[$p][1];
                                        
                                        if($data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){ 
                                            if(preg_match("/0|1/i", $choice)){
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                        		        if(preg_match("/0/i", $choice))
                                                            $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                        		        
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                            if(preg_match("/0/i", $choice))
                                                                $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                            
                                        		        }
                                                    }else{                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        if(preg_match("/0/i", $choice))
                                                            $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                            if(preg_match("/0/i", $choice))
                                                                $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                            
                                                        }
                                            		}
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($date_array[$k]." ".$this->o_end_time) - strtotime($data_arr2["s"][$j]);
                                                        if(preg_match("/0/i", $choice))
                                                            $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($date_array[$k]." ".$this->o_end_time) - strtotime($data_arr2["s"][$j]);
                                                        
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            if(preg_match("/0/i", $choice))
                                                                $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            
                                                        }
                                            		}else{                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                        
                                                        if(preg_match("/0/i", $choice))
                                                            $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                        
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                            if(preg_match("/0/i", $choice))
                                                                $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                            
                                                        }    
                                                    }
                                            	}    
                                            }
                                            
                                            if(preg_match("/3/i", $choice)){
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                        		        
                                                    }else{                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        
                                            		}
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        
                                            		}else{                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                            
                                                    }
                                            	}
                                                
                                            }
                                            
                                            if(preg_match("/5/i", $choice)){
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                        		        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                        		        //echo $this->g_shift_arr[$p]."=".($this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]])."====1"."<br>";
                                                    }else{                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        
                                            		}
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        
                                            		}else{                                    			
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$data_arr2[$this->c_event_param_arr1[3]][$j]][$data_arr2[$this->c_event_param_arr1[4]][$j]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                               
                                                    }
                                            	}
                                            } 
                                            
                                            
                                            if(preg_match("/2/i", $choice)){
                                                $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[1]]+=1;
                                                if(preg_match("/0/i", $choice))
                                                    $this->g_event_arr[$shift1][$date_array[$k]][$key2][$this->c_event_param_arr1[1]]+=1;    
                                                if($strTF==1){
                                                    $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]]+=1;                                                                                                
                                                    if(preg_match("/0/i", $choice))
                                                        $this->g_event_arr[$shift1][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]]+=1;                                                                                                
                                                        
                                                }
                                            }
                                            
                                            if(preg_match("/3/i", $choice)){
                                                if($strTF==1)
                                                    $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$data_arr2[$this->c_event_param_arr1[5]][$j]][$this->c_event_param_arr1[1]] += 1;
                                                    
                                            }
                                        
                                        }                                         
                                        
                                        
                                        
                                        
                                                                                                                                                                                                                                                
                                        
                                    }                                 
                                }
                            }
                        }
                    }
                }       
            }
        }
        
    }
    #------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式四( 班別+日期+參數名稱[分子/分母] )
    # $choice        :{ 1.暫無指定                              }
    # $extra_format  : 暫無用
    # 使用範圍      ：稼動分析-稼動指標分析-工時損失率(%)
    # -------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_4($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {    
         $ct_cate_array_flip_name=count($this->g_cate_array_flip_name); 
                
         $cate_array_flip[0]=array_flip($cate_array[0]);  #分子：key和value反轉
         $cate_array_flip[1]=array_flip($cate_array[1]);  #分母：key和value反轉
         //print_r($this->g_cate_array_flip_name);echo "<Br><br>";
        
         if(isset($merge_cate_array)){
             $p=0;
             foreach($merge_cate_array as $key => $data ) 
             {
                if($p==0)
                    $tmp_merge_cate=$data;
                else
                   $tmp_merge_cate.=",".$data; 
                $p++;
             }                
         }       
         
         $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
         //print_r($this->g_tmp_event_rawdata_array);echo "==>分子<Br><br>";echo $tmp_merge_cate."<Br><br>";          
        
         $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:            1         2             3   
        #       line    device  category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach( $this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach( $data_arr as $key1 => $data_arr1)  
                { 
                    foreach( $data_arr1 as $key2 => $data_arr2)  
                    {   
                        for($x=0;$x<$ct_cate_array_flip_name;$x++)
                        {
                            if(isset($cate_array_flip[$x][$key2]))
                            {
                                foreach($date_array as $k => $v)
                                {                            
                                    for($j=0;$j<=$tmp_ct;$j++)
                                    {
                                        if(isset($data_arr2["s"][$j]))
                                        {                                             
                                            for($s=0;$s<2;$s++){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->g_cate_array_flip_name[$x]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$this->g_cate_array_flip_name[$x]]=0;
                                                }                                        
                                            } 
                                            
                                            $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                            $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                            $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                            $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;  
                                            
                                            for($p=0;$p<2;$p++){
                                                $t_date_time1=$t_datetime_arr[$p][0];
                                                $t_date_time2=$t_datetime_arr[$p][1];    
                                                                                        
                                                if($data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){                                                    
                                                    if($data_arr2["e"][$j] < $t_date_time2){                                        		
                                                        if($data_arr2["s"][$j] > $t_date_time1){                                        			
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->g_cate_array_flip_name[$x]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                    	    //echo "1=".$key2."=". $this->g_cate_array_flip_name[$x]."=". $date_array[$k]  ."====".$data_arr2["s"][$j] ."====". $data_arr2["e"][$j] ."====".(strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j])) ."<br>";
                                                        
                                                        
                                                        }else{
                                                    		$this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->g_cate_array_flip_name[$x]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                            //echo "1=".$key2."=". $this->g_cate_array_flip_name[$x]."=". $date_array[$k]  ."====".$data_arr2["s"][$j] ."====". $data_arr2["e"][$j] ."====". (strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1)) ."<br>";
                                                        
                                                    	}
                                                    }else{                                        	   
                                                    	if($data_arr2["s"][$j] > $t_date_time1){                                        			
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->g_cate_array_flip_name[$x]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            //echo "1=".$key2."=". $this->g_cate_array_flip_name[$x]."=". $date_array[$k]  ."====".$data_arr2["s"][$j] ."====". $data_arr2["e"][$j] ."====".  (strtotime($t_date_time2) - strtotime($data_arr2["s"][$j])) ."<br>";
                                                        
                                                            
                                                    	}else{                                        			
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->g_cate_array_flip_name[$x]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                            //echo "1=".$key2."=". $this->g_cate_array_flip_name[$x]."=". $date_array[$k] ."====".$data_arr2["s"][$j] ."====". $data_arr2["e"][$j]  ."====".  (strtotime($t_date_time2) - strtotime($t_date_time1)) ."<br>";
                                                        }
                                                    }                                                
                                                }
                                            }
                                            
                                                                                  
                                        }
                                    }
                                }
                            }
                        }
                    }                        
                }        
            }
        }
        
        
    }    
    #------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式3 ( 班別+日期+Line+$category+參數名稱 )
    # $choice        :{  1.時間                       }
    # $extra_format  : 暫無用
    # 使用範圍       ：  Official Report(稼動率)
    # -------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_3($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {    
        $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
        //print_r($this->g_tmp_event_rawdata_array);echo "==><Br><br>";
        //echo $tmp_merge_cate."<Br><br>";          
        $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];     
       //echo $tmp_ct  ;echo "==><Br><br>"; 
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍    
        # key:            1         2           3
        #       line  device      category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach($data_arr as $key1 => $data_arr1)
                {
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {   
                        foreach($date_array as $k => $v)
                        {                            
                            for($j=0;$j<=$tmp_ct;$j++)
                            {
                               if(isset($data_arr2["s"][$j]))
                               {
                                    if((int)$key2>=1&&(int)$key2<=199)
                                        $strTF=1;                                    
                                    else
                                        $strTF=0; 
                                    
                                    for($s=0;$s<2;$s++){
                                        if(preg_match("/1/i", $choice)){
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]]=0;
                                            }
                                            
                                            if($strTF==1){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;
                                                }
                                            }
                                        }
                                    } 
                                    
                                    $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                    $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;  
                                    
                                    for($p=0;$p<2;$p++){    
                                        $t_date_time1=$t_datetime_arr[$p][0];
                                        $t_date_time2=$t_datetime_arr[$p][1];
                                        
                                        if($data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){ 
                                            if(preg_match("/1/i", $choice)){                                    
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){
                                                        
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        }
                                                    }else{
                                                        
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                            
                                                        }
                                                    }
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){
                                                        
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            
                                                        }                                            		
                                                    }else{
                                                        
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                           
                                                        }                                            		
                                                    }
                                            	}
                                            }
                                        }      
                                        
                                    }                                
                                    
                                                                          
                                }
                            }
                        }
                    }
                }       
            }
        }   
        
    }
       
    #------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式2 ( 班別+日期+$category+參數名稱  )
    # $choice        :{  1.時間                   }
    # $extra_format  : 暫無用
    # 使用範圍      ：  Official Report-稼動率
    # -------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_2($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {    
        $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
        //print_r($this->g_tmp_event_rawdata_array);//echo "==><Br><br>";//echo $tmp_merge_cate."<Br><br>";          
        $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];   
        
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:            1         2           3    
        #       line     device  category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach($data_arr as $key1 => $data_arr1)
                {                    
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {
                        foreach($date_array as $k => $v)
                        {       
                            for($j=0;$j<=$tmp_ct;$j++)
                            {  
                                //echo $k. "=".$v."=". $key."=".$key1."=".$data_arr1["s"][$j] ."<br>";
                                if(isset($data_arr2["s"][$j]))
                                {
                                    if((int)$key2>=1&&(int)$key2<=199){
                                        $strTF=1;                           
                                    }else
                                        $strTF=0; 
                                    if(preg_match("/1/i", $choice)){                                        
                                        for($p=0;$p<2;$p++){                                        
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]]=0;                                     
                                            }
                                            if($strTF==1){
                                                if(!isset($this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]])){
                                                    $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;                                     
                                                }    
                                            }
                                            
                                        }
                                    }
                                    
                                    $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                    $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;                                        
                                    

                                    for($p=0;$p<2;$p++){
                                        $t_date_time1=$t_datetime_arr[$p][0];
                                        $t_date_time2=$t_datetime_arr[$p][1];                            
                                        
                                        if(preg_match("/1/i", $choice)){
                                            if($data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){                                    
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                            
                                                        }
                                                    }else{                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                                               
                                                        }                                            		
                                                    }
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            
                                                        }                                            		
                                                    }else{                                    			
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                        if($strTF==1){
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                                            
                                                        }                                            		
                                                    }
                                            	}
                                            }
                                        }                                     
                                    }
                                }
                                
                            }
                        }
                    }
                }       
            }
        }
    }
    #------------------------------------------------------------------------------------------------------------
    # 來源為 event - 格式1 ( 班別+日期+Device+$category+參數  )
    # $choice        :{ 1.時間   2.次數    }
    # $extra_format  : 暫無用
    # 使用範圍      ： 
    # -------------------------------------------------------------------------------------------------------------    
    public function event_rawdata_format_1($database_name,$choice,$extra_format,$fac,$project,$device,$line,$shift,$cate_array,$merge_cate_array,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable)
    {    
        $this->event_rawdata($database_name,$rawdata_type,$choice,$extra_format,$fac,$project,$device,$line,$shift,$tmp_merge_cate,$message,$sele_date1,$sele_date2,$date_array,$date_array1,$findtable);
        
        //print_r($this->g_tmp_event_rawdata_array);echo "==><Br><br>";echo $tmp_merge_cate."<Br><br>";          
        $tmp_ct=$this->g_tmp_event_rawdata_array[$this->c_event_param_arr1[2]];        
        #﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍﹍
        # key:            1         2         3    
        #       line   device    category   參數名稱
        #﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉﹉ 
        if(isset($this->g_tmp_event_rawdata_array[$fac]))
        {
            foreach($this->g_tmp_event_rawdata_array[$fac] as $key => $data_arr)  
            {   
                foreach($data_arr as $key1 => $data_arr1)
                {
                    foreach($data_arr1 as $key2 => $data_arr2)  
                    {   
                        foreach($date_array as $k => $v)
                        {                            
                            for($j=0;$j<=$tmp_ct;$j++)
                            {
                                if(isset($data_arr2["s"][$j]))
                                {
                                    ##echo  $v ."=". $j ."=".$key1."=". $data_arr1["s"][$j] ."=".  $data_arr1["e"][$j] ."=".$this->g_event_arr[$this->g_shift_arr[0]][$date_array[$k]]."<br>";  
                                    if((int)$key2>=1&&(int)$key2<=199){
                                        $strTF=1;                           
                                    }else
                                        $strTF=0; 

                                    for($s=0;$s<2;$s++){                                        
                                        if(preg_match("/1/i", $choice)){
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]]=0;
                                                if($strTF==1){
                                                    if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]))
                                                        $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]]=0;
                                                }    
                                            }
                                        } 
                                        if(preg_match("/2/i", $choice)){
                                            if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[1]])){
                                                $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[1]]=0;
                                                if($strTF==1){
                                                    if(!isset($this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]])){
                                                        $this->g_event_arr[$this->g_shift_arr[$s]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]]=0;
                                                    }   
                                                }                                            
                                            }   
                                        } 
                                    }
                                    
                                    $t_datetime_arr[0][0]=$date_array[$k]." ".$this->o_start_time;
                                    $t_datetime_arr[0][1]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][0]=$date_array[$k]." ".$this->o_end_time;
                                    $t_datetime_arr[1][1]=$date_array1[$k]." ".$this->o_start_time;                                        
                                    
                                    for($p=0;$p<2;$p++){                                       
                                        $t_date_time1=$t_datetime_arr[$p][0];
                                        $t_date_time2=$t_datetime_arr[$p][1];
                                                   
                                        if(preg_match("/1/i", $choice)){
                                            if( $data_arr2["e"][$j] > $t_date_time1 && $data_arr2["s"][$j] < $t_date_time2){
                                                if($data_arr2["e"][$j] < $t_date_time2){                                    		
                                                    if($data_arr2["s"][$j] > $t_date_time1){
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($data_arr2["s"][$j]);
                                                        
                                                    }else{
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                        		        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($data_arr2["e"][$j]) - strtotime($t_date_time1);
                                        		        
                                                    }
                                            	}else{                                    	   
                                            		if($data_arr2["s"][$j] > $t_date_time1){
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                        if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($data_arr2["s"][$j]);
                                                            
                                            		
                                                    }else{
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                      		            if($strTF==1)
                                                            $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[0]] += strtotime($t_date_time2) - strtotime($t_date_time1);
                                      		                
                                                    }
                                            	}
                                                
                                                
                                                if(preg_match("/2/i", $choice)){
                                                    $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$key2][$this->c_event_param_arr1[1]]+=1;                                            
                                                    if($strTF==1)
                                                        $this->g_event_arr[$this->g_shift_arr[$p]][$date_array[$k]][$key1][$this->c_event_param_arr[10][1]][$this->c_event_param_arr1[1]]+=1;
                                                }
                                                
                                            
                                            }
                                        }                                        
                                    }                                     
                                }
                            }
                        }
                    }
                }        
            }
        }
    }
    
    #------------------------------------------------------------------------------------------------------------
    # AOI:將data的日期組成SQL條件
    # -------------------------------------------------------------------------------------------------------------    
    public function aoi_sql_date_Statement($shift,$sele1_date,$sele2_date)
    {
        if(strcmp($shift,"d_shift")==0){  ##日班        	
            $cdatetime = "code3 >= '".$sele1_date."'  and code3 <= '".$sele2_date."' and code4 >= '".$this->o_start_time."' and code4 < '".$this->o_end_time."'";
            
        }else if(strcmp($shift,"f_shift")==0){  ##全天        
        	$sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));    
            $cdatetime = "((code3 >= '".$sele1_date."' and code3 < '".$sele2_date."' and code4 >= '".$this->o_start_time."' ) or ( code3 > '".$sele1_date."' and code3 <= '".$sele2_date."' and code4 < '".$this->o_start_time."' ))";
              
        }else if(strcmp($shift,"f_shift_d_n")==0){  ##全天-日-夜        
        	$sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));    
            $cdatetime = "((code3 >= '".$sele1_date."' and code3 < '".$sele2_date."' and code4 >= '".$this->o_start_time."' ) or ( code3 > '".$sele1_date."' and code3 <= '".$sele2_date."' and code4 < '".$this->o_start_time."' ))";
                  
        }else{  ##夜班          
            $sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));   
            $cdatetime = "((code3 >= '".$sele1_date."' and code3 < '".$sele2_date."' and code4 >= '".$this->o_end_time."' ) or ( code3 > '".$sele1_date."' and code3 <= '".$sele2_date."' and code4 < '".$this->o_start_time."' ))";
            
        } 
        return $cdatetime;
    }
    #------------------------------------------------------------------------------------------------------------
    # HMI:將data的日期組成SQL條件
    # -------------------------------------------------------------------------------------------------------------    
    public function hmi_sql_date_Statement($shift,$sele1_date,$sele2_date)
    {        
        if(strcmp($shift,"d_shift")==0)  ##日班
        {	
            $cdatetime = "Code1 >= '".$sele1_date."'  and Code1 <= '".$sele2_date."' and code2 >= '".$this->o_start_time."' and code2 < '".$this->o_end_time."'";
        
        }else if(strcmp($shift,"f_shift")==0){  ##全天
        
        	$sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));    
            $cdatetime = "((Code1 >= '".$sele1_date."' and Code1 < '".$sele2_date."' and code2 >= '".$this->o_start_time."' ) or ( Code1 > '".$sele1_date."' and Code1 <= '".$sele2_date."' and code2 < '".$this->o_start_time."' ))";
        
        }else if(strcmp($shift,"f_shift_d_n")==0){  ##全天-日-夜       
        
        	$sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));    
            $cdatetime = "((Code1 >= '".$sele1_date."' and Code1 < '".$sele2_date."' and code2 >= '".$this->o_start_time."' ) or ( Code1 > '".$sele1_date."' and Code1 <= '".$sele2_date."' and code2 < '".$this->o_start_time."' ))";
        
        }else{  ##夜班
          
            $sele2_date=date('Y-m-d',strtotime('+1 day',strtotime($sele2_date)));   
        	$cdatetime = "((Code1 >= '".$sele1_date."' and Code1 < '".$sele2_date."' and code2 >= '".$this->o_end_time."' ) or ( Code1 > '".$sele1_date."' and  code1 <= '".$sele2_date."' and code2 < '".$this->o_start_time."' ))";
        }
        return $cdatetime;
    }
    #------------------------------------------------------------------------------------------------------------
    # EVENT:日期時間SQL (這個FUN沒針對夜班&全天日期做加1天)
    # -------------------------------------------------------------------------------------------------------------
    public function event_sql_date_Statement($shift,$sele1_date,$sele2_date)
    {
        if(strcmp($shift,"d_shift")==0){  ##日班        	
            $start_time = $this->o_start_time ;
            $end_time = $this->o_end_time ;  
            
        }else if(strcmp($shift,"f_shift")==0 || strcmp($shift,"f_shift_d_n")==0 ){  ##全天        
            $start_time = $this->o_start_time ;
            $end_time = $this->o_start_time ;
            
        }else{  ##夜班          
            $start_time = $this->o_end_time ;
            $end_time = $this->o_start_time ;            
        } 
        $cdatetime = " and (end_time >= '".$sele1_date." ".$start_time."' and start_time < '".$sele2_date." ".$end_time."')"; 
        
        //$cdatetime = " and ((start_time >= '".$sele1_date." ".$start_time."'  and end_time < '".$sele2_date." ".$end_time."') OR (end_time >= '".$sele1_date." ".$start_time."' and start_time < '".$sele2_date." ".$end_time."'))"; 
        
        return $cdatetime;      
    }
    #------------------------------------------------------------------------------------------------------------
    # 說明:轉換班別
    #-------------------------------------------------------------------------------------------------------------
    public function aoi_shift_Statement($shift)
    {
        if(strcmp($shift,"d_shift")==0){  ##日班        	
            $shift1=$this->g_shift_arr[0];
        
        }else if(strcmp($shift,"f_shift")==0){  ##全天        
        	$shift1=$this->g_shift_arr[3];    
        
        }else if(strcmp($shift,"f_shift_d_n")==0){  ##全天-日-夜        
        	$shift1=$this->g_shift_arr[2];       
        
        }else{  ##夜班          
            $shift1=$this->g_shift_arr[1];
        } 
        return $shift1;        
    }     
    #------------------------------------
    # 說明:變數歸零
    # -----------------------------------
    public function param_to_zero($tmp_str)
    {        
        $ct=count($this->$tmp_str);
        for($k=0;$k<$ct;$k++) 
        {             
            switch ($tmp_str)
            {
                case "c_aoi_param_arr":
                    if(isset($this->c_aoi_param_arr[$k]))
                        $dynamic_param="g_".$this->c_aoi_param_arr[$k]; 
                    break;  
               
                case "c_hmi_param_arr":
                    if(isset($this->c_hmi_param_arr[$k]))
                        $dynamic_param="g_".$this->c_hmi_param_arr[$k]; 
                    break;  
                
                case "c_event_param_arr":
                    if(isset($this->c_event_param_arr[$k][0]))
                        $dynamic_param="g_".$this->c_event_param_arr[$k][0];                    
                    //echo $dynamic_param."=".$this->c_event_param_arr[$k] ."<br>";
                    break;
            }             
            $this->$dynamic_param = 0;
        }
    }    
    #---------------------------------------------------------------------------------------------------------------------
    # 說明：傳回當天單一班別，並以小時做間隔的日期時間
    # 格式：日期+時:分:秒
    # g_s_day_array => Array ( [0] => 2017-05-01 07:40:00 [1] => 2017-05-01 08:00:00 ... [12] => 2017-05-01 19:00:00 ) 
    # g_e_day_array => Array ( [0] => 2017-05-01 08:00:00 [1] => 2017-05-01 09:00:00 ... [12] => 2017-05-01 20:00:00 )
    #----------------------------------------------------------------------------------------------------------------------
    public function date_array_format_1($shift,$sele_date)
    {    
        if(strcmp($shift,"d_shift")==0 || strcmp($shift,"D")==0)
        {	
			$start_time = $sele_date . " ".$this->o_start_time;
            $end_time   = $sele_date ." ".$this->o_end_time;            
            $s_day      = date('j', strtotime($start_time));
            $s_day_2    = date('Y-m-d', strtotime($start_time));
            $e_day      = date('j', strtotime($end_time));
            $e_day_2    = date('Y-m-d', strtotime($end_time));

            for($i=7;$i<20;$i++){
                if ($i == 7) {
                    $this->g_s_day_array[$i - 7] = $start_time;
                    $this->g_e_day_array[$i - 7] = $s_day_2 . " 08:00:00";
                } else {
                    if ($i < 10) {
                        $this->g_s_day_array[$i - 7] = $s_day_2 . " 0" . $i . ":00:00";
                    } else {
                        $this->g_s_day_array[$i - 7] = $s_day_2 . " " . $i . ":00:00";
                    }
                    if ($i < 9)
                        $this->g_e_day_array[$i - 7] = $s_day_2 . " 0" . ($i + 1) . ":00:00";
                    else
                        $this->g_e_day_array[$i - 7] = $s_day_2 . " " . ($i + 1) . ":00:00";
                }
            }
        }else{  ##夜班            
            $start_time = $sele_date ." ".$this->o_end_time;
            $end_time   = date("Y-m-d", strtotime($sele_date) + 86400) ." ".$this->o_start_time;
            $s_day      = date('j', strtotime($start_time));
            $s_day_2    = date('Y-m-d', strtotime($start_time));
            $e_day      = date('j', strtotime($end_time));
            $e_day_2    = date('Y-m-d', strtotime($end_time));
            
            for ($i = 20; $i < 32; $i++) {
                if ($i >= 24) {
                    $j                    = $i - 24;                
                    $this->g_s_day_array[$i - 20] = $e_day_2 . " 0" . ($i - 24) . ":00:00";
                    $this->g_e_day_array[$i - 20] = $e_day_2 . " 0" . ($i + 1 - 24) . ":00:00";
                    if ($i == 31) {
                        $this->g_s_day_array[$i - 20] = $e_day_2 . " 07:00:00";
                        $this->g_e_day_array[$i - 20] = $end_time;
                    }
                } else {
                    $j                   = $i;                
                    if ($i == 23) {
                        $this->g_s_day_array[$i - 20] = $s_day_2 . " " . $i . ":00:00";
                        $this->g_e_day_array[$i - 20] = $e_day_2 . " 0" . ($i + 1 - 24) . ":00:00";
                    } else {
                        $this->g_s_day_array[$i - 20] = $s_day_2 . " " . $i . ":00:00";
                        $this->g_e_day_array[$i - 20] = $s_day_2 . " " . ($i + 1) . ":00:00";
                    }                
                }
            }
        }
    }    
    #------------------------------------------------------------------------------------------------------------------
    # 說明：傳回當天單一班別(產生的日期是往前推的)
    # 格式：日期
    # 範例：傳入2017-05-01 
    # $first_array => Array ( [0] => 2017-04-29 [1] => 2017-04-30 [2] => 2017-05-01 ) 
    # $second_array => Array ( [0] => 2017-04-30 [1] => 2017-05-01 [2] => 2017-05-02 ) 
    #------------------------------------------------------------------------------------------------------------------
    public function date_array_format_2($shift,$sele_date,$diff)
    {    
        $year =  substr($sele_date,0,4);
        $month = substr($sele_date,5,7);
        $day = substr($sele_date,8,10);
        $first_array = array();
        $second_array = array();
        $j=0;
        
        for ($cnt = $diff;$cnt >= 0;$cnt--)
        {
             $first_array[$j] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt,$year));    # 2/1-3/2    
             $second_array[$j] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt+1,$year)); # 2/2-3/3   
             
             $j++;
        }
        
        return array($first_array,$second_array);       
    }    
    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    # 說明：傳回多天單一班別，並以1個班別產生日期時間 (產生的日期是往前推的)
    # 格式：天數流水號+[0:起始時間/1:截止時間]+日期時分秒  
    # 範例：傳入2017-05-01 
    # $first_array ==> 
    #   Array ( 
    #        [0] => Array ( [0] => 2017-04-29 07:40:00 [1] => 2017-04-29 20:00:00 ) 
    #        [1] => Array ( [0] => 2017-04-30 07:40:00 [1] => 2017-04-30 20:00:00 ) 
    #        [2] => Array ( [0] => 2017-05-01 07:40:00 [1] => 2017-05-01 20:00:00 ) 
    #        )
    #  $second_array ==> 
    #        Array ( 
    #        [0] => Array ( [0] => 2017-04-30 07:40:00 [1] => 2017-04-30 20:00:00 ) 
    #        [1] => Array ( [0] => 2017-05-01 07:40:00 [1] => 2017-05-01 20:00:00 ) 
    #        [2] => Array ( [0] => 2017-05-02 07:40:00 [1] => 2017-05-02 20:00:00 ) 
    #        )   
    # 備註：    
    #----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public function date_array_format_4($shift,$sele_date,$diff)
    {    
        $year =  substr($sele_date,0,4);
        $month = substr($sele_date,5,7);
        $day = substr($sele_date,8,10);
        $first_array = array();
        $second_array = array();
        $j=0;
                  
        for ($cnt = $diff;$cnt >= 0;$cnt--)
        {
             if(strcmp($shift,"d_shift")==0 || strcmp($shift,"D")==0){
                 $first_array[$j][0] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt,$year))." ".$this->o_start_time;    # 2/1-3/2    
                 $second_array[$j][0] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt+1,$year))." ".$this->o_start_time; # 2/2-3/3   
                 
                 $first_array[$j][1] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt,$year))." ".$this->o_end_time;    
                 $second_array[$j][1] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt+1,$year))." ".$this->o_end_time;  
                    
             }else{
                 $first_array[$j][0] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt,$year))." ".$this->o_end_time;    # 2/1-3/2    
                 $second_array[$j][0] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt+1,$year))." ".$this->o_end_time; # 2/2-3/3   
                 
                 $first_array[$j][1] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt,$year))." ".$this->o_start_time;     
                 $second_array[$j][1] = date("Y-m-d",mktime(0,0,0,$month,$day-$cnt+1,$year))." ".$this->o_start_time; 
                   
             }
             $j++;
        }
        
        return array($first_array,$second_array);       
    }
    #------------------------------------------------------------------------------------------------------------------------------------------
    # 說明：傳回多天單一班別，並以小時做間隔的日期時間
    # 格式：班別+日期+日期時分秒  
    # 範例：傳入2017-05-01 
    # g_s_day_array => Array ( [D] => Array ( [2017-05-01] => Array ( [0] => 2017-05-01 07:40:00 [1] => 2017-05-01 08:00:00 
    #                                                      [2] => 2017-05-01 09:00:00 .... [12] => 2017-05-01 19:00:00 ) 
    # 
    # g_e_day_array => Array ( [D] => Array ( [2017-05-01] => Array ( [0] => 2017-05-01 08:00:00 [1] => 2017-05-01 09:00:00
    #                                                         [2] => 2017-05-01 10:00:00 .... [12] => 2017-05-01 20:00:00 )
    # 備註：  
    #------------------------------------------------------------------------------------------------------------------------------------------
    public function date_array_format_5($shift,$sele_date,$diff)
    {    
        $date_arr=array();
        for($j=0;$j<=$diff;$j++){
            $date_arr[$j] = date('Y-m-d', strtotime($sele_date. " + {$j} days"));                            
        }
        $ct=count($date_arr);       
        if(strcmp($shift,"d_shift")==0 || strcmp($shift,"D")==0){
            for($m=0;$m<$ct;$m++){
            
                $start_time = $date_arr[$m]." ".$this->o_start_time; 
                $end_time   = $date_arr[$m]." ".$this->o_end_time;                  
                          
                $s_day      = date('j', strtotime($start_time));
                $s_day_2    = date('Y-m-d', strtotime($start_time));
                $e_day      = date('j', strtotime($end_time));
                $e_day_2    = date('Y-m-d', strtotime($end_time));
    
               // echo $start_time."=".$end_time ."=".$s_day."=".$s_day_2."=". $e_day ."=".$e_day_2  ."<br>";             
                
                for($i=7;$i<20;$i++){
                    
                    if ($i == 7) {
                        $this->g_s_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $start_time;
                        $this->g_e_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $s_day_2 . " 08:00:00";
                    } else {
                        if ($i < 10) {
                            $this->g_s_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $s_day_2 . " 0" . $i . ":00:00";
                        } else {
                            $this->g_s_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $s_day_2 . " " . $i . ":00:00";
                        }
                        if ($i < 9)
                            $this->g_e_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $s_day_2 . " 0" . ($i + 1) . ":00:00";
                        else
                            $this->g_e_day_array[$this->g_shift_arr[0]][$date_arr[$m]][$i - 7] = $s_day_2 . " " . ($i + 1) . ":00:00";
                    }
                }
            }
            
            
        }else{  ##夜班            
            
            for($m=0;$m<$ct;$m++){            
                $start_time = $date_arr[$m] ." ".$this->o_end_time;
                $end_time   = date("Y-m-d", strtotime($date_arr[$m]) + 86400) ." ".$this->o_start_time;
                $s_day      = date('', strtotime($start_time));
                $s_day_2    = date('Y-m-d', strtotime($start_time));
                $e_day      = date('j', strtotime($end_time));
                $e_day_2    = date('Y-m-d', strtotime($end_time));
                
                for ($i = 20; $i < 32; $i++) {
                    if ($i >= 24) {
                        $j                    = $i - 24;                
                        $this->g_s_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $e_day_2 . " 0" . ($i - 24) . ":00:00";
                        $this->g_e_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $e_day_2 . " 0" . ($i + 1 - 24) . ":00:00";
                        if ($i == 31) {
                            $this->g_s_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $e_day_2 . " 07:00:00";
                            $this->g_e_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $end_time;
                        }
                    } else {
                        $j                   = $i;                
                        if ($i == 23) {
                            $this->g_s_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $s_day_2 . " " . $i . ":00:00";
                            $this->g_e_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $e_day_2 . " 0" . ($i + 1 - 24) . ":00:00";
                        } else {
                            $this->g_s_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $s_day_2 . " " . $i . ":00:00";
                            $this->g_e_day_array[$this->g_shift_arr[1]][$date_arr[$m]][$i - 20] = $s_day_2 . " " . ($i + 1) . ":00:00";
                        }                
                    }
                }
            }  
           
        }    
//        print_r($this->g_s_day_array);echo "<br>";       
//        print_r($this->g_e_day_array);echo "<hr>";    
       
    }
    #------------------------------------
    # 說明: category轉中文
    # -----------------------------------
    public function category_to_cht($t_category)
    {        
        $ct_aoi_event_param =count($this->c_event_param_arr);
        for($m=0;$m<$ct_aoi_event_param;$m++) 
        {
            if($this->c_event_param_arr[$m][1]==$t_category)
            {
                return ($this->c_event_param_arr[$m][3]);
                exit;
            }
        } 
    } 
    #---------------------------------------------------------------
    # 說明: 某檢測工站的檢測名稱、SQL欄位
    # --------------------------------------------------------------
    public function measure_name($fac,$device_setting_array,$title_name)
    {        
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }          	
        $username ="root";
        $password ="foxlink";
        $database_name = "aoi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	//選擇連線資料庫
            die("無法使用資料庫");
        
        $firstArray = array();   #所有的檢測名稱欄位      
        $secondArray = array();  #檢測名稱欄位
        $thirdArray= array();    #檢測名稱
        #-------------------------------------------------------------------
        # key:   1     2         3             4       5
        #       fac  project  device_name     序號    line
        # ----------------------------------------------------------------
        foreach($device_setting_array as $k1=>$data1_arr) 
        {
            foreach($data1_arr as $k2=>$data2_arr)
            {   
                if(preg_match("/".$k2."/i", $this->o_project_exception))
                    break;
                foreach($data2_arr as $k3=>$data3_arr)
                {             
                    $ct=count($this->g_measure_info[$k2][$k3]);
                    //echo $ct."<br>";
                    
                    for($i=0; $i<$ct; $i++){                        
                        $sub_sql = "";
                        $sql = "select code,title_name,value_type from data_extend_format 
                        where project='".$k2."' and measure_workno='".$this->g_measure_info[$k2][$k3][$i]['measure_workno']."' ".$s_titile_name."  
                        order by code";
                        //echo $sql."<br>";
                        $rows = $mysqli->query($sql);                        
                        $index = 0;
                        $index1 = 0;            
                        while($row = $rows->fetch_row())
                        {                
                            $value_type = $row[2];            
                            if($value_type=="int")
                            {
                                if($index==0)
                                    $sub_sql = "Code".$row[0];
                                else
                                    $sub_sql .= ",Code".$row[0];
                                //echo $sub_sql."<br>";    
                                $firstArray[$k2][$k3][$this->g_measure_info[$k2][$k3][$i]['measure_workno']]= $sub_sql;
                                $secondArray[$k2][$k3][$this->g_measure_info[$k2][$k3][$i]['measure_workno']][$index] = "Code".$row[0];                                
                                
                                $index++;
                            }
                            else if($value_type=="varchar"){
                                $thirdArray[$k2][$k3][$this->g_measure_info[$k2][$k3][$i]['measure_workno']][$index1] = $row[1];
                                $index1++;
                                                                
                            }                   
                        }
                    }
                }
            }            
        }
        return array($firstArray,$secondArray,$thirdArray);
    }
    
    #-----------------------------------------------------------------------------------------------------------------------------------------------------
    # HMI-Data     
    # $choice      : 預設(1)
    # $extra_format: 如下
    #-----------------------------------------------------------------------------------------------------------------------------------------------------  
    /**  注  意：程式中format參數 不等於 table表的format
    #
    #    ※ $extra_format:0 => 要多呈現 [DN] 資料，目前只針對 $extra_format:1 有此功能
    #    
    #    ※ $extra_format:1 =>《TABLE: XXX_statistics_format:1》
    #        project + device_name + 日期 + 班別 + line  +  參數名稱(投入、不良)
    
    #    ※ $extra_format:2 =>《TABLE: XXX_statistics_format:2》
    #        project + device_name + 日期 + 班別 + line  + [Day-Hour] + 參數名稱(投入、不良)

    #    ※ $extra_format:3 =>《TABLE: XXX_statistics_format:》
    #       project + device_name + 日期 + 班別 + line  + 行號  + 參數名稱( periods / happen_times / {s、e} )
    #
    #-----------------------------------------------------------------------------------------------------------------------------------------------------  
    **/
    public function hmi_project_rawdata_1($choice,$extra_format,$fac,$project,$device,$line,$shift,$sele1_date,$sele2_date,$findtable)
    {
        
        if($fac=='KS'){
            $hostname="10.72.252.236";
        }else{
            $hostname="192.168.64.233";
        }
        $username ="root";
        $password ="foxlink";        
        $skip=0; 
        if(preg_match("/".$project."/i", $this->o_project_exception))    
            $database_name = "hmi_old";   
        else
            $database_name = "hmi";
        $mysqli = new mysqli($hostname,$username,$password,$database_name);
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
        if (!$mysqli->select_db($database_name))	#選擇連線資料庫
            die("無法使用資料庫");    
        
         
        $cdatetime = $this->hmi_sql_date_Statement($shift,$sele1_date,$sele2_date);
        
        $shift1=$this->aoi_shift_Statement($shift);
          
        //echo $cdatetime."=".$shift1."<br>";    
        $result_arr = array();
        
        $out_hmi_input_arr = explode(";", $this->hmi_input);
        $out_hmi_bad_arr = explode(";", $this->hmi_bad);
        $out_hmi_column_arr= explode(",", $this->hmi_column);


//$this->g_debug_msg_array[1].="=".$out_hmi_input_arr[0]."=".$out_hmi_column_arr[1] ."<br>";

        if($line!="")
            $s_line=" and Line in (".$line.") ";
        else
            $s_line="";   

        if(preg_match("/0/i", $extra_format)){
            $shift3=$this->g_shift_arr[2];  #需要有[DN]                
        }   
        if(preg_match("/3/i", $extra_format)){   //原5->4
            //$this->date_array_format_1($shift,$sele1_date); 
            $row_index = 0;
            $old_time = "";            
        }             
        $sql = "select ".$this->hmi_column."
                from `".$project."_".$device."_data".$findtable."`
                where 1=1 ".$s_line." and ".$cdatetime."  
                order by ".$this->hmi_column."";                   
        //echo $sql."<Br>";
        $this->g_debug_msg_array[1]=$sql."<Br>";
        
        $shift2=$shift1;
        $rows = $mysqli->query($sql);       
        while($row = $rows->fetch_row())
        {   
            $now_date=$row[3]; 
             
            $hour=(int)date('H',  strtotime($row[3]." ".$row[4]));
            $day=(int)date('d',  strtotime($row[3]." ".$row[4]));
            //echo $row[2]." ".$row[3]."=".$hour."<Br>";            
    
            if($row[4] >= $this->o_start_time && $row[4] < $this->o_end_time ){     
                if($shift1==$this->g_shift_arr[2])  #DN時要拆D和N
                    $shift2=$this->g_shift_arr[0];
            }else{
                if($shift1==$this->g_shift_arr[2])  #DN時要拆D和N
                    $shift2=$this->g_shift_arr[1];                        
                if($row[4] >= "00:00:00" && $row[4] < $this->o_start_time ){
                    $now_date=date('Y-m-d',strtotime('-1 day',strtotime($now_date)));  #夜班若跨到隔天，所屬日期必須向前移一天                          
                }
            }            
            //$class_resume->g_debug_msg_array[1].=$shift."<br>";
            if(preg_match("/0|1|2|3/i", $choice)){
                
                for($p=0;$p<2;$p++){ 
                    if(preg_match("/1/i", $extra_format)){
                        if(!isset($this->g_final_arr1[$fac][$project][$device][$now_date][$shift2][$row[0]][$this->c_hmi_param_arr[$p]])){
                            $this->g_final_arr1[$fac][$project][$device][$now_date][$shift2][$row[0]][$this->c_hmi_param_arr[$p]]=0;
                            
                        } 
                        if(preg_match("/0/i", $extra_format)){
                            if(!isset($this->g_final_arr1[$fac][$project][$device][$now_date][$shift3][$row[0]][$this->c_hmi_param_arr[$p]]))
                                $this->g_final_arr1[$fac][$project][$device][$now_date][$shift3][$row[0]][$this->c_hmi_param_arr[$p]]=0;                                
                        }  
                                                    
                    }      
                    
                     
                    if(preg_match("/2/i", $extra_format)){
                        if(!isset($this->g_final_arr2[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[$p]])){
                            $this->g_final_arr2[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[$p]]=0;
                        }    
                    }
                    if(preg_match("/3/i", $extra_format) ){                        
                     
                        
                    }
                                                       
                }                
    
               if(preg_match("/3/i", $extra_format) ){                            
                    if($last_shift!=$shift2){
                        $row_index=0; 
                    }
                    if($last_date!=$now_date){
                        $row_index1=0;
                    }                    
                    if($row_index!=0 && $row_index1!=0){
                        //echo $shift2."=".$old_time."=".$row[5]." ".$row[6]."<Br>";
                        //$class_resume->g_debug_msg_array[100].=$last_date."<Br>";                                                    
                        $this->g_final_arr3[$fac][$project][$device][$now_date][$shift2][$row[0]][$row_index-1]["s"] = $old_time;
                        $this->g_final_arr3[$fac][$project][$device][$now_date][$shift2][$row[0]][$row_index-1]["e"] = $row[3]." ".$row[4];
                        $this->g_final_arr3[$fac][$project][$device][$now_date][$shift2][$row[0]][$row_index-1][$this->c_event_param_arr1[0]] = strtotime($row[3]." ".$row[4]) - strtotime($old_time);                             
                    }                            
                    $old_time = $row[3]." ".$row[4];
                    $last_shift=$shift2;
                    $last_date=$now_date;
                    $row_index++; 
                    $row_index1++;                            
                }
        
                
                
                if($out_hmi_input_arr[0]==$out_hmi_column_arr[1] ){ #投入              
                    if(preg_match("/1/i", $extra_format)){  
                        $this->g_final_arr1[$fac][$project][$device][$now_date][$shift2][$row[0]][$this->c_hmi_param_arr[0]]+=$row[1];
                        if(preg_match("/0/i", $extra_format)){
                            $this->g_final_arr1[$fac][$project][$device][$now_date][$shift3][$row[0]][$this->c_hmi_param_arr[0]]+=$row[1]; 
                            //echo $now_date."=".$shift3."=".$this->g_final_arr1[$fac][$project][$device][$now_date][$shift3][$row[0]][$this->c_hmi_param_arr[0]]."<br>";
                        }
                    }
                    if(preg_match("/2/i", $extra_format)){  
                        $this->g_final_arr2[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[0]]+=$row[1];
                        //$this->g_debug_msg_array[9].= $day."=".$hour."=".$row[1]."<Br>";
                    }
                    
                    if(preg_match("/4/i", $extra_format)){
                        //$this->g_final_arr3[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[0]]+=$row[1];
                         
                    }
                } 
                               
                if($out_hmi_bad_arr[0]==$out_hmi_column_arr[2]){ #不良                     
                    if(preg_match("/1/i", $extra_format)){  
                        $this->g_final_arr1[$fac][$project][$device][$now_date][$shift2][$row[0]][$this->c_hmi_param_arr[1]]+=$row[2];                    
                        if(preg_match("/0/i", $extra_format)){
                            $this->g_final_arr1[$fac][$project][$device][$now_date][$shift3][$row[0]][$this->c_hmi_param_arr[1]]+=$row[2];                                
                        }
                    }
                    if(preg_match("/2/i", $extra_format)){  
                        $this->g_final_arr2[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[1]]+=$row[2];
                    }
                    
                    if(preg_match("/4/i", $extra_format)){
                        //$this->g_final_arr3[$fac][$project][$device][$now_date][$shift2][$row[0]][$day."-".$hour][$this->c_hmi_param_arr[0]]+=$row[2];
                         
                    }
                   
                }               
            }
        }
        mysqli_free_result($rows);
        //unset($this->g_measure_info);
    }
      
    
    
    #------------------------------------
    # 說明: category組成字串
    # -----------------------------------
    public function category_string($tmp_group_arr)
    {        
        $x=0;
        $ct_aoi_event_param =count($this->c_event_param_arr);
        for($k=0;$k<$ct_aoi_event_param;$k++){                
            if($this->c_event_param_arr[$k][2]!=""){                
                foreach($tmp_group_arr as $key => $tmp_value){ 
                    if($this->c_event_param_arr[$k][1]==$tmp_value){                                
                        if($x==0){
                            $tmp_group=$tmp_value;     
                        }else{
                            $tmp_group.="_".$tmp_value;     
                        }  
                        $x++;
                    }
                }                
            }
        }
        return $tmp_group;        
    }     
      

}
?>