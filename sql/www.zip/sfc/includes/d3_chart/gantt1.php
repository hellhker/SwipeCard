<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
</head>
<style>
#figure {
  font: 10px sans-serif;
}
</style>
<body>
<script src="../includes/d3_chart/echarts.js"></script>
<script>
function formatTime(longTime) {
    //转化为 日+小时+分+秒
    var time = parseFloat(longTime);
    if (time != null && time != ""){
        if (time < 60) {
            var s = time;
            if (s<10) {s='0'+s;}
            time ='00:'+'00:'+ s;
        } else if (time > 60 && time < 3600) {
            var m = parseInt(time / 60);
            var s = parseInt(time % 60);
            if (m<10) {m='0'+m;}
            if (s<10) {s='0'+s;}
            time ='00:'+ m + ":" + s;
        } else if (time >= 3600 && time < 86400) {
            var h = parseInt(time / 3600);
            var m = parseInt(time % 3600 / 60);
            var s = parseInt(time % 3600 % 60 % 60);
            if (h<10) {h='0'+h;}
            if (m<10) {m='0'+m;}
            if (s<10) {s='0'+s;}
            time = h + ":" + m + ":" + s;
        } else if (time >= 86400) {
            var d = parseInt(time / 86400);
            var h = parseInt(time % 86400 / 3600);
            var m = parseInt(time % 86400 % 3600 / 60)
            var s = parseInt(time % 86400 % 3600 % 60 % 60);
            if (d<10) {d='0'+d;}
            if (h<10) {h='0'+h;}
            if (m<10) {m='0'+m;}
            if (s<10) {s='0'+s;}
            time = d + '天' + h + ":" + m + ":" + s;
        }
    }   
    return time;    
}
</script>
<script>
function draw_d3(start_time,title,title1,value,value1,value2)
{         
var myChart = echarts.init(document.getElementById('figure'));
var data = [];
var startTime = +new Date(start_time);
var types = [
    {name: title1[0], color: '#009900'},
    {name: title1[1], color: '#C0504D'},
    {name: title1[2], color: '#8064A2'}
]; 

var data1=[];
var data2=[];
var data3=[];

echarts.util.each(title, function (category, index) {

        for(var j=0;j<value[index].length;j++){
            
        var duration=value1[index][j]*1000;
        var baseTime= +new Date(value[index][j]);
            
        if(value2[index][j]=="實際"){
            typeItem = types[0];
            data1.push({
            name: typeItem.name,
            value: [
                index,
                baseTime,
                baseTime += duration,
                duration
            ],
            itemStyle: {
                normal: {
                    color: typeItem.color
                }
             }
        });
        }else if(value2[index][j]=="損失"){
            typeItem = types[1];
            data2.push({
            name: typeItem.name,
            value: [
                index,
                baseTime,
                baseTime += duration,
                duration
            ],
            itemStyle: {
                normal: {
                    color: typeItem.color
                }
            }
        });
        }else{
            typeItem = types[2];
            data3.push({
            name: typeItem.name,
            value: [
                index,
                baseTime,
                baseTime += duration,
                duration
            ],
            itemStyle: {
                normal: {
                    color: typeItem.color
                }
            }
          });
        }
      }
  });
format = function date2str(x, y) {
    var z = {
        M: x.getMonth() + 1,
        d: x.getDate(),
        h: x.getHours(),
        m: x.getMinutes(),
        s: x.getSeconds()
    };
    y = y.replace(/(M+|d+|h+|m+|s+)/g, function(v) {
        return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
    });

    return y.replace(/(y+)/g, function(v) {
        return x.getFullYear().toString().slice(-v.length)
    });
}
function renderItem(params, api) { //自定義渲染邏輯使用renderItem函數
    var categoryIndex = api.value(0);//api.value:取出data中的值
    var start = api.coord([api.value(1), categoryIndex]);//api.coord:座標轉換計算
    var end = api.coord([api.value(2), categoryIndex]);
    var height = api.size([0, 1])[1] * 0.6;//api.size:座標系上一段數值範圍對應的長度

    return {
        type: 'rect', //矩形
        shape: echarts.graphic.clipRectByRect({
            x: start[0],
            y: start[1] - height / 2,
            width: end[0] - start[0],
            height: height
        }, {
            x: params.coordSys.x,
            y: params.coordSys.y,
            width: params.coordSys.width,
            height: params.coordSys.height
        }),
        style: api.style()  
    };
}     

var option = {
    tooltip: { //提示框
        formatter: function (params) {
            var longTime=params.value[3]/1000;
            return params.marker + params.name + ': ' + formatTime(longTime);
        }
    },
    title: { //標題
        //text: 'Profile',
    },
    legend: { //圖例
        data: ['實際','損失','除外']
    },
    
    dataZoom: [{ //區域縮放控制器
        type: 'slider',  //滑動條型區域縮放
        filterMode: 'weakFilter',
        showDataShadow: false,
        top: 400,
        height: 10,
        borderColor: 'transparent', 
        backgroundColor: '#e2e2e2', //數據陰影樣式       
        handleIcon: 'M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z', 
        handleSize: 20, //手柄的尺寸
        handleStyle: { //手柄樣式
            shadowBlur: 6,
            shadowOffsetX: 1,
            shadowOffsetY: 2,
            shadowColor: '#aaa'
        },
        labelFormatter: ''   //顯示的lable的格式化器
    }, {
        type: 'inside',
        filterMode: 'weakFilter'
    }],
    grid: {  //網格
        height:300,
        
    },
    
    xAxis: {
        min: startTime,
        scale: true,
        axisLabel: {
            formatter: function (val) {
                var date1 = new Date(val);
                return format(date1, 'hh:mm')
            }
        }
        
    },
    yAxis: {
        data: title
    },
    series: [
       {
            type: 'custom',
            name: '實際',
            renderItem: renderItem,
            itemStyle: {
                normal: {
                    color: '#009900',
                    opacity: 0.8  //顏色透明度
                }
            },
            encode: {
                x: [1, 2],
                y: 0
            },
            data: data1
        },
        {
            type: 'custom',
            name: '損失',
            renderItem: renderItem,
            itemStyle: {
                normal: {
                    color: '#C0504D',
                    opacity: 0.8  
                }
            },
            encode: {
                x: [1, 2],
                y: 0
            },
            data: data2
        },
        {
            type: 'custom',
            name: '除外',
            renderItem: renderItem,
            itemStyle: {
                normal: {
                    color: '#8064A2',
                    opacity: 0.8  
                }
            },
            encode: {
                x: [1, 2],
                y: 0
            },
            data: data3
        }
     
     ]
    };
myChart.setOption(option);
}
</script>
</body>
</html>