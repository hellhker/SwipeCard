<style>

#figure {
  font: 10px sans-serif;
}

.axis path,
.axis line {
  fill: none;
  stroke: #000;
  shape-rendering: crispEdges;
}

</style>

<script src="../includes/d3_chart/d3.min.js"></script>
<script>
function draw_d3(start_time,end_time,title,title1,value,value1,value2)
{
    var customTimeFormat = d3.time.format.multi([
        [".%L", function(d) { return d.getMilliseconds(); }],
        [":%S", function(d) { return d.getSeconds(); }],
        ["%H:%M", function(d) { return d.getMinutes(); }],
        ["%H", function(d) { return d.getHours(); }],
        ["%a %d", function(d) { return d.getDay() && d.getDate() != 1; }],
        ["%b %d", function(d) { return d.getDate() != 1; }],
        ["%B", function(d) { return d.getMonth(); }],
        ["%Y", function() { return true; }]
      ]);
      
    var timeFormat = d3.time.format('%Y/%m/%d %H:%M:%S');
    var hourFormat = d3.time.format('%H:%M');
    
    var margin = {top: 40, right: 20, bottom: 40, left: 75},
        width = 650 - margin.left - margin.right,
        height = 450 - margin.top - margin.bottom;
    
    var y = d3.scale.ordinal()
        .rangeRoundBands([0, height], .3);
    /*
    var start_time="2016-11-15 07:40:00";
    var end_time="2016-11-15 20:00:00";
    */
    var x = d3.time.scale()
        .domain([timeFormat.parse(start_time), timeFormat.parse(end_time)])
        .nice(d3.time.minute.hourFormat)
        .range([0, width]);
    
    var color = d3.scale.ordinal()
        .range(["#009900","#C0504D","#8064A2"]); //綠色：實際，紅色：損失，藍色：除外
    
    var xAxis = d3.svg.axis()
        .scale(x)
        .tickFormat(hourFormat)
        .orient("bottom");
        
    var yAxis = d3.svg.axis()
        .scale(y)
        .orient("left")
    
    
    var svg = d3.select("#figure").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .attr("id", "d3-plot")
      .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        /*
        var title=["a","b"];
        var title1=["投入","損失"];
        var value=["2015-11-15 10:25:33","2015-11-15 10:32:55",]
        */
      color.domain(title1);

      var data=[];
    
      for(var i=0; i<title.length; i++)
      {
        data.push({
            title: title[i], 
            value:  value[i],
            value1:  value1[i],
            value2: value2[i]
        });
      }
    
    //  d3.csv("raw_data.csv", function(error, data) {
      //var min_val=0;
      //var max_val=0;
      
      data.forEach(function(d) {
        // calc percentages
        //var number=0;
        /*
        for(var i=0; i<d.value.length; i++)
        {
            //if(typeof d[d.value2[i]] == 'undefined')
            //    d[d.value2[i]]=0;
            d[d.value2[i]] = d.value[i];
            //number += d.value[i];
            //max_val = (number>max_val)?number:max_val;
        }
        */
        //var x0 = -1*(d["C"]/2+d["B"]+d["A"]);
        //var x0 = d.value[0];
        var idx = -1;
        d.boxes = d.value2.map(function(name) { idx++; return{name: name, x0: new Date(d.value[idx]), x1: d.value1[idx], N: +d.value[4], n: d.value[idx]}; });
      });
    /*
      d3.min(data, function(d) {
        alert(d.boxes["0"].name+"  "+d.boxes["0"].x1)
              return d.boxes["0"].x1;
      });
    
      var max_val = d3.max(data, function(d) {
              return d.boxes["3"].x1;
              });
    */
      //x.domain([min_val, max_val]).nice();
      //x.domain(d3.extent(data, function(d) { return d.boxes["1"].x0; }));
      //y.domain(data.map(function(d) { return d.Question; }));
      y.domain(title);
    
      svg.append("g")
          .attr("class", "x axis")
          .attr("transform", "translate(0," + (height-margin.bottom/2) + ")")
          .call(xAxis);
    
      svg.append("g")
          .attr("class", "y axis")
          //.attr("transform", "translate(-5,0)")
          .call(yAxis);
    
      var vakken = svg.selectAll(".title")
          .data(data)
        .enter().append("g")
          .attr("class", "bar")
          .attr("transform", function(d) {return "translate(0," + y(d.title) + ")"; });
    
      var bars = vakken.selectAll("rect")
          .data(function(d) { return d.boxes; })
        .enter().append("g").attr("class", "subbar");
        
      var avg_width = width/((new Date(end_time)-new Date(start_time))/1000);
    
      bars.append("rect")
          .attr("height", y.rangeBand())
          .attr("x", function(d) {return x(d.x0); })
          .attr("width", function(d) { return d.x1*avg_width; })
          .style("fill", function(d) { return color(d.name); });
    
      bars.append("text")
          .attr("x", function(d) { return x(d.x0); })
          .attr("y", y.rangeBand()/2)
          .attr("dy", "0.5em")
          .attr("dx", "0.5em")
          .style("font" ,"10px sans-serif")
          .style("text-anchor", "begin");
          //.text(function(d) {return d.n });
    
      vakken.insert("rect",":first-child")
          .attr("height", y.rangeBand())
          .attr("x", "1")
          .attr("width", width)
          .attr("fill-opacity", "0.5")
          .style("fill", "#F5F5F5")
          .attr("class", function(d,index) { return index%2==0 ? "even" : "uneven"; });
    
      svg.append("g")
          .attr("class", "y axis")
      .append("line")
          .attr("x1", x(0))
          .attr("x2", x(0))
          .attr("y2", height);
    
      var startp = svg.append("g").attr("class", "legendbox").attr("id", "mylegendbox");
      // this is not nice, we should calculate the bounding box and use that
      var legend_tabs = [0, 80, 160, 240];
      var legend = startp.selectAll(".legend")
          .data(color.domain().slice())
        .enter().append("g")
          .attr("class", "legend")
          .attr("transform", function(d, i) { return "translate(" + legend_tabs[i] + ",-35)"; });
    
      legend.append("rect")
          .attr("x", 0)
          .attr("width", 18)
          .attr("height", 18)
          .style("fill", color);
    
      legend.append("text")
          .attr("x", 22)
          .attr("y", 9)
          .attr("dy", ".35em")
          .style("text-anchor", "begin")
          .style("font" ,"10px sans-serif")
          .text(function(d) { return d; });
    
      d3.selectAll(".axis path")
          .style("fill", "none")
          .style("stroke", "#000")
          .style("shape-rendering", "crispEdges")
    
      d3.selectAll(".axis line")
          .style("fill", "none")
          .style("stroke", "#000")
          .style("shape-rendering", "crispEdges")
    
      var movesize = width/2 - startp.node().getBBox().width/2;
      d3.selectAll(".legendbox").attr("transform", "translate(" + movesize  + ",0)");
}
//});
</script>