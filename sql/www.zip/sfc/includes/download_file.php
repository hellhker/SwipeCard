<?php
$filename = $_POST['filename'];
$filename = iconv('utf-8', 'big5', $filename);

if (file_exists($filename)) {
    header('Content-Encoding: none' );
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Transfer-Encoding: binary' );
    header('Content-Disposition: attachment; filename='.basename($filename));
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Cache-Control: public' );
    header('Pragma: public');
    header('Content-Length: ' . filesize($filename));
    readfile($filename);
}
?>