<?php
$color_array = array("#4F81BD","#C0504D","#8064A2","#9BBB59","burlywood1","brown1","gold3","darkturquoise","coral","gray8","deeppink2","AntiqueWhite3","azure2","chartreuse","hotpink","blueviolet","lemonchiffon3","khaki1","magenta");
$total_st = 1;
function Draw_PiePlot($width,$height,$title,$ydata,$legend_array,$value_type)
{
    global $color_array;
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = $cur_dir."../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($width,$height);
    
    // Set A title for the plot
    $graph->title->Set($title);
    $graph->SetBox(false);
    $graph->legend->SetFrameWeight(0);
	$graph->legend->SetFont(FF_CHINESE,FS_NORMAL,9);
	$graph->legend->SetColumns(2);
    //$graph->legend->Pos(0.05,0.78,"left","top");
    
    // Create
    $p1 = new PiePlot($ydata);
    $graph->Add($p1);
    
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.5,0.41);
    $p1->SetLegends($legend_array);
    
    if($value_type=="percent")
        $p1->value->SetFormat('%0.1f%%');
    else
        $p1->value->SetFormat('%0.1f%');
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function xyCallback($yval) {
  global $total_st;
  return floor($total_st*$yval).", ".round($yval,2)."%";
}

function Draw_PiePlot2_($width,$height,$title,$ydata,$legend_array,$value_type,$total_standard_time)
{
    global $color_array,$total_st;
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    //require_once('../jpgraph/src/jpgraph_pie3d.php');
    
    $total_st = $total_standard_time;
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = $cur_dir."../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($width,$height);
    // Set A title for the plot
    $graph->title->Set($title);
    $graph->SetBox(false);
    $graph->legend->SetFrameWeight(0);
	$graph->legend->SetFont(FF_CHINESE,FS_NORMAL,9);
	$graph->legend->SetColumns(2);
    $graph->legend->Pos(0.1,0.85,"left","center");
    $p1 = new PiePlot($ydata);
    $p1->SetSize(95);
    
    $p1->SetGuideLines();
    $p1->SetGuideLinesAdjust(1.4);
    $graph->Add($p1);
    
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.5,0.41);
    $p1->SetLegends($legend_array);
   // $p1->ExplodeSlice(3);
    $p1->value->SetFormat('%2.1f%%          ');
    $p1->value->SetFormatCallback('xyCallback');
    //$p1->SetShadow("lightgray");
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_PiePlot_($width,$height,$title,$ydata,$legend_array,$value_type,$total_standard_time)
{
    global $color_array,$total_st;
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_pie.php');
    require_once('../jpgraph/src/jpgraph_pie3d.php');
    
    $total_st = $total_standard_time;
    $pie_color = array();
    for($i=0;$i<count($ydata);$i++)
    {
        $pie_color[$i] = $color_array[$i];
    }
    
    $filename = $cur_dir."../img1/".rand().".png";  
    $map_links = "map_links";
    // Create the Pie Graph. 
    $graph = new PieGraph($width,$height);
    // Set A title for the plot
    $graph->title->Set($title);
    $graph->SetBox(false);
    $graph->legend->SetFrameWeight(0);
	$graph->legend->SetFont(FF_CHINESE,FS_NORMAL,9);
	$graph->legend->SetColumns(2);
    $graph->legend->Pos(0.27,0.85,"right","center");
    
    // Create
    
    //$p1 = new PiePlot($ydata);
    $p1 = new PiePlot3d($ydata);
    $p1->SetTheme("sand");
    $p1->SetSize(100);
    $p1->SetAngle(45);
    //$p1->SetStartAngle(45);
    $graph->Add($p1);
    
    $p1->ShowBorder();
    $p1->SetColor('black');
    $p1->SetSliceColors($pie_color);
    $p1->SetCenter(0.48,0.41);
    $p1->SetLegends($legend_array);
   // $p1->ExplodeSlice(3);
    $p1->value->SetFormat('%2.1f%%       ');
    $p1->value->SetFormatCallback('xyCallback');
    $p1->SetShadow("lightgray");
   // if($value_type=="percent")
   //     $p1->value->SetFormat('%0.1f%%');
   // else
   //     $p1->value->SetFormat('%0.1f%');
    
    @unlink($filename);
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_AccBarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata1,$ydata2,$legend_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.88,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,9);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL);
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,9);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL);
    $graph->xaxis->title->SetColor('red');
    
    $barplot1 = new BarPlot($ydata1);
    $barplot2 = new BarPlot($ydata2);
    $accbplot = new AccBarPlot(array($barplot1,$barplot2));
    $graph->Add($accbplot);
    
    $barplot1->SetColor("#4BFB05");
    $barplot1->SetFillColor("#4BFB05");
    $barplot1->SetLegend($legend_array[0]); 
    $barplot1->SetValuePos('top');
	$barplot1->value->SetFormat('%d');
	$barplot1->value->SetFont(FF_ARIAL, FS_NORMAL,9); 
    $barplot1->value->SetColor("#867DEC");
	$barplot1->value->Show(); 
    
    $barplot2->SetColor("gray");
    $barplot2->SetFillColor("gray");
    $barplot2->SetLegend($legend_array[1]);

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_AccLineBarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata1,$ydata2,$legend_array,$legend_amount_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height,"auto");
    $graph->SetScale("textlin",$ymin,$ymax);
    $graph->SetMargin(55,15,40,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(0);
    $graph->legend->SetPos(0.01,0.01,'right','top');
    $graph->legend->SetColumns(3);
    $graph->legend->SetColor('#1E1E1E');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,9);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    //$graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL);
    //$graph->yaxis->title->Set("數量(PCS)");
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
    
    $graph->yaxis->title->SetColor('#1D1D1D');
    $graph->yaxis->title->SetMargin(15);
    $graph->yaxis->SetColor('#1D1D1D');
    // Setup week as labels on the X-axis
    $xdata[0] = "                               ".$xdata[0]."\r\n\r\n                               ".$legend_amount_array[1]."\r\n                               ".$legend_amount_array[0];
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,9);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
    $graph->xaxis->title->SetColor('#1D1D1D');
    $graph->xaxis->SetColor('#1D1D1D');
    $graph->img->SetAntiAliasing(false);
    
    $ydata3 = array();
    for($i=0;$i<count($ydata1);$i++){
        $tmp_value = isset($ydata2[$i])?$ydata2[$i]:0;
        $ydata3[$i] = $ydata1[$i] + $tmp_value;
    }
    $barplot1 = new BarPlot($ydata1);
    $barplot2 = new BarPlot($ydata3);
    $gbarplot = new GroupBarPlot(array($barplot1,$barplot2));
    $graph->Add($gbarplot);
    $barplot1->SetColor("#5080B8");
    $barplot1->SetFillColor("#5080B8");
    $barplot1->SetLegend($legend_array[0]); 
    $barplot1->SetValuePos('top');
	$barplot1->value->SetFormat('%d');
	$barplot1->value->SetFont(FF_ARIAL, FS_NORMAL,9); 
    $barplot1->value->SetColor("black");
	//$barplot1->value->Show();
    
    $barplot2->SetColor("#B4E069");
    $barplot2->SetFillColor("#B4E069");
    $barplot2->SetLegend($legend_array[1]); 
    $barplot2->SetValuePos('top');
	$barplot2->value->SetFormat('%d');
	$barplot2->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
    $barplot2->value->SetColor("black");
    //$barplot2->value->Show();

    if(count($ydata1) > 1){
        $line1 = new LinePlot($ydata1);
        $graph->Add($line1);
        $line1->SetColor("black");
        $line1->SetLegend("趨勢線");
        $line1->SetWeight(2);
    //    $line1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
    //	$line1->mark->SetColor('green');
    //	$line1->mark->SetFillColor('green');
    	$line1->SetBarCenter();
        $line1->value->SetFormat('%d     ');
    	$line1->value->SetFont(FF_ARIAL, FS_NORMAL,9); 
        $line1->value->SetColor("black");
    	$line1->value->Show();
    }
    
    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_AccLinePlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata1,$ydata2,$legend_array,$legend_amount_array,$loss_array,$exclude_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    // Create the graph. These two calls are always required
    
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height,"auto");
    
    $graph->SetScale("textlin",$ymin,$ymax);
    $graph->SetMargin(55,15,40,70);
    $graph->SetShadow();
    
    $graph->yscale->ticks->Set($ticks);
    $graph->SetBox(false);
    $graph->legend->SetFrameWeight(0);
    $graph->legend->SetPos(0.01,0.01,'right','top');
    $graph->legend->SetColumns(3);
    $graph->legend->SetColor('#1E1E1E');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,9);
    
    // Create the linear plots for each category
    
    $dplot[] = new LinePLot($loss_array);
    $dplot[] = new LinePLot($exclude_array);
    $dplot[] = new LinePLot($ydata1);
    
    $dplot[0]->SetFillColor("red");
    $dplot[0]->SetLegend($legend_array[1]); 
    $dplot[0]->value->show();
    $dplot[1]->SetFillColor("blue");
    $dplot[1]->SetLegend($legend_array[2]);
    $dplot[1]->value->show();
    $dplot[2]->SetFillColor("green");
    $dplot[2]->SetLegend($legend_array[0]);
    $dplot[2]->value->show();
    
    // Create the accumulated graph
    $accplot = new AccLinePlot($dplot);
    
    // Add the plot to the graph
    $graph->Add($accplot);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
    
    $graph->yaxis->title->SetColor('#1D1D1D');
    $graph->yaxis->title->SetMargin(15);
    $graph->yaxis->SetColor('#1D1D1D');
    // Setup week as labels on the X-axis
    //$xdata[0] = "                               ".$xdata[0]."\r\n\r\n                               ".$legend_amount_array[1]."\r\n                               ".$legend_amount_array[0];
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,9);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
    $graph->xaxis->title->SetColor('#1D1D1D');
    $graph->xaxis->SetColor('#1D1D1D');
    $graph->img->SetAntiAliasing(false);
    
    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_BarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata,$legend_array,$bar_color)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.9,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $barplot = new BarPlot($ydata);
    $graph->Add($barplot);
    
    $barplot->SetColor($bar_color);
    $barplot->SetFillColor($bar_color);
    $barplot->SetLegend($legend_array[0]); 
    $barplot->SetValuePos('top');
	$barplot->value->SetFormat('%d');
	$barplot->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
    $barplot->value->SetColor("#867DEC");
	$barplot->value->Show();

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_GroupBarPlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$bar_count,$ydata_array,$legend_array,$color_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.92,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $bplot_array = array();
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i} = new BarPlot($ydata_array[$i]);
        array_push($bplot_array,${"barplot".$i});
    }
    $gbplot = new GroupBarPlot($bplot_array);
    $graph->Add($gbplot);
    
    for($i=0; $i<$bar_count; $i++)
    {
        ${"barplot".$i}->SetColor($color_array[$i]);
        ${"barplot".$i}->SetFillColor($color_array[$i]);
        ${"barplot".$i}->SetLegend($legend_array[$i]); 
        ${"barplot".$i}->SetValuePos('top');
    	${"barplot".$i}->value->SetFormat('%d');
    	${"barplot".$i}->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
        ${"barplot".$i}->value->SetColor($color_array[$i]);
    	${"barplot".$i}->value->Show();
    }

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_line4($width,$height,$datas)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",0,100);
    $graph->img->SetMargin(138,50,50,138); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set(20);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(0);
    $graph->legend->SetPos(0,0.7,'left','top');
    $graph->legend->SetColumns(1);
    $graph->legend->SetColor('#2E2E2E');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,9);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set("OEE indexes (%)");
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
    $graph->yaxis->title->SetColor('#2D2D2D');
    $graph->yaxis->title->SetMargin(10);
    $graph->yaxis->SetColor('#1D1D1D');
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($datas['xdata']);
    $graph->xaxis->SetFont(FF_CHINESE,FS_BOLD,9);
   // $graph->xaxis->title->Set("線別 (line)");
    //$graph->xaxis->title->SetMargin(10);
   // $graph->xaxis->title->SetFont(FF_CHINESE,FS_BOLD,9);
   // $graph->xaxis->title->SetColor('#2D2D2D');
    $graph->xaxis->SetColor('#1D1D1D');
    $graph->img->SetAntiAliasing(false);
    
    $line1 = new LinePlot($datas['oee']);
    $line2 = new LinePlot($datas['r1']);
    $line3 = new LinePlot($datas['r2']);
    $line4 = new LinePlot($datas['r3']);
    
    $graph->Add($line1);
    $graph->Add($line2);
    $graph->Add($line3);
    $graph->Add($line4);
    
    $line1->SetColor("#5EA0E3");
    $line1->SetLegend('整體設備效率OEE(%)');
    $line1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line1->mark->SetColor('#5EA0E3');
	$line1->mark->SetFillColor('#5EA0E3');
    $line1->mark->SetWidth(3);
    $line1->SetWeight(3);
	$line1->SetCenter();
    
    $line2->SetColor("#A0CB69");
    $line2->SetLegend('生產稼動率(%)');
    $line2->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line2->mark->SetColor('#A0CB69');
	$line2->mark->SetFillColor('#A0CB69');
    $line2->mark->SetWidth(3);
    $line2->SetWeight(3);
	$line2->SetCenter();
    
    $line3->SetColor("#F87700");
    $line3->SetLegend('產能效率(%)');
    $line3->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line3->mark->SetColor('#F87700');
	$line3->mark->SetFillColor('#F87700');
    $line3->mark->SetWidth(3);
    $line3->SetWeight(3);
	$line3->SetCenter();
    
    $line4->SetColor("#7A588F");
    $line4->SetLegend('製程良率(%)');
    $line4->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line4->mark->SetColor('#7A588F');
	$line4->mark->SetFillColor('#7A588F');
    $line4->mark->SetWidth(3);
    $line4->SetWeight(3);
	$line4->SetCenter();

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
function Draw_bar_pic($hour_array,$good_array,$diff_array,$uph_array)
{    
    // Create the graph. These two calls are always required
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_bar.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph(680,300,"auto");     
    $graph->SetScale("textlin"); 
    $graph->img->SetMargin(60,60,30,40); 
    $graph->SetFrame(true,'blue',1);
    //$graph->yscale->ticks->Set(200);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.88,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL);
    
    $graph->title->Set("每小時產能統計");
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $xtitle="時間(小時)";
    $ytitle="量數";
    $graph->ygrid->SetFill(false);
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL);
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(25);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($hour_array);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL);
    $graph->xaxis->title->SetColor('red');
    
    $barplot_good = new BarPlot($good_array);
    $barplot_total = new BarPlot($diff_array);
    $accbplot = new AccBarPlot(array($barplot_good,$barplot_total));
    $graph->Add($accbplot);
    
    $barplot_good->SetColor("#4BFB05");
    $barplot_good->SetFillColor("#4BFB05");
    $barplot_good->SetLegend("產出數"); 
    $barplot_good->SetValuePos('top');
    $barplot_good->value->SetFormat('%d');
	$barplot_good->value->SetFont(FF_ARIAL, FS_NORMAL,8); 
    $barplot_good->value->SetColor("#867DEC");
	$barplot_good->value->Show(); 
    
    $barplot_total->SetColor("gray");
    $barplot_total->SetFillColor("gray");
    $barplot_total->SetLegend("投入數");
    
    $p1 = new LinePlot($uph_array);
	$graph->Add($p1);
    $p1->SetColor("red");
	$p1->SetLegend('目標UPH:'.$uph_array[0]);

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}
//繪製兩條LinePlot
function Draw_DoubleLinePlot($width,$height,$ymin,$ymax,$ticks,$title,$xtitle,$ytitle,$xdata,$ydata,$ydata1,$legend_array)
{
    require_once('../jpgraph/src/jpgraph.php');
    require_once('../jpgraph/src/jpgraph_line.php');
    // Create the graph. These two calls are always required
    $filename = "../img1/".rand().".png";  
    $map_links = "map_links";
    $graph = new Graph($width,$height);
    $graph->SetScale("textint",$ymin,$ymax);
    $graph->img->SetMargin(50,15,20,70); //(left,right,top,bottom)
    //$graph->SetFrame(true,'blue',1);
    $graph->yscale->ticks->Set($ticks);
    //$graph->yaxis->SetTickPositions(array(0,200,400,600,800,1000,1200,1400), array(100,300,500,700,900,1100,1300));
    $graph->SetBox(false);
    
    $graph->legend->SetFrameWeight(1);
    $graph->legend->SetPos(0.5,0.9,'center','top');
    $graph->legend->SetColumns(4);
    $graph->legend->SetColor('#4E4E4E','#00A78A');
    $graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
    
    $graph->title->Set($title);
    $graph->title->SetFont(FF_CHINESE, FS_BOLD);
    
    $graph->yaxis->HideLine(false);
    $graph->yaxis->HideTicks(false,false);
    $graph->yaxis->title->Set($ytitle);
    $graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,'8');
    $graph->yaxis->title->SetColor('red');
    $graph->yaxis->title->SetMargin(20);
    // Setup week as labels on the X-axis
    $graph->xaxis->SetTickLabels($xdata);
    $graph->xaxis->SetFont(FF_CHINESE, FS_NORMAL,8);
    $graph->xaxis->title->Set($xtitle);
    $graph->xaxis->title->SetMargin(10);
    $graph->xaxis->title->SetFont(FF_CHINESE, FS_NORMAL,'8');
    $graph->xaxis->title->SetColor('red');
    
    $line1 = new LinePlot($ydata);
    $graph->Add($line1);
    
    $line2 = new LinePlot($ydata1);
    $graph->Add($line2);
    
    $line1->SetColor("red");
    $line1->SetLegend($legend_array[0]);
    $line1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
	$line1->mark->SetColor('red');
	$line1->mark->SetFillColor('red');
	$line1->SetCenter();
    
    $line2->SetColor("green");
    $line2->SetLegend($legend_array[1]);
    $line2->mark->SetType(MARK_SQUARE,'',1.0);
	$line2->mark->SetColor('green');
	$line2->mark->SetFillColor('green');
	$line2->SetCenter();

    @unlink($filename);	
    // Display the graph
    $graph->Stroke($filename);
    $imgMap = $graph->GetHTMLImageMap($map_links);
    //echo $imgMap;
    return $filename;
}

function Draw_DoubleBarPlotAndLinePlot1($width,$height,$yman,$title,$xtitle,$ytitle,$ytitle1,$xdata,$ydata,$ydata1,$ydata2,$legend_array)
{
require_once('../jpgraph/src/jpgraph.php');
require_once('../jpgraph/src/jpgraph_line.php');
require_once('../jpgraph/src/jpgraph_bar.php');

$graph = new Graph($width,$height,"auto"); //创建新的Graph对象 
$graph->SetScale("textlin"); //設置刻度值類型,x和y
$graph->SetY2Scale("lin",0,$yman); //設置y軸的值，這裡是從0-$yman,y2
$graph->SetY2OrderBack(false);       //Y2軸顯示在上層
$graph->img->SetMargin(50,50,40,80); //设置图像边距 :(60,50,40,80)
$map_links = "map_links";

$BarPlot=new BarPlot($ydata); //$ydata:有效產能, $legend_array[0]
$BarPlot2=new BarPlot($ydata1); //$ydata1:實際C/T,$legend_array[1]
$BarPlots = new GroupBarPlot(array($BarPlot,$BarPlot2));
$graph->Add($BarPlots); //将曲线放置到图像上 
$lineplot = new LinePlot($ydata2); //创建BarPlot对象 
//$line->SetLineWeight(150);
$lineplot->SetBarCenter(); //折綫顯示在柱條中間
$graph->AddY2($lineplot); //将曲线放置到图像上 
$lineplot->SetStyle(1);

$graph->title->Set($title);
$graph->title->SetMargin (0,400,400,0); 
//$graph->title->SetFont(FF_CHINESE, FS_BOLD);
$graph->xaxis->title->Set($xtitle); //设置坐标轴名称 
$graph->yaxis->title->Set($ytitle);   //xaxis:x軸名稱，yaxis:y軸名稱
$graph->yaxis->title->SetMargin(0,10,0.1,0); //y2axis改為yaxis
$graph->y2axis->title->Set($ytitle1); 
//$graph->y2axis->title->SetMargin(10,0,0.1,0);
//$graph->y2axis->title->SetMargin(25,0,0.2,0);
$graph->y2axis->title->SetMargin(25);
$graph->xaxis->SetTickLabels($xdata);
$graph->y2axis->title->SetFont(FF_CHINESE,FS_NORMAL,14); 
$graph->title->SetFont(FF_CHINESE,FS_NORMAL,18);//設置圖標標題類型
$graph->xaxis->title->SetFont(FF_CHINESE,FS_NORMAL,17);
$graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,17);

$graph->y2axis->SetFont(FF_CHINESE,FS_NORMAL,17); //設置y2軸的字體和大小  （從12開始調1.3倍）
$graph->xaxis->SetFont(FF_CHINESE,FS_NORMAL,17);  //設置y軸的字體和大小
$graph->yaxis->SetFont(FF_CHINESE,FS_NORMAL,17);  //設置x軸的字體和大小
//$line->SetColor("#FFA500"); //设置颜色 
$lineplot->SetColor("#FFA500");
$lineplot->SetWeight(20);
$lineplot->SetLegend($legend_array[2]);

$BarPlot->SetColor("#5080B8"); 
$BarPlot->SetFillColor("#5080B8"); 
$BarPlot->SetLegend($legend_array[0]); //设置图例名称 

$BarPlot2->SetColor("#B4E069"); 
$BarPlot2->SetFillColor("#B4E069"); 
$BarPlot2->SetLegend($legend_array[1]);
$BarPlot2->SetValuePos('top');
$BarPlot2->value->SetFormat('%0.2f');
$BarPlot2->value->SetFont(FF_ARIAL, FS_NORMAL,15); 
$BarPlot2->value->SetColor("#4E4E4E");
$BarPlot2->value->Show();
 
$graph->legend->SetColor('#4E4E4E');
$graph->legend->SetFont(FF_CHINESE, FS_NORMAL,15);//設置圖例字體類型
//$graph->legend->SetLayout(LEGEND_HOR);
//$graph->legend->Pos(0.4, 0.95, 'center', 'bottom');//图例的位置 0.4，0.95是以右上角为基准的，0.4是距左右距离，0.95是上下距离。
$graph->legend->Pos(0.5,0.90,"center","bottom"); 
$filename = "../img1/".rand().".png";
@unlink($filename);
$graph->Stroke($filename);//輸出圖像
return $filename;
}

function Draw_DoubleBarPlotAndLinePlot($width,$height,$yman,$title,$xtitle,$ytitle,$ytitle1,$xdata,$ydata,$ydata1,$ydata2,$legend_array)
{
require_once('../jpgraph/src/jpgraph.php');
require_once('../jpgraph/src/jpgraph_line.php');
require_once('../jpgraph/src/jpgraph_bar.php');

$graph = new Graph($width,$height,"auto"); //创建新的Graph对象 
$graph->SetScale("textlin"); 
$graph->SetY2Scale("lin",0,$yman); 
$graph->SetY2OrderBack(false);       //Y2軸顯示在上層
$graph->img->SetMargin(40,50,20,70); //设置图像边距 

$graph->title->Set($title); //设置图像标题 

$BarPlot=new BarPlot($ydata); 
$BarPlot2=new BarPlot($ydata1);
$BarPlots = new GroupBarPlot(array($BarPlot,$BarPlot2));
$graph->Add($BarPlots); //将曲线放置到图像上 
$line = new LinePlot($ydata2); //创建BarPlot对象 
$line->SetWeight(100);
$line->SetBarCenter(); //折綫顯示在柱條中間
$line->SetStyle(1);
$line->SetColor("#FFA500"); //设置颜色 
$line->SetLegend($legend_array[2]);
$graph->AddY2($line); //将曲线放置到图像上 


$graph->xaxis->title->Set($xtitle); //设置坐标轴名称 
$graph->xaxis->title->SetFont(FF_CHINESE,FS_NORMAL,12);
$graph->xaxis->SetTickLabels($xdata);

$graph->yaxis->title->Set($ytitle); 
$graph->yaxis->title->SetMargin(0,10,0.1,0);
$graph->yaxis->title->SetFont(FF_CHINESE,FS_NORMAL,12);

$graph->y2axis->title->Set($ytitle1); 
$graph->y2axis->title->SetMargin(10,0,0.1,0);
$graph->y2axis->title->SetFont(FF_CHINESE,FS_NORMAL,12); 

$graph->title->SetFont(FF_CHINESE,FS_NORMAL,18);

$BarPlot->SetColor("#5080B8"); 
$BarPlot->SetFillColor("#5080B8"); 
$BarPlot->SetLegend($legend_array[0]); //设置图例名称 

$BarPlot2->SetColor("#B4E069"); 
$BarPlot2->SetFillColor("#B4E069"); 
$BarPlot2->SetLegend($legend_array[1]);

$graph->legend->SetColor('#4E4E4E');
$graph->legend->SetFont(FF_CHINESE, FS_NORMAL,8);
$graph->legend->Pos(0.4,0.95,"center","bottom"); 

$filename = "../img1/".rand().".png";
@unlink($filename);
$graph->Stroke($filename);
return $filename;
}




?>