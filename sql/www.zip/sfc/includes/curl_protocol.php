<?php
   //新增WeChatID
  function httpPost($url,$params)
  {
  	
	  $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
	      $postData .= $k . '='.$v.'&'; 
	   }
	   $postData = rtrim($postData, '&');
	 
	    $ch = curl_init();  
	    $this_header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
	    $headers = array (
         "Content-Type: application/json; charset=utf-8",
         "Content-Length: " .strlen($postData)      
     );
     // curl_setopt($ch,CURLOPT_HTTPHEADER,$this_header);
	    curl_setopt($ch,CURLOPT_URL,$url);
	    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	    curl_setopt($ch,CURLOPT_HEADER, false); 	   
	    curl_setopt($ch, CURLOPT_POST, 1);
	    curl_setopt($ch, CURLOPT_POSTFIELDS,$postData);		
	 
	    $output=curl_exec($ch);
	   
	    
	    $statusCode = curl_getInfo($ch, CURLINFO_HTTP_CODE);
	    //return $statusCode;	 
      curl_close($ch);
	    return $output; 
      
	    
  }
  //修改WeChatID
  function httpPut($url,$params)
  { 
  	  	
	   $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
	      $postData .= $k . '='.$v.'&'; 
	   }
	   $postData = rtrim($postData, '&'); 
	   
	   $channel = curl_init($url."?".$postData);
     curl_setopt($channel, CURLOPT_RETURNTRANSFER, true);
     curl_setopt($channel, CURLOPT_CUSTOMREQUEST, "PUT");
     curl_setopt($channel, CURLOPT_SSL_VERIFYPEER, false);
     curl_setopt($channel, CURLOPT_CONNECTTIMEOUT, 10);  
     
     $output =  curl_exec($channel);
     $statusCode = curl_getInfo($channel, CURLINFO_HTTP_CODE);
     curl_close($channel);    
     return $output;	 
  }
  // 刪除WeChatID
  function httpDel($url,$noteid,$userid)
  {
  	 $channel = curl_init($url."/".$noteid."?updateUser=".$userid);
		 curl_setopt($channel, CURLOPT_CUSTOMREQUEST, "DELETE");
		 curl_setopt($channel, CURLOPT_HEADER, false);
		 curl_setopt($channel, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($channel, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"OAuth-Token: $token"));
 
// Make the REST call, returning the result
     $output = curl_exec($channel);
     $statusCode = curl_getInfo($channel, CURLINFO_HTTP_CODE);
  	 curl_close($channel);    
     return $output;	 
  }
  
  function httpPost_new($url,$postData)
  {
  	  $cnt=0;
  	  $sendstr ="";
		  foreach($postData as $key=>$value)
		  {
				  if($cnt==0)
				  	 $sendstr = $sendstr."{";
				  if($cnt>0)
				  $sendstr = $sendstr.",";
				  $sendstr = $sendstr."\"".$key."\":".$value;  
				  $cnt++;	
			}
		  $sendstr = $sendstr."}";
		  
		  // Setup cURL
			$ch = curl_init($url);
			curl_setopt_array($ch, array(
			    CURLOPT_POST => TRUE,
			    CURLOPT_RETURNTRANSFER => TRUE,
			    CURLOPT_HTTPHEADER => array(
			        'Authorization: '.$authToken,
			        'Content-Type: application/json'
			    ),
			    CURLOPT_POSTFIELDS => $sendstr
			));
			
			// Send the request
			$response = curl_exec($ch);
			
			// Check for errors
			if($response === FALSE){
			    die(curl_error($ch));
			}
		  return $response;
  }
  
  //通知加入專案群組
  function project_add($note_id,$project_name)
  {
		$url = "http://10.8.91.142:8080/WeChatWebService/WeChat/ModifyGroupMember?UpdateUser=5726";
		$userdata = "{\"groupName\":\"".$project_name."\",\"addMembers\":[\"".$note_id."\"],\"delMembers\":[]}";
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
		        CURLOPT_POST => TRUE,
				    CURLOPT_RETURNTRANSFER => TRUE,
				    CURLOPT_HTTPHEADER => array(
				        'Authorization: '.$authToken,
				        'Content-Type: application/json'
				    ),
				    CURLOPT_POSTFIELDS => $userdata
				));
				
		// Send the request
		$response = curl_exec($ch);
				
		// Check for errors
		if($response === FALSE){
		    //die(curl_error($ch));
		}
		return $response;
	}
  
  //通知退出專案群組  
  function project_del($note_id,$project_name)
  {
		$url = "http://10.8.91.142:8080/WeChatWebService/WeChat/ModifyGroupMember?UpdateUser=5726";
		$userdata = "{\"groupName\":\"".$project_name."\",\"addMembers\":[],\"delMembers\":[\"".$note_id."\"]}";
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
		        CURLOPT_POST => TRUE,
				    CURLOPT_RETURNTRANSFER => TRUE,
				    CURLOPT_HTTPHEADER => array(
				        'Authorization: '.$authToken,
				        'Content-Type: application/json'
				    ),
				    CURLOPT_POSTFIELDS => $userdata
				));
				
		// Send the request
		$response = curl_exec($ch);
				
		// Check for errors
		if($response === FALSE){
		    //die(curl_error($ch));
		}
		return $response;
	}
    
    //新增刪除群組
    function edit_group($newgrps,$delgrps)
    {
        $url = "http://10.8.91.142:8080/WeChatWebService/WeChat/ModifyChatGroup?UpdateUser=5726";
        $userdata = array("newGroups"=>$newgrps,"delGroups"=>$delgrps);
        $addvar = "";
        $delvar = "";
        if(count($newgrps)==0)
        	$addvar = "";
        else
        {
          	for($x=0;$x<count($newgrps);$x++)
          	{
          		 if($x>0)
          		 		$addvar .= ",";
          		 $addvar = $addvar."\"".$newgrps[$x]."\"";
          	}
          }
          if(count($delgrps)==0)
        	$delvar = "";
        else
        {
          	for($x=0;$x<count($delgrps);$x++)
          	{
          		 if($x>0)
          		 		$delvar .= ",";
          		 $delvar = $delvar."\"".$delgrps[$x]."\"";
          	}
          }  	
        $userdata = array("newGroups"=>'['.$addvar.']',"delGroups"=>'['.$delvar.']');
        $result = httpPost_new($url,$userdata);
          return  $result;		
    }
    
    // 新增專案聊天群組
    function group_chat_add($add_arr)
    {
        $result = json_decode(edit_group($add_arr,null));
        $add_group = $result->AddNewGroup;
        $invalid_group = $result->InvalidGroups;
        
        $status_code = $add_group->StatusCode;
        $Err_msg = $add_group->ErrMsg;
            
        return $status_code;
    }
    
    // 刪除專案聊天群組
    function group_chat_del($del_arr)
    {
        $result = json_decode(edit_group(null,$del_arr));
        $del_group = $result->DelGroup;
        $invalid_group = $result->InvalidGroups;
        
        $status_code = $del_group->StatusCode;
        $Err_msg = $del_group->ErrMsg;
            
        return $status_code;
    }
    
    function alarm_wechat($username,$project_name)
    {
        $time = date("H:i");
        $oci_conn = oci_new_connect('alarmdblinker','f0xlink','10.8.91.142:1521/ALARMTESTDB','AL32UTF8');
        $sys_name = "SFC";
        $app_name = "MsgBox";
        $fac_name ="FQ";
        $msg_title = $username." ".$time."退出了群組";
        $msg_content = $username." ".$time."退出了群組";
        $msg_send_tp = "43";
        $msg_sender = "5726";
        $send_by_dep = "9569";
        //$rec_grp_name ="WeChat群聊測試";
        $rec_grp_name = $project_name;
        $app_parm = "";
        $wechat_app_name = "富強連接器";
        if($oci_conn!=FALSE)
        {
          $insert_sql ="Insert into ALARMUSER.ALARM_MESSAGE_TMP(SYSTEM_NAME,APP_NAME,FACTORY_CODE,MESSAGE_TITLE,MESSAGE_CONTENT,MESSAGE_SEND_TYPE,MESSAGE_SENDER,SEND_BY_DEPARTMENT,RECEIVED_GROUP_NAME,APPEND_PARAMETER,WECHAT_APP_NAME) VALUES('".$sys_name."','".$app_name."','".$fac_name."','".$msg_title."','".$msg_content."','".$msg_send_tp."','".$msg_sender."','".$send_by_dep."','".$rec_grp_name."','".$app_parm."','".$wechat_app_name."')";
        	$stmt = oci_parse($oci_conn, $insert_sql);  	
        	oci_execute($stmt, OCI_NO_AUTO_COMMIT);
        	oci_commit($oci_conn);
            oci_close($oci_conn);
        	return 1;
        }
        else
        	return 0;
    }
  
  /*
  //新增WeChatID
  $userdata = array("EmployeeID" => '7336',"EmpName" =>'吳迪',"WeChatID"=> 'edwardt',"DeptID"=>'9569',"Notes_ID"=>'Edwardt_Wu');   
  $var1 = "[".json_encode($userdata)."]";
 // echo $var1;
  $NewWeChat_array = array("NewWeChatUsers"=>$var1,"UpdateUserID"=>"7336");
  $posturl = "http://10.8.30.241:8080/WeChatWebService/WeChat/AddUser";
  $url = "http://192.168.11.54/request.php";
  
  $result = json_decode(httpPost($posturl,$NewWeChat_array));

  $status_code = $result->StatusCode;
  $Err_msg = $result->ErrMsg;
  if($status_code==500)
  	echo $Err_msg."<BR>";
  else if($status_code==200)
  	echo "新增使用者成功<BR>";
  else
  	;
  	*/
  /*
  //修改WeChatID
  //$stringdata = 'UpdateWeChatUser=[{"EmployeeID":"7336","EmpName":"吳迪","WeChatID":"wuti123","DeptID":"9569","Notes_ID":"Edwardt_Wu"}]&UpdateUserID=7336';		
  $updatedata = array("EmployeeID" => '7336',"EmpName" =>'吳迪',"WeChatID"=> 'joke710927',"DeptID"=>'9569',"Notes_ID"=>'Edwardt_Wu',"WeChatDeptID"=>'0');   
  $var2 = "[".json_encode($updatedata)."]";
  $UpdateWeChat_array = array("UpdateWeChatUser"=>$var2,"UpdateUserID"=>"7336");  
  $puturl = "http://10.8.30.241:8080/WeChatWebService/WeChat/UpdateUser";
  $url = "http://192.168.11.54/request.php";
  
  //$result2 = httpPut($puturl,$UpdateWeChat_array);
 
  $result2 = json_decode(httpPut($puturl,$UpdateWeChat_array));
  $status_code2 = $result2->StatusCode;
  
  $Err_msg = $result2->ErrMsg;
  if($status_code2==500)
  	echo $Err_msg;
  else if($status_code2==200)
  	echo "WeChatID修改成功<BR>";
  else
  	;
  */
/*
 // 刪除WeChatID
  $del_url = "http://10.8.30.241:8080/WeChatWebService/WeChat/DeleteUser";
  $Note_id = "denil_chuang";
  $userid_no = "7575"; 
  $result3 = json_decode(httpDel($del_url,$Note_id,$userid_no));
  $status_code3 = $result3->StatusCode;  
  $Err_msg = $result3->ErrMsg;
  if($status_code3==500)
  	echo $Err_msg;
  else if($status_code3==200)
  	echo "WeChatID刪除成功<BR>";
  else
  	;
*/
?>