<?php

    // 資料庫設定
    $host_sql = '192.168.64.233';
    $username_sql = 'root';
    $password_sql = 'foxlink';

    // 聯結資料庫
    $link = mysql_connect($host_sql, $username_sql, $password_sql) or die('無法連結資料庫');
    mysql_select_db('test', $link);
    mysql_query('SET NAMES UTF8');

    // 預設選項
    $data['0'] = '';

    // 只有在 parentId 與 levelNum 都存在的情況下，才進行資料庫的搜尋
    if (0 !== (int) $_GET['id'] && 0 !== (int) $_GET['lv']) {
        $parentId = (int) $_GET['id'];
        $levelNum = (int) $_GET['lv'];
        
        $query = sprintf("SELECT id, name FROM real_structure WHERE parentId = %d AND levelNum = %d order by name ASC", $parentId, $levelNum);
        $result = mysql_query($query, $link);
        while ($row = mysql_fetch_assoc($result)) {
        
            // 將取得的資料放入陣列中
            $data[$row['id']] = $row['name'];
        }
    }
    
    // 將陣列轉換為 json 格式輸入，利用JSON.php提供的方法，讓PHP5.2以前版本可以使用json_encode及json_decode兩個函式	
    if(!function_exists('json_encode'))  
    {  
        include('JSON.php');  
        function json_encode($val)  
        {  
            $json = new Services_JSON();  
            return $json->encode($val);  
        }  
      
        function json_decode($val)  
        {  
            $json = new Services_JSON();  
            return $json->decode($val);  
        }  
    }  
    echo json_encode($data);
    mysql_close($link);
?>
