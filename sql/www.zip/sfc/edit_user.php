﻿<?
require_once("fq_mysql_connect.php");
@require_once("includes/xajax_core/xajax.inc.php");
//建立物件
$xajax = new xajax(); 
//$xajax->setFlag("debug",true);
//註刪回應函數
$xajax->registerFunction("checkPwd");
//處理非同步要求
$xajax->processRequest();
$xajax->configure( 'defaultMode', 'synchronous' );//設成同步

function checkPwd($uid,$pwd)
{
    $objResponse = new xajaxResponse();
    global $mysqli,$MYSQL_LOGIN,$MYSQL_PASSWORD,$MYSQL_HOST;
    connect_db("sfc");
    
    $sql = "select * from user_data where `UserID`='".$uid."' and `Password`='".$pwd."'";
    $rows = $mysqli->query($sql);
    $num_row = $rows->num_rows;
    mysqli_free_result($rows);
    $mysqli->close();
    
    if($num_row == 0)
    {    
        $objResponse->alert("帳號或密碼有誤，請回首頁-->\"忘記密碼?\"進行查詢!!");
        $objResponse->setReturnValue(false);
    }
    else
    {
        $objResponse->setReturnValue(true);
    }
    return $objResponse;
}
?>
<HTML>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?
$xajax->printJavascript("includes"); //輸出用戶
?>
</head>
<BODY bgcolor="#FFFFFF" BACKGROUND="lbg.jpg" >
<script language="JavaScript">
function show_window()
{
	var newtab = window.open("forget_pwd.php", 'SFC',config='height=200px,width=430px,scrollbars=no,resizable=no,status=no');
	newtab.focus(); 
}
function check()  //.......................檢查輸入的空格是否有資料
{  
  var uid = document.main.Usname.value;
  var pwd = document.main.pwd.value;
  if(document.main.Usname.value.length < 1) {
    window.alert("請輸入帳號");
    return false;
  }
  if(!checkVal(document.main.Usname.value))
  {	
  	 window.alert("帳號只能是英文或數字!");
  	 return false;
  }
  return xajax_checkPwd(uid,pwd);
}
function checkVal( str ) 
{
    var regExp = /^[\.|\d|a-zA-Z_-]+$/;
    if (regExp.test(str))
        return true;
    else
        return false;
}
</script>
<CENTER>
<h3>編輯個人資料</h3>
<p>
<form method=post name=main action=edit_user1.php onSubmit="return check()">
<table border=2  width='45%' >
<tr>
<td colspan=2>編輯個人資料
</tr>
<tr>          
    <td><font color=black>使用者帳號:</font></td>          
    <td><INPUT Type="Text"  Name="Usname"  Size="10"></td>    
</tr>
<tr>
		<td><font color=black>使用者密碼:</font></td>          
    <td><INPUT Type="password"  Name="pwd"  Size="20"></td>          
</tr>  
<tr>
<td colspan=2><CENTER><INPUT Type=Submit Name=Send Value="送出">
<input Type=Reset  Value="重寫 ">
<INPUT Type=button Name=Send Value="忘記密碼" onclick="show_window()">
</CENTER></td> 
</tr>  
</table>
</form>
</BODY>
</HTML> 
