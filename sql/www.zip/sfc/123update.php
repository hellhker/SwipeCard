<?php
$hostname = "192.168.64.233";
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$counter = 1;
	$mysqli->query("SET NAMES 'utf8'");
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');


if ($_POST) {
	$pro=$_POST['pro'];
	$s_uid=$_POST['UserID'];
	$s_username=$_POST['ChineseName'];
	$s_email=$_POST['EMail'];
	$strPro=$_POST['Projname'];
	$strReport=$_POST['report_right'];
	$strRee=$_POST['err_right'];
	$Personal_Notice=$_POST['Personal_Notice'];
	$sql1="select * from `user_setting_chat` where `UserID`='$s_uid'";
	$rs=$mysqli->query($sql1);
	if($rs->num_rows > 0){
	$row=$rs->fetch_assoc();
	$row1=$row['Personal_Notice'];
	$arr=explode('*', $row1);
	foreach ($arr as $key => $value) {
		if(strstr($arr[$key],$pro)){
		unset($arr[$key]);
		}
	}
	$str=implode('*',$arr);
	if($str){
		if($_POST['Personal_Notice']){
			$Personal_Notice=$_POST['Personal_Notice'].'*'.$str;
		}else{
		$Personal_Notice=$str;
		}
	}else{
	$Personal_Notice=$_POST['Personal_Notice'];
	}
	//$arr1=explode('*', $Personal_Notice);
	if (strlen($Personal_Notice)>1000) {
		echo "開啟的數量過多";die;
	}
	$sql2="UPDATE  `user_setting_chat` SET  `Personal_Notice` =  '$Personal_Notice' WHERE  `UserID` ='$s_uid'";
	}else{
	if (strlen($Personal_Notice)>1000) {
		echo "開啟的數量過多";die;
	}
	$sql2="insert into `user_setting_chat`(`UserID`,`ChineseName`,`EMail`,`Projname`,`report_right`,`err_right`,`Personal_Notice`) values('$s_uid','$s_username','$s_email','$strPro','$strReport','$strRee','$Personal_Notice')";
	}
	mysqli_free_result($rs);
	$mysqli->query($sql2);
	$rc=mysqli_affected_rows($mysqli);
	if ($rc>0) {
		echo "修改成功，幾分鐘后生效！";
	}else{
	echo "沒有數據改動！";
	}
}
$mysqli->close();
?>