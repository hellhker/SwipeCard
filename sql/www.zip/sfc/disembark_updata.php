<?php
    $user=$_POST['username'];
    $psw=$_POST['password'];
    $user1=$_GET['user'];
    $psw1=$_GET['password'];
    $hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
    
    $mysqli = new mysqli($hostname,$username,$password,$database_name);
	$mysqli->query('SET NAMES utf8');	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
    
        
    if($user!=''&&$psw!=''){
        $sql = "select a.* , b.name from user_data a LEFT JOIN group_structure b on a.`DepartmentCode`=b.`Depart_Code` where a.UserID='$user' and  a.Password='$psw'";
    }else{
        $sql = "select a.* , b.name from user_data a LEFT JOIN group_structure b on a.`DepartmentCode`=b.`Depart_Code` where a.UserID='$user1' and  a.Password='$psw1'";
    }
        
    
    $user_data=$mysqli->query($sql);
    $user_num=$user_data->num_rows;
    if($user_num >0){
        $user_row=$user_data->fetch_row();
         $userID=$user_row[1];
         $psw=$user_row[2];
         $user=$user_row[3];
         $DepartmentCode=$user_row[5];
         $modification_prove=$user_row[19];
         $name=$user_row[20];
    }else{
        echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
            echo "<SCRIPT Language=javascript type=\"text/javascript\">";
            echo "window.alert('帳號密碼不正確!!')";
            echo "</SCRIPT>";
            echo "<script language=\"javascript\">";
            echo "location.href='disembark.php'";
            echo "</script>";
    }


?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="../SFC/jquery-1.9.1.js"></script>
<style type="text/css">
    .read{
        border:0;
    }
</style>
<script type="text/javascript">


function update(v){
    if(v=="修改"||v=="新增"){
        $(".chang").css('border','1px solid black');
        $(".chang").removeAttr('readonly');
        if(v=="修改"){
          $("#button").val("確定修改");
        }if(v=="新增"){
          $("#button").val("確定新增");
        }
    }else{
      $("#submit").submit();
    } 

      
}
</script>
<style>

#login_click{ margin-top:32px; height:40px;}
#login_click a 
{
    

    text-decoration:none;
	background:#2f435e;
	color:#f2f2f2;
	
	padding: 10px 30px 10px 30px;
	font-size:16px;
	font-family: 微软雅黑,宋体,Arial,Helvetica,Verdana,sans-serif;
	font-weight:bold;
	border-radius:3px;
	
	-webkit-transition:all linear 0.30s;
	-moz-transition:all linear 0.30s;
	transition:all linear 0.30s;
	
	}
   #login_click a:hover { background:#c7a061; }

</style>
</head>
<center>
<div>
<?php echo $user_row[3]; ?>您好：<br /><br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font color="red" size="3" face="新細明體"><b>部門代碼未填寫或有異動者，請於12/8前完成更改，逾時可能會造成無法登入或帳號被移除等情形</b></font>
</div><br />

<form method="post" id="submit" action="disembark_updata_realize.php">
<table border=2  width='55%' >
    <input type="hidden" value="<?= $psw ?>" name="psw" />
    <table border=2  width='55%' >
<tr>          
    <td>
        <font color=black>使用者帳號:</font>
    </td>  
    <td colspan="2">
        <input type="text" name="UserID" value="<?php echo $userID;?>" class="read" readonly="readonly" />
    </td>     
</tr>

<tr>          
<td>
    <font color=black>中文姓名:</font>
</td> 
<td colspan="2">
    <input type="text" name="ChineseName" value="<?php echo $user;?>" class="read" readonly="readonly" />
</td>   
</tr> 

<tr>          
<td>
    <font color=black>部門:</font>
</td> 
<td colspan="2">
    <input type="text" name="name" value="<?php echo $name;?>" class="read" readonly="readonly" />
</td>   
</tr> 

<tr>          
    <td >
        <font color=black>部門代碼:<br/></font>
    </td> 
    <td >
        <input type="text" name="DepartmentCode" value="<?php echo $DepartmentCode;?>" class=" chang" readonly="readonly" />
        <?php 
        $property=='';
        if($modification_prove==1){
            $property = "hidden";
        }
        else{
            $property="button";
        }?>
        <input type="<?php echo $property ?>" id="button" value="修改" onclick="update(this.value);" /><br />
        
        
    </td> 
    <td>
        <font color="red" size="2" face="新細明體"><b>部門代碼只能修改一次，修改時請仔細填寫,如果修正錯誤，請聯繫黃祥鋒  分機：33461</b></font>
    </td>
</tr>
</table>
</form>
</center>
<center>
     <div id="login_click"><br /><br /><br />
            <a id="btlogin" href="http://scbg-iot.foxlink.com.tw/WELCOME.PHP#" id="login_click" target="_blank">Welcome to CABG  IoT-Platform</a>
    </div>
    </<center>
</html>
