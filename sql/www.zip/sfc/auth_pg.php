<?php 
//ob_start();
putenv("TZ=Asia/Taipei");
session_start();
$PG_LOGIN = "root";
$PG_PASSWORD = "foxlink";
$PG_HOST = "192.168.64.233";

$conn = pg_connect("host=".$PG_HOST." dbname=sfc user=".$PG_LOGIN." password=".$PG_PASSWORD) or die("Can't connect to database".pg_last_error());

if((strcmp($_SESSION["ssn_usr"],"")!=0)&& (strcmp($_SESSION["ssn_psd"],"")!=0))
{
	$username = $_SESSION["ssn_usr"];
	$password = $_SESSION["ssn_psd"];
			
	$user_sql = "SELECT a.ID,a.UserID,a.ChineseName,a.EMail,a.DepartmentCode,b.name,a.Division,b.fac_code,a.GroupName FROM `user_data` a left join `group_structure` b on a.DepartmentCode=b.Depart_Code Where a.UserID='$username' And a.Password = '$password'";
	$user_rows = pg_query($conn,$user_sql);
	$user_num = pg_num_rows($user_rows);
	if($user_num > 0)
	{
			$user_row = pg_fetch_row($user_rows);
			$ShowID = $user_row[1];
			$ChName = $user_row[2];
			$emailaddr = $user_row[3];
            $dept_code = $user_row[4];
			$dpment = $user_row[5];
			$division = $user_row[6];
			$factory = $user_row[7];
			$groupname = $user_row[8];
			
			$group_sql = "SELECT * FROM `group_table` where GroupName='$groupname'";
			$group_rows = pg_query($conn,$group_sql);
			$group_row = pg_fetch_row($group_rows);
			
			$sfc_wip_query = $group_row[3];
			$sfc_wip_modify = $group_row[4];
			$sfc_repair_query = $group_row[5];
			$sfc_repair_modify = $group_row[6];
			$sfc_product_query = $group_row[7];
			$sfc_product_modify = $group_row[8];
			$sfc_yield_query = $group_row[9];
			$sfc_yield_modify = $group_row[10];
			$sfc_alert_query = $group_row[11];
			$sfc_alert_modify = $group_row[12];
			$sfc_clipboard_query = $group_row[13];
			$sfc_clipboard_modify = $group_row[14];
			$aoi_product_query = $group_row[15];
            $aoi_product_modify = $group_row[16];
			$aoi_detect_query = $group_row[17];
            $aoi_setting_query = $group_row[18];
            $aoi_setting_modify = $group_row[19];
            $erp_fq_conn_query = $group_row[20];
            $erp_ks_conn_query = $group_row[21];
            $erp_igbu_query = $group_row[22];
            $erp_lk_cable_query = $group_row[23];
            $erp_ks_cable_query = $group_row[24];
            $erp_qy_cable_query = $group_row[25];
            $fab_query = $group_row[26];
            $user_add = $group_row[27];
            $dept_modify = $group_row[28];
            pg_free_result($group_rows);
            pg_free_result($user_rows);
            pg_close($conn);
	}
    else 
	{
	        pg_close($conn);
            session_write_close();
	        echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
	        echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
            echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
            echo "</SCRIPT>"; 
            echo "<script language=\"javascript\">"; 
            echo "top.location.href='http://".$_SERVER['HTTP_HOST']."/sfc/index.php'";  
            echo "</script>"; 
	}
}
else
{
    pg_close($conn);
    session_write_close();
    echo "<meta http-equiv='content-type' content='text/html; charset=UTF-8'>";
    echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
    echo "window.alert('使用者帳號不存在或密碼錯誤!!')";  
    echo "</SCRIPT>"; 
    echo "<script language=\"javascript\">";
    echo "top.location.href='http://".$_SERVER['HTTP_HOST']."/sfc/index.php'"; 
    echo "</script>";
}
session_write_close();
//關閉輸出暫存器
//ob_end_flush();
?>