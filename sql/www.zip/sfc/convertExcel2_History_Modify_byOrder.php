﻿<HTML>
<?php
 $form_filename = "report.xls";
 
 header("Content-Type: application/octetstream; name=$form_filename; charset=UTF-8");
 header("Content-Disposition: attachment; filename=$form_filename;"); 
 header("Content-Transfer-Encoding: binary");
 header("Cache-Control: cache, must-revalidate");
 header("Pragma: public");
 header("Pragma: no-cache");
 header("Expires: 0");
 echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; CHARSET=UTF-8\">";
 
 $hostname = "10.8.90.26";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "test";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$counter = 1;
	$mysqli->query("SET NAMES 'utf8'");	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
	
	$counter = 1 ;
	$cstr = "";
	
	$PLine1 = $_POST['PLine1'];
 $PDLine1 = $_POST['PDLine1'];
 $pnumber = $_POST['pnumber'];
 $pjcode = $_POST['pjcode'];
 $start_testdate = $_POST['start_testdate'];
 $end_testdate = $_POST['end_testdate'];
 $classname = $_POST['classname'];
 $finishratioup = $_POST['finishratioup'];
 $finishratiolow = $_POST['finishratiolow'];
 $ngratioup = $_POST['ngratioup'];
 $ngratiolow = $_POST['ngratiolow'];
	
	if(!empty($PLine1))
  {
   if($counter)
   		$cstr=$cstr." and `DEPARTMENT_NAME`='$PLine1' ";
   else
   		$cstr="where `DEPARTMENT_NAME`='$PLine1' ";
   $counter++;
  } 
  if(!empty($PDLine1))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_LINE_CODE` like '$PDLine1%' ";
   else
   		$cstr="where `PROD_LINE_CODE` like '$PDLine1%' ";
   $counter++;
  } 
  if(!empty($pnumber))
  {
   if($counter)
   		$cstr=$cstr." and `PRIMARY_ITEM` like '$pnumber%' ";
   else
   		$cstr="where `PRIMARY_ITEM` like '$pnumber%' ";
   $counter++;
  }
  
  if(!empty($pjcode))
  {
   if($counter)
   		$cstr=$cstr." and `PRIMARY_ITEM_PROJECT_CODE` like '$pjcode%' ";
   else
   		$cstr="where `PRIMARY_ITEM_PROJECT_CODE` like '$pjcode%' ";
   $counter++;
  }
  if(!empty($start_testdate))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_DATE`>='$start_testdate' ";
   else
   		$cstr="where `PROD_DATE`>='$start_testdate' ";
   $counter++;
  }
  if(!empty($end_testdate))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_DATE`<='$end_testdate' ";
   else
   		$cstr="where `PROD_DATE`<='$end_testdate' ";
   $counter++;
  }
  if(!empty($classname))
  {
   if($counter)
   		$cstr=$cstr." and `SHIFT_NAME` like '$classname%' ";
   else
   		$cstr="where `SHIFT_NAME` like '$classname%' ";
   $counter++;
  }
   
  
  
 	$finishratio_up_check =false;
  $finishratio_low_check =false;
  $ngratio_up_check =false;
  $ngratio_low_check =false;
  if(!empty($finishratioup))
	{
	   $finishratio_up_check =true;
	}
	if(!empty($finishratiolow))
	{
	   $finishratio_low_check =true;
	}
	if(!empty($ngratioup))
	{
		 $ngratio_up_check =true;
	}
	if(!empty($ngratiolow))
	{
	   $ngratio_low_check =true;
  }
  
  function check_default($finishratio_up_check,$finishratio_low_check,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$itemvalue,$itemvalue1)
  {
  		if($finishratio_up_check)
			{														
					if(is_numeric($itemvalue))
					{															
							if(($itemvalue-$finishratioup)>0)
									return false;
					}
					else
						return false;
			}
			if($finishratio_low_check)
			{
					if(is_numeric($itemvalue))
					{
							if(($itemvalue-$finishratiolow)<0)
							 	 return false;
					}
					else
						return false;
			}												
			if($ngratio_up_check)
			{
					if(is_numeric($itemvalue1))
					{
							if(($itemvalue1-$ngratioup)>0)
							 	 return false;
					}
					else
						return false;
			}	
			if($ngratio_low_check)
			{
			  	if(is_numeric($itemvalue1))
					{
							if(($itemvalue1-$ngratiolow)<0)
							 	 return false;
					}
					else
						return false;
			}						
			return true;							
  }
  
   
	$sql = "Select PROD_DATE,WIP_ENTITY_NAME,ORG_CODE,PROD_LINE_CODE,SHIFT_NAME,OPERATION_NUM,PRIMARY_ITEM,PRIMARY_ITEM_PROJECT_CODE,ATTEND_HOURS,PROD_QTY,RC_GOOD_MOVE_QTY,RC_NG_MOVE_QTY,RC_RJ_MOVE_QTY,ATTENDANCE_MAN_POWER,PRIMARY_UOM_CODE from fl_rc_daily_report_bi_all where 1=1 and (RC_GOOD_MOVE_QTY >0 OR RC_NG_MOVE_QTY > 0) and DEPARTMENT_NAME like '組裝生產%' $cstr ORDER BY `PROD_DATE` DESC,`PROD_LINE_CODE` ASC,`RC_NO` DESC,`OPERATION_NUM` DESC";
	$rows = $mysqli->query($sql);
	//echo $sql."<BR>";
	$num = $rows->num_rows;
	//14個顯示欄位
	$itemnumber = 14;
	$sortarray = array();
	$finalarray = array();
	$final_count = 0;
	$sort_count = 0;
	$itemcount = 0;
	$lastfpy = 0 ;	
	
	//echo $sql."<BR>";
	if($num_data_page=="")
	 $num_data_page=10;
	if(!$num)
	{
			echo "<font size=\"5\" color=\"red\">您輸入的查詢資料沒有符合的資料!!</font>"; 		 
	 	  exit;
	}  
	else if(empty($start_testdate))
  {
 		echo "<font size=\"5\" color=\"red\">您輸入的查詢資料沒有符合的資料!!</font>"; 		 
  	exit;
  }
	else
	{
	 		while( $row = $rows->fetch_row() ) 
   		{          
	 			  $pdate = $row[0];
	 			  $org = $row[2];
	 			  $pline = $row[3];
	 			  $workno = $row[1];
					$class_name = $row[4];
	 			  $seq_no = $row[5];
					$pcode = $row[7];
					$pno = $row[6];
					$unit = $row[14];
					if($unit=="KPC")
					{
							$prodqty = $row[9]*1000;					
							$goodqty = $row[10]*1000;
							$ngqty = $row[11]*1000;
							$rjqty = $row[12]*1000;
					}
					else
					{
							$prodqty = $row[9];					
							$goodqty = $row[10];
							$ngqty = $row[11];
							$rjqty = $row[12];
					
					}
					$workhours = $row[8];
					$manpowers = $row[13];
					$different = 0;
					if($prodqty>0)
						$finishrate = round(($goodqty/$prodqty)*100,2);
					else
						$finishrate = "---";	
						
					if($itemcount>0)
					{							
							//相同時間
							if(strcmp($pdate,$sortarray[$sort_count][0])==0)
							{
								//相同工單
								if(strcmp($workno,$sortarray[$sort_count][3])==0)
								{
										//相同線
										if(strcmp($sortarray[$sort_count][1],$pline)==0)
										{
												//相同班
												if(strcmp($sortarray[$sort_count][2],$class_name)==0)
												{	
													$sortarray[$sort_count][7] = $sortarray[$sort_count][7] + $workhours;
													$sortarray[$sort_count][8] = $sortarray[$sort_count][8] + $manpowers;
													$sortarray[$sort_count][13] = $sortarray[$sort_count][13] + $ngqty;
													$sortarray[$sort_count][14] = $sortarray[$sort_count][14] + $rjqty;
													if(($goodqty+$ngqty+$rjqty)>0)
														$lastfpy = $lastfpy*($goodqty/($goodqty+$ngqty+$rjqty));
													else
														$lastfpy = "---";			
												}
												else
													$different = 1;
										}
										else
												$different = 1;
								}
								else								
									$different = 1;	
							}
							else
								$different = 1;	
							if($different)
							{		
									$realqty = $sortarray[$sort_count][10]+$sortarray[$sort_count][13]+$sortarray[$sort_count][14];
									if($realqty > 0)	
											$failedrate = round(($sortarray[$sort_count][13]/$realqty*100),2);
									else
											$failedrate ="---";
									$sortarray[$sort_count][15] = $failedrate;
									if($lastfpy>0)
											$sortarray[$sort_count][16] = round($lastfpy*100,2);
									else
											$sortarray[$sort_count][16] = "---";	
									
									if(check_default($finishratio_up_check,$finishratiolow,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$sortarray[$sort_count][12],$sortarray[$sort_count][15]))
									{	
										$count = 0;
										foreach( $sortarray[$sort_count] as $key => $value)
										{											
												$finalarray[$final_count][$count++] = $value;															
										}
										$final_count++;
										$sort_count++;
									}
									$sortarray[$sort_count][0] = $pdate;
									$sortarray[$sort_count][1] = $pline;						
									$sortarray[$sort_count][2] = $class_name;
									$sortarray[$sort_count][3] = $workno;
									$sortarray[$sort_count][4] = $seq_no;
									$sortarray[$sort_count][5] = $pcode;
									$sortarray[$sort_count][6] = $pno;
									$sortarray[$sort_count][7] = $workhours;
									$sortarray[$sort_count][8] = $manpowers;
									$sortarray[$sort_count][9] = $prodqty;
									$sortarray[$sort_count][10] = $goodqty;
									$sortarray[$sort_count][11] = $prodqty-$goodqty;
									$sortarray[$sort_count][12] = $finishrate;					
									$sortarray[$sort_count][13] = $ngqty;
									$sortarray[$sort_count][14] = $rjqty;
									
									if(($goodqty+$ngqty+$rjqty)>0)
										$lastfpy = $goodqty/($goodqty+$ngqty+$rjqty);
									else
										$lastfpy = "---";				
							}								
					}
					else
					{
						//固定的
						$sortarray[$sort_count][0] = $pdate;
						$sortarray[$sort_count][1] = $pline;						
						$sortarray[$sort_count][2] = $class_name;
						$sortarray[$sort_count][3] = $workno;
						$sortarray[$sort_count][4] = $seq_no;
						$sortarray[$sort_count][5] = $pcode;
						$sortarray[$sort_count][6] = $pno;
						$sortarray[$sort_count][7] = $workhours;
						$sortarray[$sort_count][8] = $manpowers;
						$sortarray[$sort_count][9] = $prodqty;
						$sortarray[$sort_count][10] = $goodqty;
						$sortarray[$sort_count][11] = $prodqty-$goodqty;
						$sortarray[$sort_count][12] = $finishrate;					
						$sortarray[$sort_count][13] = $ngqty;
						$sortarray[$sort_count][14] = $rjqty;
						if(($goodqty+$ngqty+$rjqty)>0)
							$lastfpy = $goodqty/($goodqty+$ngqty+$rjqty);
						else
							$lastfpy = "---";		
					}	
					$itemcount++;
			}
  		//最後一筆的不良率
			$realqty = $sortarray[$sort_count][10]+$sortarray[$sort_count][13]+$sortarray[$sort_count][14];
			if($realqty > 0)	
				$failedrate = round(($sortarray[$sort_count][13]/$realqty*100),2);
			else
				$failedrate ="---";
			$sortarray[$sort_count][15] = $failedrate;
			if($lastfpy>0)
				$sortarray[$sort_count][16] = round($lastfpy*100,2);
			else
				$sortarray[$sort_count][16] = "---";	
			if(check_default($finishratio_up_check,$finishratiolow,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$sortarray[$sort_count][12],$sortarray[$sort_count][15]))
			{	
					$count = 0;
					foreach( $sortarray[$sort_count] as $key => $value)
					{	
							$finalarray[$final_count][$count++] = $value;															
					}
					$final_count++;
					$sort_count++;
			}	
					
			if(!empty($start_testdate))
  			echo "您查詢條件為 生產日期<font color=\"blue\">".$start_testdate."</font>~<font color=\"blue\">".$end_testdate."</font>";	
	 		if(!empty($errordata))
	  		echo "，資料別為<font color=\"blue\">異常資料</font>";
	 		if(!empty($PLine1))
	  		echo "，生產線別為<font color=\"blue\">".$PLine1."</font>";
	  	if(!empty($PDLine1))
	  		echo "，生產線為<font color=\"blue\">".$PDLine1."</font>";	
	  	if(!empty($finishratiolow))
	  		echo "，達成率下限<font color=\"blue\">".$finishratiolow."%</font>";
	  	if(!empty($finishratioup))
	  		echo "，達成率上限<font color=\"blue\">".$finishratioup."%</font>";
	  	if(!empty($ngratiolow))
	  		echo "，不良率下限<font color=\"blue\">".$ngratiolow."%</font>";
	  	if(!empty($ngratioup))
	  		echo "，不良率上限<font color=\"blue\">".$ngratioup."%</font>";
	 		$k=0;
	 		$Pages = intval(($num - 1) / $num_data_page) + 1;         
	  	if ( $Page < 1 ) $Page = 1;         
	  	if ( $Page > $Pages ) $Page = $Pages;     
	}  

	function compare_ship($a, $b)
  {
    return ($a[16] > $b[16]) ? 1 : -1;
  } 
  usort($finalarray, "compare_ship");
  echo "<CENTER><table border=1>";
 	echo "<tr><td align=center colspan=8><B>資料來源時間:</B><font color=blue>".$createdate."</font></td><td align=center colspan=9><B>截止至今</B></td></tr>";
 	echo "<tr><th bgcolor='#FFFFCC'><font size=2>生產日期</font><th bgcolor='#FFFFCC'><font size=2>主生產線</font><th bgcolor='#FFFFCC'><font size=2>班別</font><th bgcolor='#FFFFCC'><font size=2>工單號碼</font><th bgcolor='#FFFFCC'><font size=2>最後工序</font><th bgcolor='#FFFFCC'><font size=2>機種品名</font><th bgcolor='#FFFFCC'><font size=2>料號</font><th bgcolor='#FFFFCC'><font size=2>出勤總工時</font><th bgcolor='#FFFFCC'><font size=2>出勤總人數</font><th bgcolor='#FFFFCC'><font size=2>指示單數量</font><th bgcolor='#FFFFCC'><font size=2>累計良品數</font><th bgcolor='#FFFFCC'><font size=2>差異數</font><th bgcolor='#FFFFCC'><font size=2>達成率</font><th bgcolor='#FFFFCC'><font size=2>累計不良品數</font><th bgcolor='#FFFFCC'><font size=2>累計未判數</font><th bgcolor='#FFFFCC'><font size=2 color=red>不良率</font><th bgcolor='#FFFFCC'><font size=2>直通率</font></tr>";
	foreach( $finalarray as $key => $data)
	{
	 	echo "<tr>";	 
	 	foreach( $data as $key1 => $value)
		{			
			if($key1==12)
			{			
				if($value<95)
					$color = "red";
				else
					$color = "black";	
				echo "<td align=right><font size=2 color=$color>".$value."%</font></td>";
			}
			else if($key1==15)
			{
					if($value>5)
						$color = "red";
					else
						$color = "black";	
					echo "<td align=right><font size=2 color=$color>".$value."%</font></td>";	
			}
			else if($key1==16)
				echo "<td align=right><font size=2 >".$value."%</font></td>";	
			else	
				echo "<td align=right><font size=2>".$value."</font></td>";
		}
		
		echo "</tr>";
	}		
	echo "</TABLE></CENTER>";    
    $mysqli->close();
?>               
</HTML>
