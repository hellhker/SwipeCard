﻿<HTML>
<?php
 $form_filename = "report.xls";
 
 header("Content-Type: application/octetstream; name=$form_filename; charset=UTF-8");
 header("Content-Disposition: attachment; filename=$form_filename;"); 
 header("Content-Transfer-Encoding: binary");
 header("Cache-Control: cache, must-revalidate");
 header("Pragma: public");
 header("Pragma: no-cache");
 header("Expires: 0");
 echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; CHARSET=UTF-8\">";
 
 $hostname = "10.8.90.26";  		
 $username ="root";
 $password ="foxlink";
 $database_name = "test";
 $mysqli = new mysqli($hostname,$username,$password,$database_name);
 $counter = 1;
 $mysqli->query("SET NAMES 'utf8'");	 
 $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
 $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
 
 $PLine1 = $_POST['PLine1'];
  $PDLine1 = $_POST['PDLine1'];
  $errordata = $_REQUEST['errordata'];
  $pnumber = $_POST['pnumber'];
  $pjcode = $_POST['pjcode'];
  $finishratioup = $_POST['finishratioup'];
  $finishratiolow = $_POST['finishratiolow'];
  $ngratioup = $_POST['ngratioup'];
  $ngratiolow = $_POST['ngratiolow'];
  $Page = $_REQUEST['Page'];
  $Pages = $_REQUEST['Pages'];
 
 $counter = 1 ;
 $cstr = "";
 //echo $PLine1;
 if(!empty($PLine1))
  {
   if($counter)
   		$cstr=$cstr." and `department_name`='$PLine1' ";
   else
   		$cstr="where `department_name`='$PLine1' ";
   $counter++;
  } 
  if(!empty($PDLine1))
  {
   if($counter)
   		$cstr=$cstr." and `prod_line_code`='$PDLine1' ";
   else
   		$cstr="where `prod_line_code`='$PDLine1' ";
   $counter++;
  } 
  
  if(!empty($pjcode))
  {
   if($counter)
   		$cstr=$cstr." and `project_code` like '$pjcode%' ";
   else
   		$cstr="where `project_code` like '$pjcode%' ";
   $counter++;
  }
  if(!empty($pnumber))
  {
   if($counter)
   		$cstr=$cstr." and `item_no` like '$pnumber%' ";
   else
   		$cstr="where `item_no` like '$pnumber%' ";
   $counter++;
  }
  if(!empty($finishratioup))
  {
   if($counter)
   		$cstr=$cstr." and ((good_qty*100)/prod_qty_total) <= $finishratioup ";
   else
   		$cstr="where and ((good_qty*100)/prod_qty_total) <= $finishratioup ";
   $counter++;
  }
  if(!empty($finishratiolow))
  {
   if($counter)
   		$cstr=$cstr." and ((good_qty*100)/prod_qty_total) >= $finishratiolow ";
   else
   		$cstr="where and ((good_qty*100)/prod_qty_total) >= $finishratiolow ";
   $counter++;
  }
  if(!empty($ngratioup))
  {
   if($counter)
   		$cstr=$cstr." and ((ng_qty*100)/(ng_qty+good_qty)) <= $ngratioup ";
   else
   		$cstr="where and ((ng_qty*100)/(ng_qty+good_qty)) <= $ngratioup ";
   $counter++;
  }
  if(!empty($ngratiolow))
  {
   if($counter)
   		$cstr=$cstr." and ((ng_qty*100)/(ng_qty+good_qty)) >= $ngratiolow ";
   else
   		$cstr="where and ((ng_qty*100)/(ng_qty+good_qty)) >= $ngratiolow ";
   $counter++;
  }
 
 //echo strcmp($ngratioup,"");
  $sql_date = "Select creation_date from fl_bi_wip_move_qty where department_name in ('成型生產線','沖壓生產線','電鍍生產線一處','電鍍生產線二處') ORDER BY `prod_date` DESC,`prod_line_code` ASC,`rc_no` DESC,`operation_seq_num` DESC";
  $date_rows = $mysqli->query($sql_date);
	$date_row = $date_rows->fetch_row();
	$createdate = $date_row[0];
   
	$sql = "Select * from fl_bi_wip_move_qty where 1=1 and department_name in ('成型生產線','沖壓生產線','電鍍生產線一處','電鍍生產線二處') $cstr ORDER BY `prod_date` DESC,`prod_line_code` ASC,`rc_no` DESC,`operation_seq_num` DESC";
	$rows = $mysqli->query($sql);
	$num = $rows->num_rows;
 //echo $sql;
 echo "<table border=2>";
 echo "<tr><td align=center colspan=8><B>資料來源時間:</B><font color=blue>".$createdate."</font></td><td align=center colspan=6><B>截止至今</B></td></tr>";
 echo "<tr><th bgcolor='#FFFFCC'><font size=2>生產日期</font><th bgcolor='#FFFFCC'><font size=2>主生產線</font><th bgcolor='#FFFFCC'><font size=2>生產指示單號</font><th bgcolor='#FFFFCC'><font size=2>工序</font><th bgcolor='#FFFFCC'><font size=2>料號</font><th bgcolor='#FFFFCC'><font size=2>投入工時</font><th bgcolor='#FFFFCC'><font size=2>指示單數量</font><th bgcolor='#FFFFCC'><font size=2>累計排配量</font><th bgcolor='#FFFFCC'><font size=2>累計良品數</font><th bgcolor='#FFFFCC'><font size=2>差異數</font><th bgcolor='#FFFFCC'><font size=2>達成率</font><th bgcolor='#FFFFCC'><font size=2>累計不良品數</font><th bgcolor='#FFFFCC'><font size=2 color=red>不良率</font><th bgcolor='#FFFFCC'><font size=2>總開線數</font></tr>";
			//一頁十筆資料         
 while( $row = $rows->fetch_row() ) 
 {          
	 			  $pdate = $row[5];
	 			  $pline = $row[8];
	 			  $rc_no = $row[11];
	 			  $seq_no = $row[12];
					$pno = $row[14];
					$prodqty = $row[16];
					$prod_totalqty = $row[17];
					$goodqty = $row[18];
					$ngqty = $row[19];
					$workhours = $row[15];
					$maxline = $row[26];
					echo "<tr><td><font size=2>".$pdate."</font></td><td><font size=2>".$pline."</font></td><td><font size=2>".$rc_no."</font></td><td><font size=2>".$seq_no."</font></td><td><font size=2>".$pno."</font></td><td align=right align=right><font size=2>".number_format($workhours)."</font></td><td align=right><font size=2>".number_format($prodqty)."</font></td><td align=right><font size=2>".number_format($prod_totalqty)."</font></td><td align=right><font size=2>".number_format($goodqty)."</font></td><td align=right><font size=2>".number_format(($prod_totalqty-$goodqty))."</font></td>";
					if($prod_totalqty>0)
					{	
						$finishrate = round(($goodqty/$prod_totalqty)*100,2);
						if($finishrate<95)
							$color = "red";
						else
							$color = "black";	
						echo "<td align=right><font size=2 color=$color>".$finishrate."</font>%</td>";
					}
					else
						echo "<td align=right><font size=2>---</font></td>";
					echo "<td align=right><font size=2>".number_format($ngqty)."</font></td>";
					if(($ngqty+$goodqty)>0)	
					{
						$failedrate = round(($ngqty/($ngqty+$goodqty)*100),2);
						if($failedrate>5)
							$color = "red";
						else
							$color = "black";	
						echo "<td align=right><font size=2 color=$color>".$failedrate."</font>%</td>";						
					}
					else
						echo "<td align=right><font size=2>---</font></td>";
					echo "<td align=right>".$maxline."</td>";
					echo "</tr>";
}         
echo "</TABLE>";         
$mysqli->close();        
?>
</HTML>
