<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<form>
<center>
<?php 
  	// 資料庫設定
    $MYSQL_LOGIN = "root";
    $MYSQL_PASSWORD = "foxlink";
    $MYSQL_HOST = "192.168.64.233";
    $mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
    $mysqli->query("SET NAMES 'utf8'");	 
    $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
    $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
      
	$usid = $_POST['usid']; 
    
    $sql = "select userid,password,email from `user_data` where UserID = '$usid' or ChineseName = '$usid'"; 
    $rows = $mysqli->query( $sql );
    $num = $rows->num_rows;
    if($num==0) 
    {   
       echo "<p>查無".$usid."該使用者資料，請確定是否已新增此使用者!</p>";
       echo "<input type=\"button\" VALUE=\"關閉視窗\" onClick=\"window.close();\"></p>"; 
       exit;    
    }
    
    $row = $rows->fetch_row();
    $id = $row[0];
    $pwd = $row[1];
    $email = $row[2];	
    $Subject = '策略客戶製造即時系統--使用者密碼查詢';
    $Subject = "=?UTF-8?B?".base64_encode($Subject)."?=";
    $message = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head><body><p>您的帳號為【".$id."】，密碼為【".$pwd."】，<br>請重新登入系統‧<a href=\"http://scbg-iot.foxlink.com.tw/sfc/index.php\">http://scbg-iot.foxlink.com.tw/sfc/index.php</a></p></body></html>";
    $headers = "Content-Type: text/html; ". "charset=UTF-8; format=flowed\n". "MIME-Version: 1.0\n". "Content-Transfer-Encoding: 8bit\n";
    $headers = $headers."To:".$email."\r\n";
    $headers = $headers. "From: 策略客戶製造即時系統通知<denil_chuang@cn.foxlink.com.tw>" . "\r\n";
    $headers = iconv("UTF-8", "big5", $headers);		  
    if(!empty($email))
    	 mail($email, $Subject, $message,$headers);						 							 

    $mysqli->close();
    echo "<CENTER><p><font color=red>$usid</font>您的密碼已寄送至您的信箱!</p></CENTER>";
?>
<p align="center"><input type="button" VALUE="確定" onClick="window.close();"></p>
</center>
</form>
</BODY>
</HTML>