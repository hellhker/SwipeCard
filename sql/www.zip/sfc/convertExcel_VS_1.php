﻿<HTML>
<?php
 $form_filename = "report.xls";
 
 header("Content-Type: application/octetstream; name=$form_filename; charset=UTF-8");
 header("Content-Disposition: attachment; filename=$form_filename;"); 
 header("Content-Transfer-Encoding: binary");
 header("Cache-Control: cache, must-revalidate");
 header("Pragma: public");
 header("Pragma: no-cache");
 header("Expires: 0");
 echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; CHARSET=UTF-8\">";
 
 $hostname = "10.8.90.26";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "test";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$counter = 1;
	$mysqli->query("SET NAMES 'utf8'");	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
	
	$PLine1 = $_POST['PLine1'];
  $PDLine1 = $_POST['PDLine1'];
	$pnumber = $_POST['pnumber'];
  $pjcode = $_POST['pjcode'];
  $start_testdate = $_POST['start_testdate'];
  $end_testdate = $_POST['end_testdate'];
  $classname = $_POST['classname'];
	
	$counter = 1 ;
	$cstr = "";
	if(!empty($PLine1))
  {
   if($counter)
   		$cstr=$cstr." and `DEPARTMENT_NAME`='$PLine1' ";
   else
   		$cstr="where `DEPARTMENT_NAME`='$PLine1' ";
   $counter++;
  } 
  if(!empty($PDLine1))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_LINE_CODE` like '$PDLine1%' ";
   else
   		$cstr="where `PROD_LINE_CODE` like '$PDLine1%' ";
   $counter++;
  } 
  if(!empty($pnumber))
  {
   if($counter)
   		$cstr=$cstr." and `PRIMARY_ITEM` like '$pnumber%' ";
   else
   		$cstr="where `PRIMARY_ITEM` like '$pnumber%' ";
   $counter++;
  }
  
  if(!empty($pjcode))
  {
   if($counter)
   		$cstr=$cstr." and `PRIMARY_ITEM_PROJECT_CODE` like '$pjcode%' ";
   else
   		$cstr="where `PRIMARY_ITEM_PROJECT_CODE` like '$pjcode%' ";
   $counter++;
  }
  if(!empty($start_testdate))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_DATE`>='$start_testdate' ";
   else
   		$cstr="where `PROD_DATE`>='$start_testdate' ";
   $counter++;
  }
  if(!empty($end_testdate))
  {
   if($counter)
   		$cstr=$cstr." and `PROD_DATE`<='$end_testdate' ";
   else
   		$cstr="where `PROD_DATE`<='$end_testdate' ";
   $counter++;
  }
  if(!empty($classname))
  {
   if($counter)
   		$cstr=$cstr." and `SHIFT_NAME` like '$classname%' ";
   else
   		$cstr="where `SHIFT_NAME` like '$classname%' ";
   $counter++;
  }
   
  
  
    
	$sql = "Select PROD_DATE,WIP_ENTITY_NAME,ORG_CODE,PROD_LINE_CODE,SHIFT_NAME,OPERATION_NUM,PRIMARY_ITEM,PRIMARY_ITEM_PROJECT_CODE,ATTEND_HOURS,PROD_QTY,RC_GOOD_MOVE_QTY,RC_NG_MOVE_QTY,RC_RJ_MOVE_QTY,ATTENDANCE_MAN_POWER,PRIMARY_UOM_CODE from fl_rc_daily_report_bi_all where 1=1 and (RC_GOOD_MOVE_QTY >0 OR RC_NG_MOVE_QTY > 0) and `ORG_CODE` IN ('S03', 'E0C', 'N0A') $cstr ORDER BY `PROD_DATE` DESC,`PROD_LINE_CODE` ASC,`RC_NO` DESC,`OPERATION_NUM` DESC";
	$rows = $mysqli->query($sql);
	//echo $sql."<BR>";
	$num = $rows->num_rows;
	//14個顯示欄位
	$itemnumber = 14;
	$sortarray = array();
	$finalarray = array();
	$vsarray= array();
	$final_count = 0;
	$sort_count = 0;
	$itemcount = 0;
	$lastfpy = 0 ;	
	
	//echo $sql."<BR>";
	if($num_data_page=="")
	 $num_data_page=10;
	if(!$num)
	{
			echo "<font size=\"5\" color=\"red\">您輸入的查詢資料沒有符合的資料!!</font>"; 		 
	 	  exit;
	}  
	else if(empty($start_testdate))
  {
 		echo "<font size=\"5\" color=\"red\">您輸入的查詢資料沒有符合的資料!!</font>"; 		 
  	exit;
  }
	else
	{
	 		while( $row = $rows->fetch_row() ) 
   		{          
	 			  $pdate = $row[0];
	 			  $org = $row[2];
	 			  if(($org=="S03")||($org=="E0C"))		
		  			$fac = "富強";
		  		else
		  			$fac = "崑山";	 
	 			  $pline = $row[3];
	 			  $workno = $row[1];	 			  
					$class_name = $row[4];
	 			  $seq_no = $row[5];
					$pcode = $row[7];
					$pno = $row[6];
					$unit = $row[14];
					if($unit=="KPC")
					{
							$prodqty = $row[9]*1000;					
							$goodqty = $row[10]*1000;
							$ngqty = $row[11]*1000;
							$rjqty = $row[12]*1000;
					}
					else
					{
							$prodqty = $row[9];					
							$goodqty = $row[10];
							$ngqty = $row[11];
							$rjqty = $row[12];
					
					}
					$workhours = $row[8];
					$manpowers = $row[13];
					
					$different = 0;
					if($prodqty>0)
						$finishrate = round(($goodqty/$prodqty)*100,2);
					else
						$finishrate = "---";	
						
					if($itemcount>0)
					{							
							//相同時間
							if(strcmp($pdate,$sortarray[$sort_count][1])==0)
							{
								//相同工單
								if(strcmp($workno,$sortarray[$sort_count][4])==0)
								{
										//相同線
										if(strcmp($sortarray[$sort_count][2],$pline)==0)
										{
												//相同班
												if(strcmp($sortarray[$sort_count][3],$class_name)==0)
												{	
													//相同工序
													if(strcmp($sortarray[$sort_count][5],$seq_no)==0)
													{
															$sortarray[$sort_count][10] = $sortarray[$sort_count][10]+$prodqty;
															$sortarray[$sort_count][11] = $sortarray[$sort_count][11]+$goodqty;	
													}
													$sortarray[$sort_count][8] = $sortarray[$sort_count][8] + $workhours;
													$sortarray[$sort_count][9] = $sortarray[$sort_count][9] + $manpowers;
													$sortarray[$sort_count][14] = $sortarray[$sort_count][14] + $ngqty;
													$sortarray[$sort_count][15] = $sortarray[$sort_count][15] + $rjqty;
													if(($goodqty+$ngqty+$rjqty)>0)
														$lastfpy = $lastfpy*($goodqty/($goodqty+$ngqty+$rjqty));
													else
														$lastfpy = "---";			
												}
												else
													$different = 1;
										}
										else
												$different = 1;
								}
								else								
									$different = 1;	
							}
							else
								$different = 1;	
							if($different)
							{		
									$realqty = $sortarray[$sort_count][11]+$sortarray[$sort_count][14]+$sortarray[$sort_count][15];
									if($realqty > 0)	
											$failedrate = round(($sortarray[$sort_count][14]/$realqty*100),2);
									else
											$failedrate ="---";
									$sortarray[$sort_count][16] = $failedrate;
									if($lastfpy>0)
											$sortarray[$sort_count][17] = round($lastfpy*100,2);
									else
											$sortarray[$sort_count][17] = "---";	
									
									$sort_count++;
									
									$sortarray[$sort_count][0] = $fac;
									$sortarray[$sort_count][1] = $pdate;
									$sortarray[$sort_count][2] = $pline;						
									$sortarray[$sort_count][3] = $class_name;
									$sortarray[$sort_count][4] = $workno;
									$sortarray[$sort_count][5] = $seq_no;
									$sortarray[$sort_count][6] = $pcode;
									$sortarray[$sort_count][7] = $pno;
									$sortarray[$sort_count][8] = $workhours;
									$sortarray[$sort_count][9] = $manpowers;
									$sortarray[$sort_count][10] = $prodqty;
									$sortarray[$sort_count][11] = $goodqty;
									$sortarray[$sort_count][12] = $prodqty-$goodqty;
									$sortarray[$sort_count][13] = $finishrate;					
									$sortarray[$sort_count][14] = $ngqty;
									$sortarray[$sort_count][15] = $rjqty;
									
									if(($goodqty+$ngqty+$rjqty)>0)
										$lastfpy = $goodqty/($goodqty+$ngqty+$rjqty);
									else
										$lastfpy = "---";				
							}								
					}
					else
					{
						//固定的
						$sortarray[$sort_count][0] = $fac;
						$sortarray[$sort_count][1] = $pdate;
						$sortarray[$sort_count][2] = $pline;						
						$sortarray[$sort_count][3] = $class_name;
						$sortarray[$sort_count][4] = $workno;
						$sortarray[$sort_count][5] = $seq_no;
						$sortarray[$sort_count][6] = $pcode;
						$sortarray[$sort_count][7] = $pno;
						$sortarray[$sort_count][8] = $workhours;
						$sortarray[$sort_count][9] = $manpowers;
						$sortarray[$sort_count][10] = $prodqty;
						$sortarray[$sort_count][11] = $goodqty;
						$sortarray[$sort_count][12] = $prodqty-$goodqty;
						$sortarray[$sort_count][13] = $finishrate;					
						$sortarray[$sort_count][14] = $ngqty;
						$sortarray[$sort_count][15] = $rjqty;
						if(($goodqty+$ngqty+$rjqty)>0)
							$lastfpy = $goodqty/($goodqty+$ngqty+$rjqty);
						else
							$lastfpy = "---";		
					}	
					$itemcount++;
			}
  		//最後一筆的不良率
			$realqty = $sortarray[$sort_count][11]+$sortarray[$sort_count][14]+$sortarray[$sort_count][15];
			if($realqty > 0)	
				$failedrate = round(($sortarray[$sort_count][14]/$realqty*100),2);
			else
				$failedrate ="---";
			$sortarray[$sort_count][16] = $failedrate;
			if($lastfpy>0)
				$sortarray[$sort_count][17] = round($lastfpy*100,2);
			else
				$sortarray[$sort_count][17] = "---";	
			$sort_count++;
			$count = 0;
			/*
			foreach( $sortarray[$sort_count] as $key => $value)
			{	
					$finalarray[$final_count][$count++] = $value;															
			}
			$final_count++;
			$sort_count++;
			*/
			//echo $sort_count."<BR>";
			for($con=0;$con<=$sort_count-1;$con++)
			{
				foreach($sortarray[$con] as $key => $value)
				{	
						if($key==0)
							$tempfac = $value;
						else if($key==1)
							$tempdate = $value;
						else if($key==3)
							$tempclass = $value;
						else if($key==2)
							$temppline = $value;
						else if($key==7)
							$temppno = $value;		
						else if($key==8)
							$tempworkhours = $value;
						else if($key==10)
							$tempprodqty = $value;
						else if($key==11)
							$tempgoodqty = $value;
						else if($key==14)
							$tempngqty = $value;
						else
							;
				}									
				//echo $tempdate." ".$tempfac." ".$tempclass." ".$temppline." ".$tempworkhours." ".$tempprodqty." ".$tempgoodqty." ".$tempngqty."<BR>";
				$finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Workhours"] = $finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Workhours"]+$tempworkhours;
				$finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Prodqtys"] = $finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Prodqtys"]+$tempprodqty;
				$finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Goodqtys"] = $finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Goodqtys"]+$tempgoodqty;
				$finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Ngqtys"] = $finalarray[$temppno][$tempdate][$tempfac][$tempclass][$temppline]["Ngqtys"]+$tempngqty;														
				
			}
					
			if(!empty($start_testdate))
  			echo "您查詢條件為 生產日期<font color=\"blue\">".$start_testdate."</font>~<font color=\"blue\">".$end_testdate."</font>";	
	 		if(!empty($errordata))
	  		echo "，資料別為<font color=\"blue\">異常資料</font>";
	 		if(!empty($PLine1))
	  		echo "，生產線別為<font color=\"blue\">".$PLine1."</font>";
	  	if(!empty($PDLine1))
	  		echo "，生產線為<font color=\"blue\">".$PDLine1."</font>";
	  	if(!empty($pjcode))
  			echo "，機種為<font color=\"blue\">".$pjcode."</font>";
  		if(!empty($pnumber))
  			echo "，料號為<font color=\"blue\">".$pnumber."</font>";	  	
	}  
?>　
<?php
	
	foreach( $finalarray as $proj_no => $pdatetime_array)
	{
		$vsarray= array();
		foreach( $pdatetime_array as $pdatetime => $fac_array)
		{
				foreach( $fac_array as $fac_name => $class_array)
				{
						foreach( $class_array as $classname => $pline_array)
						{
								$linecount = count($pline_array);
								foreach( $pline_array as $pline => $showdata)
								{
											//echo "<tr><td>".$pdatetime."</td><td>".$fac_name."</td><td>".$classname."</td><td>".$pline."</td><td>".$showdata["Workhours"]."</td><td>".$showdata["Prodqtys"]."</td><td>".$showdata["Goodqtys"]."</td><td>".$showdata["Ngqtys"]."</td><td></tr>";	
											$vsarray[$pdatetime][$classname][$fac_name]["Workhours"] = $vsarray[$pdatetime][$classname][$fac_name]["Workhours"]+$showdata["Workhours"];
											$vsarray[$pdatetime][$classname][$fac_name]["Prodqtys"] = $vsarray[$pdatetime][$classname][$fac_name]["Prodqtys"]+$showdata["Prodqtys"];
											$vsarray[$pdatetime][$classname][$fac_name]["Goodqtys"] = $vsarray[$pdatetime][$classname][$fac_name]["Goodqtys"]+$showdata["Goodqtys"];
											$vsarray[$pdatetime][$classname][$fac_name]["Ngqtys"] = $vsarray[$pdatetime][$classname][$fac_name]["Ngqtys"]+$showdata["Ngqtys"];
								}
								$vsarray[$pdatetime][$classname][$fac_name]["Lines"] = $linecount;
						}
				}
		}
		echo "<CENTER><table border=1>";
		echo "<tr><td colspan=12 align=left><font size=3>專案代碼:</font><font size=3 color=blue>".$pjcode." "."</font><font size=3>料號:</font><font size=3 color=blue>".$proj_no."</font></td></tr>";
	 	echo "<tr><td colspan=2 align=center><font size=2>廠區</font></td><td colspan=5 align=center bgcolor=lightblue><font size=2>FQ</font></td><td colspan=5 align=center bgcolor=yellow><font size=2>KS</font></td></tr>";
		echo "<tr><td align=center><font size=2>日期</font></td><td align=center><font size=2>班別</font></td><td align=center bgcolor=lightblue><font size=2>產線(主)數</font></td><td align=center><font size=2>平均投入總工時</font></td><td align=center><font size=2>平均排配數量</font></td><td align=center><font size=2>平均產出良品數</font></td><td align=center><font size=2>平均不良品數量</font></td><td align=center bgcolor=yellow><font size=2>產線(主)數</font></td><td align=center><font size=2>平均投入總工時</font></td><td align=center><font size=2>平均排配數量</font></td><td align=center><font size=2>平均產出良品數</font></td><td align=center><font size=2>平均不良品數量</font></td></tr>";
		foreach( $vsarray as $pdate_time => $classarray)
		{			
				for($x=0;$x<2;$x++)
				{
						if($x==0)
							echo "<tr><td face=\"Arial Narrow\">".$pdate_time."</td><td face=\"Arial Narrow\">D</td>";
						else
							echo "<tr><td face=\"Arial Narrow\">".$pdate_time."</td><td face=\"Arial Narrow\">N</td>";
						for($y=0;$y<2;$y++)
						{
								if($x==0)
									$shift_name = "Day Shift";
								else
									$shift_name = "Night Shift";
								if($y==0)
								{	
									$facname = "富強";
									$color = "lightblue";
								}
								else
								{	
									$facname = "崑山";
									$color = "yellow";
								}
								$linecounts = $classarray[$shift_name][$facname]["Lines"];	
								if($linecounts>0)
									echo "<td align=right bgcolor=$color face=\"Arial Narrow\">".$linecounts."</td><td align=right face=\"Arial Narrow\">".number_format(round($classarray[$shift_name][$facname]["Workhours"]/$linecounts))."</td><td align=right face=\"Arial Narrow\">".number_format(round($classarray[$shift_name][$facname]["Prodqtys"]/$linecounts))."</td><td align=right face=\"Arial Narrow\">".number_format(round($classarray[$shift_name][$facname]["Goodqtys"]/$linecounts))."</td><td align=right face=\"Arial Narrow\">".number_format(round($classarray[$shift_name][$facname]["Ngqtys"]/$linecounts))."</td>";										
								else
									echo "<td bgcolor=$color>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
						}
				}
				echo "</tr>";			
		}
	}
	echo "</TABLE></CENTER>";   
    $mysqli->close();    
?>               
</HTML>
