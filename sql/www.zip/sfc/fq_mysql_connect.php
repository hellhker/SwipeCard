<?php 
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$mysqli;

function connect_db($MYSQL_DB)
{
    global $mysqli,$MYSQL_LOGIN,$MYSQL_PASSWORD,$MYSQL_HOST;
    $mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,$MYSQL_DB);
    
    if ($mysqli->connect_error) {
        //die('Connect Error: ' . $mysqli->connect_error);
        exit();
    }
    else
    {
        $mysqli->query("SET NAMES 'utf8'");	 
        $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
        $mysqli->query('SET CHARACTER_SET_RESULTS=utf8');
    }
}
?>