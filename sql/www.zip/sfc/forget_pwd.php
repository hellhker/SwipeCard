﻿<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
    <script type="text/javascript">
    function makeSure(theForm)
    {
        if(theForm.usid.value == "")
        {
            alert("請輸入使用者帳號或姓名!");
            return;
        }
        theForm.submit();
    }
    </script>
</head>
<body>
<center>
<form name="upload" method="post" action="forget_pwd2.php">
請輸入您的使用者帳號或姓名：<input type="text" name="usid" /><br /><br />
<input type="button" onclick="makeSure(this.form)" class="groovybutton" value="查詢" />
</form>
</center>
</body>
</html>