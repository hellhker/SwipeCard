<?php
require_once("./auth.php");
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
    <script language="JavaScript">
    function add()
    {
        document.myform.submit();
    }
    
    function del(code)
    {
        var answer = confirm("確定刪除此筆資料?")
    	if (answer)
    	{
    		var depname;
    		var addr = "dept_setting_del.php?code="+code;	//encodeURI()將中文編碼轉成UTF-8
    		var mylib = window.open(addr, 'foxlink','scrollbars=yes,resizable=yes,status=no');
        	mylib.focus();    
    	}
    }
    </script>
</head>
<body>
<form name=myform method="post" action="dept_setting_add.php">
<center>
<h2>部門代碼對照表</h2>
<?php
$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');

$sql = "select `Department_Code`,`Department_Name` from department_table order by Department_Code";
$rows = $mysqli->query($sql);
$row_num = $rows->num_rows;

if($row_num > 0)
{
    echo "<table>";
    if($dept_modify == 1)
    {
        echo "<tr><td align=right valign=top height=30 class=\"rlink\" onclick=\"add()\">新增一筆資料</td></tr>";
    }
    echo "<tr><td>";
    echo "<table border=1>";
    echo "<tr><td class=\"title\">部門代碼</td><td class=\"title\">部門名稱</td><td class=\"title\"></td></tr>";
    while($row = $rows->fetch_row())
    {
        echo "<tr><td class=\"cdata\" width=90>".$row[0]."</td><td width=340 style=\"padding-left: 10px;\">".$row[1]."</td>";
        if($dept_modify == 1)
        {
            echo "<td class=\"red_link\" width=40 onclick=\"del(".$row[0].")\">刪除</td></tr>";
        }
        else
        {
            echo "<td width=40>&nbsp;</td></tr>";
        }
    }
    echo "</table>";
    echo "</td></tr>";
    echo "</table>";
    mysqli_free_result($rows);
}
else
{
    echo "<div style=\"margin-left: 10px;\"><h2><font color=\"red\">查無任何設定資料!!</font></h2></div>";
    if($dept_modify == 1)
    {
        echo "<table>";
        echo "<tr><td align=right valign=top height=30 class=\"rlink\" onclick=\"add()\">新增一筆資料</td></tr>";
        echo "</table>";
    }
}

$mysqli->close();
?>
</center>
</form>
</body>
</html>