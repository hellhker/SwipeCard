<?php
require_once("./auth.php");
if($dept_modify != 1)
{
    echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
    echo "window.alert('您無此操作權限!!')";  
    echo "</SCRIPT>"; 
    exit;
}
?>
<HTML>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<form>
<?php 
    $mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
    $mysqli->query("SET NAMES 'utf8'");	 
    $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
    $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
    
    $dept_code  = explode(',',$_POST['dept_code']);
	$dept_name  = explode(',',$_POST['dept_name']);
    
    for($i=0; $i < count($dept_code); $i++)
    {  
        $sql = "select * from department_table Where department_code = '$dept_code[$i]'"; 
        $rows = $mysqli->query( $sql );
        $num = $rows->num_rows;
        if ( $num > 0 ) 
        {   
            mysqli_free_result($rows);
            echo "<CENTER><p><font color=red>部門代碼:".$dept_code[$i]." 資料重複，無法新增!</font></p></CENTER><br />";   
        }
        else
        {			
            $sql = "Insert Into department_table (`department_code`,`department_name`) values ('$dept_code[$i]','$dept_name[$i]')";           
            $mysqli->query( $sql );
            echo "<CENTER><p><font color=red>部門代碼:".$dept_code[$i]."、部門名稱:".$dept_name[$i]." 新增完畢!</font></p></CENTER><br />";
        }
    }
    
    $mysqli->close();
?>
<p align="center"><input type="button" VALUE="關閉視窗" onClick="javascript:window.location='dept_setting.php'"></p>
</center>
</form>
</BODY>
</HTML>