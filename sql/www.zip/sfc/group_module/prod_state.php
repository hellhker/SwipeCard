﻿<?php  
  $KoolControlsFolder = "../KoolPHPSuite/KoolControls/";
	require $KoolControlsFolder."/KoolTreeView/kooltreeview.php";
	require_once("../auth.php");
	
  header('Expires: Sun, 15 Dec 2002 06:00:00 GMT');
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
	header('Cache-Control: no-store, no-cache, must-revalidate');
	header('Cache-Control: post-check=0, pre-check=0', false);
	header('Pragma: no-cache');

  class Person
  {
     var $usid;
     var $cname;
     var $dept;
     var $deptid;
     var $title;  
  }
  
  class Dep
  {
     var $depid;
     var $parentid;
     var $childid;
     var $depname;    
  }

  function get_child($nodeid,$deparr,$treeview,$parentNode)
	{		 
		 if(strcmp($deparr[$nodeid]->childid,"")==0)
		 {
		 	  
		 }
		 else
		 {		 	  
		 	  //echo "parentID:".$parentNode." "."childID:".$deparr[$nodeid]->childid."<BR>";
		 	  $childarr = explode(",",$deparr[$nodeid]->childid);		 	  
		 	  for($i=0;$i<count($childarr);$i++)
		 	  {
		 	  	 $NodeName = $deparr[$childarr[$i]]->depname;	
		 	  	 $node_depid = $deparr[$childarr[$i]]->depid;		
		 	  	 //echo $childarr[$i].":".$NodeName."<BR>";
		 	  	 //$linkhref = "<a href='result_by_dep.php?userid=".$tmp."&&departname=".$NodeName."&&node_depid=".$node_depid."' target='result'>".$NodeName."</a>"; 	  	 
		 	  	 /*
		 	  	 if(strcmp($NodeName,"營運本處")==0)
		 	  	 		echo $node_depid."<BR>";
		 	  	 */
		 	  	 $linkhref = "<a href='#'>".$NodeName."</a>"; 
		 	  	 $treeview->Add($parentNode,$node_depid,$linkhref,false,"square_blueS.gif","");		 	  	 
		 	  	 get_child($childarr[$i],$deparr,$treeview,$node_depid);
		 	  }	 	 
		 }
	}


  $hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$counter = 1;
	$mysqli->query("SET NAMES 'utf8'");	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
	
	$deparr = array();
	$sql = "SELECT * FROM `new_group_structure`";
	$rows = $mysqli->query($sql);	
  while($row = $rows->fetch_row()) 
	{
		  $dept = new Dep;
		  $dept->depid = $row[0];
		  $dept->parentid = $row[1];
		  $dept->childid = $row[2];
		  $dept->depname = $row[8];
		  $deparr[$row[0]] = $dept; 		  
	}
	/*
	for($i=1;$i<=count($deparr);$i++)
	{
		 echo $deparr[$i]->depname." ".$deparr[$i]->depid."<BR>";
	}
	*/
	$treeview = new KoolTreeView("treeview");
	$treeview->scriptFolder = $KoolControlsFolder."/KoolTreeView";
	$treeview->imageFolder=$KoolControlsFolder."/KoolTreeView/icons";
	$treeview->styleFolder="default";
	$treeview->showLines = true;
	
	
	$root = $treeview->getRootNode();
	$root->text = $deparr[889]->depname;
	$root->expand=false;
	$root->image="xpNetwork.gif";
	$linkhref = "<a href='#'>SCBG222</a>"; 
	//$treeview->Add("root","SCBG222",$linkhref,false,"xpNetwork.gif","");	
	
	get_child(889,$deparr,$treeview,"root");
	
	
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>SFC Report</title>
</HEAD>
<body>
<form>	
<div style="padding:10px;">
	<?php echo $treeview->Render();?>
</div>
</form>
</body>
</html>