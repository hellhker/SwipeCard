<?php
require_once("mysql.php");
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$db = new mysql($MYSQL_HOST, $MYSQL_LOGIN, $MYSQL_PASSWORD, "sfc");
$list = $_POST['data'];
$Role_ID = $list[0];
$sql = "select MODULE_ID from `group_module` where GROUP_ID = '$Role_ID'";
$result = $db->query($sql);
$count = mysql_num_rows($result);
$htmlstr = "";
if($count>0){
    while($d_row = mysql_fetch_array($result)){
        $htmlstr .= $d_row[0].",";
    }
    $htmlstr = substr($htmlstr,0,strlen($htmlstr)-1);
}
mysql_free_result($result);
echo $htmlstr;
?>