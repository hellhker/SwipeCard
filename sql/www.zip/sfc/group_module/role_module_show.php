<?php
    $Role_ID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $Role_Name = isset($_GET['Role_Name']) ? $_GET['Role_Name'] : "";
?>
<html>
    <head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>模块信息</title>
    <script src="../jquery-1.9.1.js"></script>
    <style>
        input{
            margin: 5px;
        }
        #treeMenu_div{
            border: 1px solid gray;
            padding-top: 15px;
            margin-right: 0px;
            list-style: none;
            width: 50%;
            height: 300px;
            overflow:auto;
        }
        #treeMenu_div ul{
            text-align: left;
            list-style: none;
            list-style-type: none;
            margin-left: 10px;
            padding-left: 10px;
        }
        #treeMenu_div ul span{
            padding-left: 10px;
        }
        #treeMenu_div ul li{
            margin: 3px;
        }
        #treeMenu_div ul li:hover{
            cursor: pointer;
        }
    </style>
    <script type="text/javascript">
        $icount = 0;
        function selectModule($node){
            if($node.attr('checked')!= 'checked'){
                $node.parent("li").find("input[type='checkbox']").attr("checked",true);
            }else{
                $node.parent("li").find("input[type='checkbox']").removeAttr('checked');
            } 
        }
        function getChildren($node,$layer,$Role_ID){
            $s_pid = "";
            for($i=0;$i<$node.length;$i++){
                if($i==$node.length-1){
                    $s_pid += $node[$i].val();
                }else{
                    $s_pid += $node[$i].val()+",";
                }
            }
            $c_layer = $layer+1;
            $.ajax({
    			type: 'post',
    			url: 'role_module_getdata.php',
    			data: {"data[]":[$s_pid,$c_layer,'show',$Role_ID]},
    			success: function(msg){
    			    if(msg == "")return;
                    $nodehtml = msg;
    			    $attr = new Array();
                    $attr = $nodehtml.split(',');
                    for($i=0;$i<$node.length;$i++){
                        $node[$i].append($attr[$i]);
                    }
                    $c_layer = $layer+1;
                    $tempstr1 =".layer"+$c_layer;
                    if($("#treeMenu_div "+$tempstr1).length < 1)return;
                    $t2 = 0;
                    $node1 = new Array();
                    $("#treeMenu_div "+$tempstr1).each(function(){
                        $node1[$t2] = $(this);
                        $t2++;
                    });
                    getChildren($node1,$c_layer,$Role_ID);
    			}
    	    });
        }
        $(function(){
            $tempstr = ".layer1";
            $Role_ID = $("#Role_ID").val();
            $node = new Array();
            $t1 = 0;
            $("#treeMenu_div "+$tempstr).each(function(){
               $node[$t1] = $(this);
               $t1++;
            });
            getChildren($node,1,$Role_ID);
        });
    </script>
    </head>
    <body>
        <a href="role_module_set.php">返回</a><br />
        分組ID：
        <input type="text" value="<?php echo $Role_ID ?>" disabled="true" id="Role_ID" />
        <label>
        <?php echo $Role_Name ?> 
        </label><br />
        <div id="treeMenu_div">
            <ul>
                <li class="layer1" value="0">功能</li>
            </ul>
        </div>
    </body>
</html>

