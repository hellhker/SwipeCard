<?php
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');

$sql = "select ID,GroupName from group_table order by ID";
$rows = $mysqli->query($sql);
$row_num = $rows->num_rows;
?>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
        <title>分組模块权限设定</title>
        <style>
            table,div,input,select{
                margin: 5px;
            }
            table td{
                padding: 5px;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <script type="text/javascript">
        </script>
        <div id="table">
            <table border=1 style="border-collapse: collapse;">
            <tr>
                <td colspan="3" style="text-align: center;">分組列表權限设定</td>
            </tr>
            <tr>
                <td>分組名</td><td>分組描述</td><td>操作</td>
            </tr>
            <?php 
                if($row_num > 0)
                {
                    while($row = $rows->fetch_row()){ 
            ?>
            <tr>
                <td><?php echo $row[1] ?></td>
                <td></td>
                <td><a href="role_module_show.php?id=<?php echo $row[0] ?>&Role_Name=<?php echo $row[1] ?>">查看权限</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="role_module_action.php?id=<?php echo $row[0] ?>&Role_Name=<?php echo $row[1] ?>">重新分配权限</a></td>
            </tr>
            <?php }
                mysqli_free_result($rows);
                }
                $mysqli->close();
            ?>
            </table>
       </div>
    </body>
</html>