<?php
require_once("mysql.php");
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$db = new mysql($MYSQL_HOST, $MYSQL_LOGIN, $MYSQL_PASSWORD, "sfc");
$list = $_POST['data'];
$action = $list[0];
if ($action == "Add") {
    $pid = htmlspecialchars($list[1]);
    $Module_Name = htmlspecialchars($list[2]);
    $CName = htmlspecialchars($list[3]);
    if($db->checkFiled('module','MODULE_NAME',$Module_Name)){
        $db->insert('module', array('MODULE_NAME' => $Module_Name, 'CNAME' => $CName, 'PID' =>$pid));
        echo "success";
    }else{
        echo "failed";
    }
}else if($action == "Del"){
    $s_pid = $list[1];
    $pid_info = getChildrenIDList($db,$s_pid);
    $c_list =$pid_info;
    $enable_count = 0;
    while(1){
        $enable_count++;
        $temp_list = array();
        if(empty($pid_info))break;
        foreach($pid_info as $index => $value){
            if(getChildrenCount($db,$value) > 0){
                $tempArray = getChildrenIDList($db,$value);
                $c_list = array_merge($c_list,$tempArray);
            }else{
                continue;
            }
            $temp_list = array_merge($tempArray,$temp_list);
        }
        if(empty($temp_list))break;
        else{
            $pid_info = null;
            $pid_info = $temp_list;
        }
        /// 无限级权限设定，最高10层
        if($enable_count > 10)break;
    }
    $htmlstr = $s_pid;
    if(!empty($c_list)){
        foreach($c_list as $index => $value){
            $htmlstr .= ",".$value;
        }
    }
    $db->delete('module', "ID in($htmlstr)");
    echo "delete";
}else if($action == "Updata"){
    $id = htmlspecialchars($list[1]);
    $Module_Name = htmlspecialchars($list[2]);
    $CName = htmlspecialchars($list[3]);
    $db->update('module', array('MODULE_NAME' => $Module_Name, 'CNAME' => $CName), "ID = $id");
    echo "修改完成.";
}else{
    echo "Not Set!";
}

function getChildrenIDList($db,$s_pid){
    $sqlstr = "select * from module where PID = ".$s_pid." order by ID";
    $result = $db->query($sqlstr);
    $count = mysql_num_rows($result);
    $pid_list = null;
    if($count>0){
       while($d_row = mysql_fetch_array($result)){
            $pid_list[$d_row[1]] = $d_row[0];
       }
    }
    mysql_free_result($result);
    return $pid_list;
}
function getChildrenCount($db,$s_pid){
    $sqlstr = "select ID from module where PID = ".$s_pid." order by ID";
    $result = $db->query($sqlstr);
    $count = mysql_num_rows($result);
    mysql_free_result($result);
    return $count;
}

?>