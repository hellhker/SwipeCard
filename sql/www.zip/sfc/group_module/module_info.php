<html>
    <head>
    <title>模块信息</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <script src="../jquery-1.9.1.js"></script>
    <style>
    input{
        margin: 5px;
    }
    #treeMenu_div{
        border: 1px solid gray;
        padding-top: 15px;
        margin-right: 0px;
        list-style: none;
        width: 50%;
        height: 300px;
        overflow:auto;
    }
    #treeMenu_div ul{
        text-align: left;
        list-style: none;
        list-style-type: none;
        margin-left: 10px;
        padding-left: 10px;
    }
    #treeMenu_div ul span{
        padding-left: 10px;
    }
    #treeMenu_div ul li{
        margin: 3px;
    }
    #treeMenu_div ul li:hover{
        cursor: pointer;
    }
    </style>
    </head>
    <body>
    <script type="text/javascript">
    var s_node = null;
    function check(){
        if ($("#Module_Name").val() == "") {
            alert("模块名不能为空！");
            return false;
        }
        if ($("#CName").val() == "") {
            alert("中文名称不能为空！");
            return false;
        }
        return true;
    }
    function isDel(){
        if(confirm("你確定要刪除信息嗎?")){
            return true;
        }else{
            return false;
        }
    }
    function getChildren($node,event){
        $("#module_div").css('display','none');
        event.stopPropagation();
        $s_id = $node.val();
        if(s_node != null)s_node.css('background-color','white');
        $node.css('background-color','lime');
        s_node = $node;
        $("#pid").val($s_id);
        $.ajax({
			type: 'post',
			url: 'module_GetChildren.php',
			data: {"data[]":[$s_id]},
			success: function(msg){
			    $node.children().empty();
			    $node.append(msg);
			}
	    });
    }
    $(function(){
       $("#done").click(function(){
        $act_done = $("#act_done").val();
        if($act_done == "Add"){
            if(check() == false)return;
            if(s_node == null){
                alert("请选取上级节点");
                return;
            }
            $pid = $("#pid").val();
            $Module_Name = $("#Module_Name").val();
            $CName = $("#CName").val();
            $.ajax({
    			type: 'post',
    			url: 'module_Action.php',
    			data: {"data[]":["Add",$pid,$Module_Name,$CName]},
    			success: function(msg){
    			    if($.trim(msg) == "success"){
                        $add_node = "";
                        $add_node = "<li value=\""+$pid+"\" onclick=\"getChildren($(this),event)\">"+$CName+"</li>";
                        s_node.append("<ul>"+$add_node+"</ul>");
                        getChildren(s_node,event);
    			    }else{
    			     alert(msg);
    			    }
                    $("#Module_Name").val("");
                    $("#CName").val("");
                    $("#module_div").css('display','none');
    			}
    	    });
        }else if($act_done == "Updata"){
            if(check() == false)return;
            if(s_node == null){
                alert("请选取上级节点");
                return;
            }
            $id = $("#pid").val();
            $Module_Name = $("#Module_Name").val();
            $CName = $("#CName").val();
            $.ajax({
                type: 'post',
    			url: 'module_Action.php',
    			data: {"data[]":["Updata",$id,$Module_Name,$CName]},
                success: function(msg){
                    alert(msg);
                    s_node.parent().click();
                    $("#Module_Name").val("");
                    $("#CName").val("");
                }
            });
        }else{
            alert("未设定");
        }
        
       });
       
       $("#Del").click(function(){
            if(isDel() == false)return;
            if(s_node == null){
                alert("请选定需要删除的模块,该功能请慎用.");
                return;
            }
            $pid = $("#pid").val();
            $.ajax({
                type: 'post',
    			url: 'module_Action.php',
    			data: {"data[]":["Del",$pid,"test","test"]},
                success: function(msg){
                    if($.trim(msg) == "delete"){
                        if(s_node != null){
                            s_node.empty();
                        }
                    }
                }
            });
       });
       
       $("#Add").click(function(){
            $("#module_div").css('display','block');
            $("#act_done").val("Add");
       });
       
       $("#Updata").click(function(){
            $("#module_div").css('display','block');
            $("#act_done").val("Updata");
            $("#Module_Name").val(s_node.attr("title"));
       });
    });
    </script>
        <div id="treeMenu_div">
            <ul>
                <li value="0" title="" onclick="getChildren($(this),event)">功能列表</li>
            </ul>
        </div>
        当前模块ID：<input type="text" id="pid" value="0" disabled="true" />
        <input type="button" value="添加子模块" id="Add"/>
        <input type="button" value="修改模块" id="Updata" />
        <input type="button" value="删除模块及子模块" id="Del"/>
        <br />
        <div id="module_div" style="display: none;">
        模块名：<input type="text" id="Module_Name" value="" />
        名称：<input type="text" id="CName" value="" />
        <input type="hidden" value="" id="act_done" />
        <input type="button" value="确定" id="done" />
        </div>
    </body>
</html>