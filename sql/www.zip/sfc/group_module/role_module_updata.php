<?php
require_once("mysql.php");
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$db = new mysql($MYSQL_HOST, $MYSQL_LOGIN, $MYSQL_PASSWORD, "sfc");
$list = $_POST['data'];
$Role_ID = $list[0];
/// split explode
$module_list = explode(',',$list[1]);
$db->delete('group_module', "GROUP_ID = $Role_ID");
foreach($module_list as $index => $value){
    $db->insert('group_module', array('GROUP_ID' => $Role_ID, 'MODULE_ID' => $value));
}
echo "权限分配完成";

?>