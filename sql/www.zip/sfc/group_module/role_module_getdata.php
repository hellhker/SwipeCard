<?php
    require_once("mysql.php");
    $MYSQL_LOGIN = "root";
    $MYSQL_PASSWORD = "foxlink";
    $MYSQL_HOST = "192.168.64.233";
    $db = new mysql($MYSQL_HOST, $MYSQL_LOGIN, $MYSQL_PASSWORD, "sfc");
    $db->query("SET NAMES 'utf8'");	 
    $db->query('SET CHARACTER_SET_CLIENT=utf8');
    $db->query('SET CHARACTER_SET_RESULTS=utf8');
    function getChildrenIDList($db,$s_pid,$layer){
        $id_list = explode(',',$s_pid);
        $str = "";
        for($i=0;$i<count($id_list);$i++){
            $pid = $id_list[$i];
            $sqlstr = "select * from module where PID = ".$pid." order by ID";
            $result = $db->query($sqlstr);
            $count = mysql_num_rows($result);
            $c_layer = $layer;
            $tempstr = "layer".$c_layer;
            $htmlstr = "";
            if($count>0){
                $htmlstr = "<ul>";
                while($d_row = mysql_fetch_array($result)){
                    $htmlstr .= "<li class = \"$tempstr\" value = \"$d_row[0]\"><input type=\"checkbox\" value=\"$d_row[0]\" onclick=\"selectModule($(this))\" />$d_row[2]</li>";
                }
                $htmlstr .= "</ul>";
            }
            $str .= $htmlstr.",";
            mysql_free_result($result);
        }
        if($str != ""){
            $str = substr($str,0,strlen($str)-1);
        }
        return $str;
    }
    function showChildrenIDList($db,$s_pid,$layer,$Role_ID){
        $id_list = explode(',',$s_pid);
        $str = "";
        for($i=0;$i<count($id_list);$i++){
            $pid = $id_list[$i];
            $sqlstr = "SELECT * FROM `module` WHERE ID in (select `MODULE_ID` from `group_module` where `GROUP_ID`= $Role_ID) and PID = ".$pid." order by ID";
            $result = $db->query($sqlstr);
            $count = mysql_num_rows($result);
            $c_layer = $layer;
            $tempstr = "layer".$c_layer;
            $htmlstr = "";
            if($count>0){
                $htmlstr = "<ul>";
                while($d_row = mysql_fetch_array($result)){
                    $htmlstr .= "<li class = \"$tempstr\" value = \"$d_row[0]\">$d_row[2] => $d_row[1]</li>";
                }
                $htmlstr .= "</ul>";
            }
            $str .= $htmlstr.",";
            mysql_free_result($result);
        }
        if($str != ""){
            $str = substr($str,0,strlen($str)-1);
        }
        return $str;
    }
    $list = $_POST['data'];
    $s_pid = $list[0];
    $layer = $list[1];
    $type = $list[2];
    if($type == 'new'){
        echo getChildrenIDList($db,$s_pid,$layer);
    }else if($type == 'show'){
        $Role_ID = $list[3];
        echo showChildrenIDList($db,$s_pid,$layer,$Role_ID);
    }else{
        echo 'not set';
    }
    
?>