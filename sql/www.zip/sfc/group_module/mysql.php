<?php
class mysql{
    private $host;
    private $user;
    private $pass;
    private $database;
    private $code;
    private $conn;
    private $sql;
    private $result;

    public function __construct($host, $user, $pass, $database, $code = 'utf8', $conn = 'conn') {
        $this->host = $host;
        $this->user = $user;
        $this->pass = $pass;
        $this->data = $database;
        $this->code = $code;
        $this->conn = $conn;
        $this->__connect();
    }

    private function __connect() {
        if ($this->conn == 'pconn') {
            $this->conn = mysql_pconnect($this->host, $this->user, $this->pass);
        } else {
            $this->conn = mysql_connect($this->host, $this->user, $this->pass);
        }
        if (!$this->conn) {
            echo "无法连接服务器";
        }

        $this->select_db($this->data);
        $this->query("SET NAMES $this->code");
    }

    public function select_db($data) {
        $result = mysql_select_db($data, $this->conn);
        if (!$result) {
            echo "无法连接数据库";
        }
        return $result;
    }

    public function query($sql) {
        if (empty($sql)) {
            echo "sql语句为空";
        }
        $this->sql = preg_replace('/ {2,}/', ' ', trim($sql));
        $this->result = mysql_query($this->sql, $this->conn);
        if (!$this->result) {
            echo "sql语句有错误";
        }
        return $this->result;
    }
    
    public function checkFiled($table,$filed,$filedvalue){
        $sql = "SELECT count($filed) FROM $table where $filed = '$filedvalue'";
        $rows = mysql_query($sql, $this->conn);
        $result = mysql_fetch_array($rows);
        if($result[0]>=1){
            return false;
        }else{
            return true;
        }
    }

    public function select($table, $fileds='*', $condition='', $rows=1) {
        if (!$fileds) {
            $fileds = '*';
        }
        if ($rows > 1) {
            $condition .= "order by id desc LIMIT 0, {$rows}";
        }
        $sql = "SELECT {$fileds} FROM {$table} {$condition}";
        return $sql;
    }

    public function insert($table, $data) {
        foreach ($data as $key => $value) {
            $sqlkey .= $key . ",";
            if (strpos($value, now) === false) {
                $sqlvalue .= "'" . $value . "',";
            }else {
                $sqlvalue .= $value . ",";
            }
         }
         return $this->query("INSERT INTO $table (" . substr($sqlkey, 0,-1) . ") VALUES (" . substr($sqlvalue, 0,-1) . ")");
    }

    public function update($table, $data, $condition = '') {
        foreach ($data as $key => $value) {
            if (strpos($value, now) === false) {
                $sqlud .= $key . "= '" . $value . "',";
            } else { 
                $sqlud .= $key . "= " . $value . ",";
            }
       }
       return $this->query("UPDATE $table SET " . substr($sqlud, 0, -1) . " WHERE " . $condition);
    }

    public function delete($table, $condition = '') {
        return $this->query("DELETE FROM $table " . ($condition ? " WHERE {$condition} " : ''));
    }

    public function getResultRow() {
        $this->result = mysql_fetch_array($this->result);
        return $this->result;
    }
}
?>