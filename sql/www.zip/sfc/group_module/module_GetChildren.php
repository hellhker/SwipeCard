<?php
    require_once("mysql.php");
    $MYSQL_LOGIN = "root";
    $MYSQL_PASSWORD = "foxlink";
    $MYSQL_HOST = "192.168.64.233";
    $db = new mysql($MYSQL_HOST, $MYSQL_LOGIN, $MYSQL_PASSWORD, "sfc");
    $list = $_POST['data'];
    $sqlstr = "select * from module where PID = ".$list[0]." order by ID";
    $result = $db->query($sqlstr);
    $count = mysql_num_rows($result);
    $htmlstr = "";
    if($count>0){
        $htmlstr .= "<ul>";
        while($d_row = mysql_fetch_array($result)){
            $htmlstr .= "<li value=\"$d_row[0]\" title=\"$d_row[1]\" onclick=\"getChildren($(this),event)\">$d_row[2]</li>";
        }
        $htmlstr .= "</ul>";
    }
    mysql_free_result($result);
    echo $htmlstr;
?>