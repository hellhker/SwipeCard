<?php
//require_once("../auth.php");
//global $MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD;
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";
$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');
$sql = "select ID,GroupName from group_table order by ID";
$rows = $mysqli->query($sql);
$row_num = $rows->num_rows;
?>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
        <title>分組信息</title>
        <style>
            table,div,input,select{
                margin: 5px;
            }
            table td{
                padding: 5px;
                text-align: center;
            }
        </style>
    </head>
    <body>
    <div>
        <table border=1 style="border-collapse: collapse;">
        <tr>
            <td colspan="3" style="text-align: center;">分組列表</td>
        </tr>
        <tr>
            <td>分組名</td><td>分組描述</td><td>操作</td>
        </tr>
        <?php
            if($row_num > 0)
            {
                while($row = $rows->fetch_row())
                {
                    echo "<tr><td>$row[1]</td><td></td><td></td></tr>";
                }
                mysqli_free_result($rows);
            }
            $mysqli->close();
        ?>
        </table>
    </div>   
    </body>
</html>