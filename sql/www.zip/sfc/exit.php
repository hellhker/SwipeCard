<?php
//require_once("auth.php");
//ob_start(); 
session_start();
$MYSQL_LOGIN = "root";
$MYSQL_PASSWORD = "foxlink";
$MYSQL_HOST = "192.168.64.233";

$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 	
$end_testdate = Date("Y-m-d H:i:s");		  				
//$starty = substr($end_testdate,0,4); 
//$startm = substr($end_testdate,5,2); 
//$startd = substr($end_testdate,8,2);
//$starth = substr($end_testdate,11,2);
//$starti = substr($end_testdate,14,2);
//$starts = substr($end_testdate,17,2);
//$end_testdate = Date("Y-m-d H:i:s",mktime($starth+8, $starti, $starts, $startm, $startd, $starty));
$end_updatetime= $_SESSION["logtime"];
$username = $_SESSION["ssn_usr"];
$sql = "Update `login_log` Set LogoutTime='$end_testdate' where UserID='$username' and LoginTime = '$end_updatetime'";
//echo $sql;	
$mysqli->query($sql);

$mysqli->close();
$_SESSION=array();
session_regenerate_id(); 
session_destroy();
//關閉輸出暫存器
//ob_end_flush();
?>
<html>
<head>
<script language="javascript">setTimeout("window.close();",1000)</script>
</head>
<body>
</body>
</html>