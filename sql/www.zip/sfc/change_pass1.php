<?php 
  include("auth.php");
?>
<HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<BODY bgcolor="#FFFFFF">
<center>
<H3>修改密碼：</H3>
<TABLE BORDER=1>
<?php
    // 資料庫設定
    $mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
    $mysqli->query("SET NAMES 'utf8'");	 
    $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
    $mysqli->query('SET CHARACTER_SET_RESULTS=utf8');
	 $sql ="Select * from `user_data` where UserID='$ShowID'";
	 $rows = $mysqli->query( $sql );
	 $row = $rows->fetch_row();
	 $email = $row[4];
	 $oldpass = $_POST['oldpass'];
	 $pass1 = $_POST['pass1'];
	 $pass2 = $_POST['pass2'];
	 if($oldpass != $row[2])
	 {
	 	echo "密碼修改失敗！請確定您輸入的密碼和原先舊密碼是否相同！（請注意大小寫）";
	    exit;
	 }
	 if ( strlen( $pass1) < 4 )
	 {
	    echo "<p>新密碼至少需四位數字或字母！";
	    exit;
	 }
	 if ( $pass1 != $pass2 )
	 {
	    echo "密碼修改失敗！請確定新輸入密碼是否相同！（請注意大小寫）";
	    exit;
	 }
	 $sql = "Update `user_data` Set Password='$pass2'  Where UserID = '$ShowID'"; 
     //echo $sql."<br>";
	 $mysqli->query( $sql );
     $mysqli->close();

	 if( !empty($email) )
	 {
		 $Subject = "策略客戶製造即時系統通知您，您的密碼已經變更了";			 
		 $emailaddress1 = $email;
		 $Subject = "=?UTF-8?B?".base64_encode($Subject)."?=";
		 $message ='您的密碼已經更新為【'.$pass2.'】，原先的密碼【'.$oldpass.'】，已經不能使用了。';
		 $message = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head><body><p>您的密碼已經更新為【".$pass2."】，原先的密碼【".$oldpass."】，已經不能使用了。</p></body></html>";
		 $headers = "From: 策略客戶製造即時系統通知<denil_chuang@cn.foxlink.com.tw>" . "\r\n";
	 	 $headers = $headers."Content-Type: text/html; ". "charset=UTF-8; format=flowed\n". "MIME-Version: 1.0\n". "Content-Transfer-Encoding: 8bit\n";
	 	 $headers = iconv("UTF-8", "big5", $headers);		  
		 mail($emailaddress1, $Subject, $message,$headers);
	 }
     echo "<p><p><H3>密碼修改成功！</H3>";  
     session_start();
	 $_SESSION["ssn_psd"]= $pass2;
?>
</BODY>
</HTML>