<?php
ini_set("memory_limit","1024M");
$project = $_GET["project"];
$device = $_GET["device"];

if($project!="" && $device!="")
    $page="aoi_file_format_setting.php?project=".$project."&device=".$device;
else
    $page="aoi_file_format_setting.php";
require_once("auth2.php");
require_once("mysql_connect.php");
@require_once("includes/xajax_core/xajax.inc.php");
//建立物件
$xajax = new xajax(); 
//$xajax->setFlag("debug",true);
$xajax->configure( 'javascript URI', './includes' );
$xajax->configure( 'debug', false);
$xajax->configure( 'errorHandler', true );
$xajax->configure( 'logFile', 'xajax_error_log.log' );
//註刪回應函數
$xajax->register(XAJAX_FUNCTION,"getFormat");
$xajax->register(XAJAX_FUNCTION,"addWorkno");
$xajax->register(XAJAX_FUNCTION,"basicDataFormat");
$xajax->register(XAJAX_FUNCTION,"extendDataFormat");
$xajax->register(XAJAX_FUNCTION,"showFileContent");
$xajax->register(XAJAX_FUNCTION,"clearFileContent");
$xajax->register(XAJAX_FUNCTION,"save");
//處理非同步要求
$xajax->processRequest();

function getFormat($check,$project,$device)
{
    $objResponse = new xajaxResponse();
    $objResponse->assign('preloader', 'style.display', 'none');
    
    if($check)
    {
        global $groupname;
        $mydb = new DataBase();
        $mydb->connect_fq("sfc");

        $sql="SELECT * FROM `device_setting` where project='".$project."' and Device_Name='".$device."'";
        $mydb->query($sql);
        
        $row = $mydb->result->fetch_array(MYSQLI_BOTH);
        $factory = $row["FAC_CODE"];
        $rows_count = $mydb->result->num_rows;
        $mydb->result->free_result();
        $mydb->disconnect();
        
        if($rows_count > 0)
        {
            $sub_sql = "";
            $workno_count = 0;
            
            if($factory=="FQ")
                $mydb->connect_fq("aoi");
            else
                $mydb->connect_ks("aoi");
            
            $sql="SELECT Measure_Workno,Workno_Chinese FROM  `measure_info` where project='".$project."' and device_name='".$device."' order by workno_order";
            $mydb->query($sql);
            
            if($mydb->result->num_rows == 0)
            {
                $mode = 1;
                $objResponse->confirmCommands(6,"此專案及設備名稱未設定過檔案格式，是否要進行設定?");
                
                $cch = "<span style=\"border: gray;\"><b>基本格式設定表</b></span>";
                $cch .= "<table id=\"basic_format_table\" border=1>";
                $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\">名稱</td><td class=\"title\">類型</td></tr>";
                $cch .= "<tr><td>1</td><td><input size=\"20\" value=\"檢測編號\" disabled /></td><td><select disabled><option value=\"varchar\" selected>文字</option><option value=\"int\">數值</option></select></td></tr>";
                $cch .= "<tr><td>2</td><td><input size=\"20\" value=\"檢測工站狀態\" disabled /></td><td><select disabled><option value=\"varchar\">文字</option><option value=\"int\" selected>數值</option></select></td></tr>";
                $cch .= "<tr><td>3</td><td><input size=\"20\" value=\"檢測日期\" disabled /></td><td><select disabled><option value=\"varchar\" selected>文字</option><option value=\"int\">數值</option></select></td></tr>";
                $cch .= "<tr><td>4</td><td><input size=\"20\" value=\"檢測時間\" disabled /></td><td><select disabled><option value=\"varchar\" selected>文字</option><option value=\"int\">數值</option></select></td></tr>";
                $cch .= "<tr><td>5</td><td><input size=\"20\" value=\"模號\" disabled /></td><td><select disabled><option value=\"varchar\" selected>文字</option><option value=\"int\">數值</option></select></td></tr>";
                $cch .= "<tr><td>6</td><td><input size=\"20\" value=\"穴號\" disabled /></td><td><select disabled><option value=\"varchar\" selected>文字</option><option value=\"int\">數值</option></select></td></tr>";
                $cch .= "</table>";
                $cch .= "<input type=\"button\" value=\"新增代碼\" onclick=\"insert_row();\" disabled>&nbsp;&nbsp;";
                $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last();\" disabled><br><br>";
                $objResponse->assign('basic_span','innerHTML',$cch);
                
                $cch = "<span style=\"border: gray;\"><b>進階格式設定表</b></span><br>";
                $cch .= "請輸入檢測工站數量：<input id=\"workno_count\" type=\"text\" size=\"1\" />&nbsp;&nbsp;<input type=\"button\" value=\"確定\" onclick=\"addWorkno();\"><br>";
                $cch .= "<span id=\"workno_span\"></span>";
                $objResponse->assign('extend_span','innerHTML',$cch);
                
                $cch = "請輸入一次檢測數量：<input id=\"measure_unit\" type=\"text\" size=\"1\" />&nbsp;<input type=\"button\" id=\"down_btn\" value=\"  模擬TXT檔案內容\" onclick=\"showContent('".$mode."','".$project."',".$workno_count.");\"/><br><br>";
                $objResponse->assign('demo_span','innerHTML',$cch);
            }
            else
            {
                $mode = 2;
                $workno_array = array();
                
                while($row = $mydb->result->fetch_row())
                {
                    $workno_array[$row[0]] = $row[1];
                }
                $workno_count = count($workno_array);
                $objResponse->call('xajax_basicDataFormat', $project, $factory);
                $objResponse->call('xajax_extendDataFormat', $project, $workno_array, $factory);
                $cch = "請輸入一次檢測數量：<input id=\"measure_unit\" type=\"text\" size=\"1\" />&nbsp;<input type=\"button\" id=\"down_btn\" value=\"  模擬TXT檔案內容\" onclick=\"showContent('".$mode."','".$project."',".$workno_count.");\"/><br><br>";
                $objResponse->assign('demo_span','innerHTML',$cch);
            }
            $mydb->result->free_result();
            
            if($groupname!="Adm" && $mode==2)
            {
                $cch = "<input type=\"button\" class=\"groovybutton\" value=\"儲存修改\" onclick=\"checkSure('".$mode."','".$project."','".$device."','".$factory."',".$workno_count.");\" disabled>";
                $objResponse->alert("若需變更檔案格式設定，請洽系統管理員進行修改!!");
            }
            else
                $cch = "<input type=\"button\" class=\"groovybutton\" value=\"儲存修改\" onclick=\"checkSure('".$mode."','".$project."','".$device."','".$factory."',".$workno_count.");\">";
            $objResponse->assign('save_span','innerHTML',$cch);
            $objResponse->assign('format_border', 'style.display', '');
            $objResponse->assign('result_span', 'style.display', '');
            $mydb->disconnect();  
        }
        else
        {
            $objResponse->alert("此專案未進行過設備連線設定，請先至即時系統『車間資訊』=>『連線設定』進行設置!!");
            $objResponse->assign('result_span', 'style.display', 'none');
        }
    }
    return $objResponse;
}

function worknoItem($order)
{
    $cch = "<table border=1><tr><td>";
    $cch .= "檢測第".$order."站，請輸入檢測工站英文名稱：<input id=\"workno".$order."\" type=\"text\" size=\"10\" />，中文名稱(若無，請空白)：<input id=\"workno_cname".$order."\" type=\"text\" size=\"10\" />";
    $cch .= "<table id=\"workno_table".$order."\" border=1>";
    $cch .= "<tr><td class=\"title\">編號</td><td class=\"title\">檢測項目名稱</td></tr>";
    $cch .= "<tr><td>1</td><td><input size=\"20\" value=\"\" /></td></tr>";
    $cch .= "</table>";
    $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row2('".$order."');\">&nbsp;&nbsp;";
    $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1('".$order."');\">";
    $cch .= "</td></tr></table>";
    return $cch;
}

function addWorkno($workno_count)
{
    $objResponse = new xajaxResponse();
    $cch = "<font color=\"red\"><b>**重要!請按照檢測順序填寫。**</b></font>";
    for($i=0; $i<$workno_count; $i++)
        $cch .= "<br>".worknoItem($i+1);
    $objResponse->assign('workno_span','innerHTML',$cch);
    return $objResponse;
}

function basicDataFormat($project,$factory)
{
    $objResponse = new xajaxResponse();
    global $groupname;
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("aoi");
    else
        $mydb->connect_ks("aoi");
    
    $cch = "<span style=\"border: gray;\"><b>基本格式設定表</b></span>";
    $cch .= "<table id=\"basic_format_table\" border=1>";
    $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\">名稱</td><td class=\"title\">類型</td></tr>";
    
    $sql="SELECT Code,Title_Name,Value_type FROM `data_basic_format` where project='".$project."' order by Code";
    $mydb->query($sql);
    if($mydb->result->num_rows > 0)
    {
        while($row = $mydb->result->fetch_row())
        {
            $cch .= "<tr><td>".$row[0]."</td><td>";
            if($groupname!="Adm" && $groupname!="系統管理者")
                $cch .= "<input size=\"20\" value=\"".$row[1]."\" disabled /></td><td><select disabled>";
            else
                $cch .= "<input size=\"20\" value=\"".$row[1]."\" /></td><td><select>";
            
            if($row[2]=="varchar")
            {
                $cch .= "<option value=\"varchar\" selected>文字</option>";
                $cch .= "<option value=\"int\">數值</option>";
            }
            else
            {
                $cch .= "<option value=\"varchar\">文字</option>";
                $cch .= "<option value=\"int\" selected>數值</option>";
            }
            $cch .= "</select></td></tr>";
        }
        $mydb->result->free_result();
    }
    $mydb->disconnect();
    
    $cch .= "</table>";
    
    if($groupname!="Adm" && $groupname!="系統管理者")
    {
        $cch .= "<input type=\"button\" value=\"新增代碼\" onclick=\"insert_row();\" disabled>&nbsp;&nbsp;";
        $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last();\" disabled><br><br>";
    }
    else
    {
        $cch .= "<input type=\"button\" value=\"新增代碼\" onclick=\"insert_row();\">&nbsp;&nbsp;";
        $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last();\"><br><br>";
    }
    
    $objResponse->assign('basic_span','innerHTML',$cch);
    return $objResponse;
}

function extendDataFormat($project, $workno_array, $factory)
{
    $objResponse = new xajaxResponse();
    global $groupname;
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("aoi");
    else
        $mydb->connect_ks("aoi");
    
    $cch = "<span style=\"border: gray;\"><b>進階格式設定表</b></span><br>";
    $cch .= "<input id=\"workno_count\" type=\"hidden\" value=\"".count($workno_array)."\" />";
    
    $index = 0;
    foreach($workno_array as $workno => $cname)
    {
        $index++;
        $cch .= "檢測第".$index."站，檢測工站英文名稱：";
        if($groupname!="Adm" && $groupname!="系統管理者")
            $cch .= "<input id=\"workno".$index."\" type=\"text\" size=\"10\" value=\"".$workno."\" disabled />，中文名稱(若無，請空白)：<input id=\"workno_cname".$index."\" type=\"text\" size=\"10\" value=\"".$cname."\" disabled />";
        else
            $cch .= "<input id=\"workno".$index."\" type=\"text\" size=\"10\" value=\"".$workno."\" />，中文名稱(若無，請空白)：<input id=\"workno_cname".$index."\" type=\"text\" size=\"10\" value=\"".$cname."\" />";
        $cch .= "<table id=\"workno_table".$index."\" border=1>";
        $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\">名稱</td><td class=\"title\">類型</td></tr>";

        $sql="SELECT Code,Title_Name,Value_type FROM `data_extend_format` where project='".$project."' and Measure_Workno='".$workno."' order by Code";
        $mydb->query($sql);

        while($row = $mydb->result->fetch_row())
        {
            if($groupname!="Adm" && $groupname!="系統管理者")
                $cch .= "<tr><td><input size=\"2\" value=\"".$row[0]."\" disabled /></td><td><input size=\"20\" value=\"".$row[1]."\" disabled /></td><td><select disabled>";
            else
                $cch .= "<tr><td><input size=\"2\" value=\"".$row[0]."\" /></td><td><input size=\"20\" value=\"".$row[1]."\" /></td><td><select>";
            
            if($row[2]=="varchar")
            {
                $cch .= "<option value=\"varchar\" selected>文字</option>";
                $cch .= "<option value=\"int\">數值</option>";
            }
            else
            {
                $cch .= "<option value=\"varchar\">文字</option>";
                $cch .= "<option value=\"int\" selected>數值</option>";
            }
            $cch .= "</select></td></tr>";
        }
        $mydb->result->free_result();
        
        $cch .= "</table>";
        
        if($groupname!="Adm" && $groupname!="系統管理者")
        {
            $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row1('".$index."');\" disabled>&nbsp;&nbsp;";
            $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1('".$index."');\" disabled><br><br>";
        }
        else
        {
            $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row1('".$index."');\">&nbsp;&nbsp;";
            $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1('".$index."');\"><br><br>";
        }
    }
    $mydb->disconnect();
    $objResponse->assign('extend_span','innerHTML',$cch);
    return $objResponse;
}

function showFileContent($mode,$project,$unit,$basic_formats,$extend_formats,$workno_count)
{
    $objResponse = new xajaxResponse();
    $cch = "";
    $tmp_workno = "";
    
    for($i=0; $i<count($extend_formats); $i++)
    {
        for($j=0; $j<$unit; $j++)
        {
            if($extend_formats[$i][0] != $tmp_workno) //是新的檢測工站
            {
                if($i != 0)
                    $cch .= ${"cch".$j}."<br>";
                //產生一筆新資料    
                ${"cch".$j} = $extend_formats[$i][0]."&emsp;".($j+1)."&emsp;".$basic_formats[1][0]."&emsp;2016-01-01&emsp;22:46:02&emsp;".$basic_formats[4][0]."&emsp;".$basic_formats[5][0]."&emsp;1.479&emsp;1";
            }
            else //相同檢測工站
            {
                //往後延伸該筆資料長度
                ${"cch".$j} .= "&emsp;1.479&emsp;1";
            }
        }
        $tmp_workno = $extend_formats[$i][0];
    }
    
    for($j=0; $j<$unit; $j++)
        $cch .= ${"cch".$j}."<br>";

    $cch .= "<br><input type=\"button\" id=\"up_btn\" value=\"  隱藏內容\" onclick=\"xajax_clearFileContent('".$mode."','".$project."',".$workno_count.");\"/><br><br>";
    
    $objResponse->assign('demo_span','innerHTML',$cch);
    return $objResponse;
}

function clearFileContent($mode,$project,$workno_count)
{
    $objResponse = new xajaxResponse();
    $cch = "請輸入一次檢測數量：<input id=\"measure_unit\" type=\"text\" size=\"1\" />&nbsp;<input type=\"button\" id=\"down_btn\" value=\"  模擬TXT檔案內容\" onclick=\"showContent('".$mode."','".$project."',".$workno_count.");\"/><br><br>";
    $objResponse->assign('demo_span','innerHTML',$cch);
    return $objResponse;
}

function save($mode,$project,$device,$basic_formats,$extend_formats,$factory)
{
    $objResponse = new xajaxResponse();
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("aoi");
    else
        $mydb->connect_ks("aoi");

    $sql = "delete from `data_basic_format` where project='".$project."'";
    $mydb->execute($sql);
        
    // 儲存基本格式設定表
    for($i=0; $i<count($basic_formats); $i++)
    {
        $sql = "insert into `data_basic_format` (Project,Code,Title_Name,Value_type) values ('".strtoupper($project)."',".$basic_formats[$i][0].",'".$basic_formats[$i][1]."','".$basic_formats[$i][2]."')";
        //$cch .= $sql."<br>";
        $mydb->execute($sql);
    }
    
    $sql = "SELECT measure_workno FROM  `measure_info` where project='".$project."' and device_name='".$device."' order by workno_order";
    $mydb->query($sql);
    
    if($mydb->result->num_rows > 0)
    {
        $count = 0;
        $sub_sql = "`Measure_Workno` in (";
        while($row = $mydb->result->fetch_row())
        {
            //刪除原有的data表
            $mydb->execute("drop table IF EXISTS `".$project."_".$row[0]."_data`");
            //刪除原有的data_new表
            $mydb->execute("drop table IF EXISTS `".$project."_".$row[0]."_data_new`");
                
            if($count>0)
                $sub_sql .= ",";
            $sub_sql .= "'".$row[0]."'";
            $count++;
        }
        $sub_sql .= ")";
        
        $sql = "delete from `data_extend_format` where project='".$project."' and ".$sub_sql;
        $mydb->execute($sql);
    }
    $mydb->result->free_result();

    $tmp_workno = "";
    $tmp_item = "";
    $create_sql = "";
    $code = 7;
    $workno_index = 0;

    $sql = "delete from `measure_info` where project='".$project."' and Device_Name='".$device."'";
    $mydb->execute($sql);
    
    // 儲存進階格式設定表 & 建立data表
    for($i=0; $i<count($extend_formats); $i++)
    {
        $workno = $extend_formats[$i][0];
        $measure_item = $extend_formats[$i][2];
        $workno_cname = $extend_formats[$i][4];

        // 儲存進階格式設定表
        $sql = "insert into `data_extend_format` (Project,Measure_Workno,Code,Title_Name,Value_type) values ('".strtoupper($project)."','".$workno."',".$extend_formats[$i][1].",'".$measure_item."','".$extend_formats[$i][3]."')";
        //$cch .= $sql."<br>";
        $mydb->execute($sql);

        if($workno != $tmp_workno)
        {   
            $code = 7;
            //將上個檢測項目所Create SQL，進行執行動作
            if($create_sql!="")
            {
                //建立data表
                $mydb->execute($create_sql.");");
                //建立Primary Key
                $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data` ADD PRIMARY KEY( `ID`, `Line`, `Device_Name`, `Code1`);");
                //建立日期的Index
                $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data` ADD INDEX `date_index`( `Code3`);");
     
                //建立data_new表
                $mydb->execute(str_replace("_data","_data_new",$create_sql).")");
                //建立Primary Key
                $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data_new` ADD PRIMARY KEY( `ID`, `Line`, `Device_Name`, `Code1`);");
                //建立日期的Index
                $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data_new` ADD INDEX `date_index`( `Code3`);");
                
                //insert data_new表的觸發器                
                $trigger = "CREATE TRIGGER `".$project."_".$tmp_workno."_data_trigger` "
                        ."AFTER INSERT ON `".$project."_".$tmp_workno."_data` "
                        ."FOR EACH ROW "
                        ."BEGIN "
                        ."    INSERT INTO `".$project."_".$tmp_workno."_data_new` "
                        ."    SELECT * "
                        ."            FROM `".$project."_".$tmp_workno."_data` "
                        ."            WHERE ID = new.ID and line=new.line and device_name=new.device_name and Code1=new.Code1; "
                        ."END ;";
                $mydb->execute($trigger);
            }
            
            //為新的檢測工站建立暫存的SQL指令，暫不實際執行
            $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_".$workno."_data` ("
                    ."`ID` BIGINT(13) UNSIGNED,"
                    ."`Line` VARCHAR(2) NOT NULL,"
                    ."`Device_Name` VARCHAR(20) NOT NULL,";
                    
            for($j=0; $j<count($basic_formats); $j++)
            {
                $create_sql .= "`Code".$basic_formats[$j][0]."` ";
                $title = $basic_formats[$j][1];
                $value_type = $basic_formats[$j][2];
                
                if($value_type=="varchar")
                {
                    if($title=="檢測日期")
                        $create_sql .= "DATE NOT NULL,";
                    else if($title=="檢測時間")
                        $create_sql .= "TIME NOT NULL,";
                    else
                    {
                        if(($title=="模號") || ($title=="穴號"))
                            $create_sql .= "VARCHAR(1),";
                        else
                            $create_sql .= "VARCHAR(1) NOT NULL,";
                    }
                }
                else
                    $create_sql .= "INT(1) NOT NULL,";
            }
            $create_sql .= "`Code".$code."` DECIMAL(6,3)";
        }
        else
        {
            $code++;
            
            if(($code%2)==0)
                $create_sql .= ",`Code".$code."` INT(1)";
            else
                $create_sql .= ",`Code".$code."` DECIMAL(6,3)";
        }

        //儲存measure_info
        if($workno != $tmp_workno)
        {
            $workno_index++;
            $sql = "insert into `measure_info` (Project,Device_Name,Measure_Workno,Workno_Chinese,Workno_Order) values ('".strtoupper($project)."','".$device."','".$workno."','".$workno_cname."',".$workno_index.");";
            //$cch .= $sql."<br>";
            $mydb->execute($sql);
        }       
        $tmp_workno = $workno;
        $tmp_item = $measure_item;
    }

    //將最後一個檢測工站所Create SQL，進行執行動作
    if($create_sql!="")
    {
        //建立data表
        $mydb->execute($create_sql.");");
        //建立Primary Key
        $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data` ADD PRIMARY KEY( `ID`, `Line`, `Device_Name`, `Code1`);");
        //建立日期的Index
        $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data` ADD INDEX `date_index`( `Code3`);");
        
        //建立data_new表
        $mydb->execute(str_replace("_data","_data_new",$create_sql).");");
        //建立Primary Key
        $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data_new` ADD PRIMARY KEY( `ID`, `Line`, `Device_Name`, `Code1`);");
        //建立日期的Index
        $mydb->query("ALTER TABLE `".$project."_".$tmp_workno."_data_new` ADD INDEX `date_index`( `Code3`);");

        //insert data_new表的觸發器                
        $trigger = "CREATE TRIGGER `".$project."_".$tmp_workno."_data_trigger` "
                ."AFTER INSERT ON `".$project."_".$tmp_workno."_data` "
                ."FOR EACH ROW "
                ."BEGIN "
                ."    INSERT INTO `".$project."_".$tmp_workno."_data_new` "
                ."    SELECT * "
                ."            FROM `".$project."_".$tmp_workno."_data` "
                ."            WHERE ID = new.ID and line=new.line and device_name=new.device_name and Code1=new.Code1; "
                ."END ;";
        $mydb->execute($trigger);
    }
  
    //建立event表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_event` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`Line` VARCHAR(2) NOT NULL,"
                ."`Device_Name` VARCHAR(20) NOT NULL,"
                ."`Category` INT(3) UNSIGNED NOT NULL,"
                ."`Start_Time` DATETIME,"
                ."`End_Time` DATETIME,"
                ."`Message` VARCHAR(30))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    //建立Start_Time及End_Time的Index
    $mydb->query("ALTER TABLE `".$project."_event` ADD INDEX `start_index`( `Start_Time`), ADD INDEX `end_index`( `End_Time`);");
        //建立event_new表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_event_new` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`Line` VARCHAR(2) NOT NULL,"
                ."`Device_Name` VARCHAR(20) NOT NULL,"
                ."`Category` INT(3) UNSIGNED NOT NULL,"
                ."`Start_Time` DATETIME,"
                ."`End_Time` DATETIME,"
                ."`Message` VARCHAR(30))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    //建立Start_Time及End_Time的Index
    $mydb->query("ALTER TABLE `".$project."_event_new` ADD INDEX `start_index`( `Start_Time`), ADD INDEX `end_index`( `End_Time`);");
     //insert event_new表的觸發器
     $trigger="DROP TRIGGER IF EXISTS `".$project."_event_trigger`"; 
     $mydb->execute($trigger);               
        $trigger = "CREATE TRIGGER `".$project."_event_trigger` "
                ."AFTER INSERT ON `".$project."_event` "
                ."FOR EACH ROW "
                ."BEGIN "
                ."    INSERT INTO `".$project."_event_new` "
                ."    SELECT * "
                ."            FROM `".$project."_event` "
                ."            WHERE ID = new.ID; "
                ."END ;";

 //$objResponse->alert($trigger);
        $mydb->execute($trigger);
 //update event_new表的觸發器
    $trigger="DROP TRIGGER IF EXISTS `"
    .$project."_event_update_trigger`"; 
         $mydb->execute($trigger);
     $trigger="create trigger `"
     .$project."_event_update_trigger` after update on `"
     .$project."_event` for each row   
    begin 
    if new.End_Time!=old.End_Time  or (old.End_Time is null)
        then   
    update `"
    .$project."_event_new` set `"
    .$project."_event_new`.`End_Time`=new.`End_Time` where `"
    .$project."_event_new`.`ID`=new.`ID`; 
    end if;
    end ;";
//$objResponse->alert($trigger);
$mydb->execute($trigger);
    //建立File Record表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_file_record` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`File_Path` VARCHAR(60) NOT NULL,"
                ."`File_Name` VARCHAR(20) NOT NULL,"
                ."`Reading_Time` DATETIME,"
                ."`Reading_Success` TINYINT(1) NOT NULL,"
                ."CONSTRAINT `File_Path` UNIQUE (File_Path, File_Name))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    
    //建立Data預存表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_statistics` ("
                ."`format` TINYINT(2) UNSIGNED NOT NULL,"
                ."`work_date` DATE NOT NULL,"
                ."`line` TINYINT(2) UNSIGNED NOT NULL,"
                ."`device_name` VARCHAR(15) NOT NULL,"
                ."`measure_workno` VARCHAR(25) NOT NULL,"
                ."`shift` CHAR(1) NOT NULL,"
                ."`parameter1` VARCHAR(45) NOT NULL,"
                ."`parameter2` VARCHAR(45) NOT NULL,"
                ."`qty` INT(8) UNSIGNED NOT NULL,"
                ."CONSTRAINT `KEY` PRIMARY KEY (format,work_date,line,device_name,measure_workno,shift,parameter1,parameter2))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    
    //建立Event預存表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_statistics_event` ("
                ."`format` TINYINT(2) UNSIGNED NOT NULL,"
                ."`work_date` DATE NOT NULL,"
                ."`line` TINYINT(2) UNSIGNED NOT NULL,"
                ."`device_name` VARCHAR(15) NOT NULL,"
                ."`category` VARCHAR(25) NOT NULL,"
                ."`shift` CHAR(1) NOT NULL,"
                ."`parameter1` VARCHAR(45) NOT NULL,"
                ."`parameter2` VARCHAR(45) NOT NULL,"
                ."`qty` INT(8) UNSIGNED NOT NULL,"
                ."CONSTRAINT `KEY` PRIMARY KEY (format,work_date,line,device_name,category,shift,parameter1,parameter2))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    $mydb->disconnect();
    
    /*
    if($mode==1)
    {
        $subject = "=?UTF-8?B?".base64_encode("AOI檔案傳輸格式-新專案：".$project)."?=";
        mail("denil_chuang@cn.foxlink.com.tw",$subject,"=?UTF-8?B?請製作讀檔程式!?=");
    }
    */
    $objResponse->alert("檔案傳輸格式修改成功!!");
    return $objResponse;
}

function pattern_match($data)
{
    $pattern = "/^[A-Za-z]+$/";
    if(preg_match($pattern,$data))
        return true;
    else
        return false; 
}
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AOI檔案傳輸格式設定</title>
    <link href="includes/class.css"  rel="stylesheet" type="text/css" />
<?
$xajax->printJavascript(); //輸出用戶
?>
<script> 
function check()
{
    if(document.getElementById("project").value.trim()=="")
    {
        alert("請填寫專案名稱!!");
        return false;
    }
    
    var sel_device = document.getElementById("device_name");
    if(sel_device.options[sel_device.selectedIndex].value=="")
    {
        alert("請選擇設備名稱!!");
        return false;
    }
    return true;
}

function check1(mode,workno_count)
{
    var table = document.getElementById("basic_format_table");
    var row_num = table.rows.length;
    var measure_unit = document.getElementById("measure_unit").value.trim();
        
    if(measure_unit=="")
    {
        alert("請填寫一次檢測數量!!");
        return false;
    }
    
    for(var i=1; i< row_num; i++)
    {  
        if(table.rows[i].cells[1].firstChild.value.trim()=="")
        {
            alert("請填寫基本格式設定表的名稱!!");
            return false;
        }
    }
    
    if(mode=="1")  //建立新專案
    {
        workno_count = document.getElementById("workno_count").value.trim();
        
        if(workno_count=="")
        {
            alert("請填寫檢測工站數量!!");
            return false;
        }
        
        var workno_array = new Array();
        
        for(var i=1; i<=workno_count; i++)
        {
            var table1 = document.getElementById("workno_table"+i);
            var workno = document.getElementById("workno"+i).value.trim();
            var workno_modify = workno.substring(0,1).toUpperCase()+workno.substring(1).toLowerCase();
            
            if(table1==null)
            {
                alert("請在進階格式設定表中輸入檢測工站數量，並按下'確定'鈕!!");
                return false;
            }
            var row_num1 = table1.rows.length;
            
            if(workno_modify=="")
            {
                alert("請填寫檢測第"+i+"站的檢測工站英文名稱!!");
                return false;
            }
            
            if(workno_array.indexOf(workno_modify) > -1)
            {
                alert("檢測工站名稱重複!!");
                return false;
            }
            
            //將檢測工站英文名稱儲存陣列中，用以判斷是否重複
            workno_array.push(workno_modify);
            /*
            if(document.getElementById("workno_cname"+i).value.trim()=="")
            {
                alert("請填寫檢測第"+i+"站的檢測工站中文名稱!!");
                return false;
            }
            */
            
            for(var j=1; j< row_num1; j++)
            {
                if(table1.rows[j].cells[1].firstChild.value.trim()=="")
                {
                    alert("請填寫檢測第"+i+"站的檢測項目名稱!!");
                    return false;
                }
            }
        }
    }
    else  //修改舊專案
    {
        for(var i=1; i<=workno_count; i++)
        {
            var table1 = document.getElementById("workno_table"+i);
            var row_num1 = table1.rows.length;
            
            for(var j=1; j< row_num1; j++)
            {                
                if(table1.rows[j].cells[0].firstChild.value.trim()=="")
                {
                    alert("請填寫檢測第"+i+"站的代碼!!");
                    return false;
                }
                
                if(table1.rows[j].cells[1].firstChild.value.trim()=="")
                {
                    alert("請填寫檢測第"+i+"站的名稱!!");
                    return false;
                }
            }
        }
    }
    return true;
}

function get_project()
{
    return document.getElementById("project").value.trim();
}

function get_device()
{
    var sel_device = document.getElementById("device_name");
    return sel_device.options[sel_device.selectedIndex].value;
}

function get_unit()
{
    return document.getElementById("measure_unit").value.trim();
}

function addWorkno()
{
    var workno_count = document.getElementById("workno_count").value.trim();
    
    if(workno_count=="")
        alert("請輸入檢測工站數量");
    else
        xajax_addWorkno(workno_count);
}

function insert_row()
{
    var table = document.getElementById("basic_format_table");
    var row_num = table.rows.length - 1; //扣除標題列
    var row = table.insertRow();
    
    // text cell
    var td_code = row.insertCell();
    td_code.textContent = row_num+1;
    
    // input text cell
    var td_title = row.insertCell();
    var element1 = document.createElement("input");             
    element1.type = "text";
    element1.size = "20";         
    td_title.appendChild(element1);  
    
    // select cell
    var td_type = row.insertCell();
    var element2 = document.createElement("select");
    element2.options[0] = new Option('文字', 'varchar');
    element2.options[1] = new Option('數值', 'int');
    //var option1 = document.createElement("option");
    //option1.value = "varchar";
    //option1.textContent = "文字";
    //var option2 = document.createElement("option");
    //option2.value = "int";
    //option2.textContent = "數值";
    //element2.appendChild(option2);
    td_type.appendChild(element2);
}

function insert_row1(order)
{
    var table = document.getElementById("workno_table"+order);
    var row_num = table.rows.length - 1; //扣除標題列
    var row = table.insertRow();

    // input text cell
    var td_code = row.insertCell();
    var element2 = document.createElement("input");             
    element2.type = "text";
    element2.size = "2";               
    td_code.appendChild(element2);
    
    // input text cell
    var td_title = row.insertCell();
    var element3 = document.createElement("input");             
    element3.type = "text";
    element3.size = "20";               
    td_title.appendChild(element3);  
    
    // select cell
    var td_type = row.insertCell();
    var element4 = document.createElement("select");
    element4.options[0] = new Option('文字', 'varchar');
    element4.options[1] = new Option('數值', 'int');
    td_type.appendChild(element4);
}

function insert_row2(order)
{
    var table = document.getElementById("workno_table"+order);
    var row_num = table.rows.length - 1; //扣除標題列
    var row = table.insertRow();
    
    // text cell
    var td_no = row.insertCell();
    td_no.textContent = row_num+1;
    // input text cell
    var td_title = row.insertCell();
    var element = document.createElement("input");             
    element.type = "text";
    element.size = "20";               
    td_title.appendChild(element);
}

function delete_last()
{
    var table = document.getElementById("basic_format_table");
    if (table.rows.length > 2) 
        table.deleteRow(table.rows.length - 1);
}

function delete_last1(order)
{
    var table = document.getElementById("workno_table"+order);
    if (table.rows.length > 2) 
        table.deleteRow(table.rows.length - 1);
}

function basicTable_content()
{
    var table = document.getElementById("basic_format_table");
    var row_num = table.rows.length;
    var formats = new Array(row_num-1); //扣除標題列
    
    for(var i=0; i< (row_num-1); i++)
    {
        formats[i] = new Array(3);
        formats[i][0] = table.rows[i+1].cells[0].innerHTML;
        formats[i][1] = table.rows[i+1].cells[1].firstChild.value;
        formats[i][2] = table.rows[i+1].cells[2].firstChild[table.rows[i+1].cells[2].firstChild.selectedIndex].value;
    }
    return formats;
}

function basicTable_content1()
{
    var table = document.getElementById("basic_format_table");
    var row_num = table.rows.length;
    var formats = new Array(row_num-1); //扣除標題列
    
    for(var i=0; i< (row_num-1); i++)
    {
        formats[i] = new Array(1);
        formats[i][0] = table.rows[i+1].cells[1].firstChild.value;
    }
    return formats;
}

function extendTable_content(mode)
{
    var workno_count = document.getElementById("workno_count").value.trim();
    
    if(mode=="1")
    {
        var total_rownum = 0;
        
        for(var i=1; i<=workno_count; i++)
        {
            for(var j=0; j< (document.getElementById("workno_table"+i).rows.length -1); j++)
            {
                total_rownum+=2; //每個檢測項目名稱，在資料表中分別儲存"文字"和"數值"兩種類型資料
            }
        }
        
        var formats = new Array(total_rownum);
        
        var index = 0;
        for(var i=1; i<=workno_count; i++)
        {
            var workno = document.getElementById("workno"+i).value.trim();
            var workno_cname = document.getElementById("workno_cname"+i).value.trim();
            var workno_modify = workno.substring(0,1).toUpperCase()+workno.substring(1).toLowerCase();
            if(workno_cname=="")
                workno_cname = workno_modify;
            var table = document.getElementById("workno_table"+i);
            var row_num = table.rows.length;
            
            for(var j=0; j< (row_num-1); j++)
            {
                var titlename = table.rows[j+1].cells[1].firstChild.value;
                var titlename_modify = titlename.substring(0,1).toUpperCase()+titlename.substring(1).toLowerCase();
                formats[index] = new Array(5);
                formats[index][0] = workno_modify;  //檢測工站
                formats[index][1] = 7+(j*2);     //代碼
                formats[index][2] = titlename_modify;  //名稱
                formats[index][3] = "varchar";  //類型
                formats[index][4] = workno_cname;  //檢測工站中文名
                index++;
                
                formats[index] = new Array(5);
                formats[index][0] = workno_modify;  //檢測工站
                formats[index][1] = 7+(j*2)+1;     //代碼
                formats[index][2] = titlename_modify+"檢測數值狀態";  //名稱
                formats[index][3] = "int";  //類型
                formats[index][4] = workno_cname;  //檢測工站中文名
                index++;
            }
        }
        return formats;
    }
    else
    {
        var total_rownum = 0;
        
        for(var i=1; i<=workno_count; i++)
        {
            for(var j=0; j< (document.getElementById("workno_table"+i).rows.length -1); j++)
            {
                total_rownum+=1;
            }
        }
        
        var formats = new Array(total_rownum);
        
        var index = 0;
        for(var i=1; i<=workno_count; i++)
        {
            var workno = document.getElementById("workno"+i).value.trim();
            var workno_cname = document.getElementById("workno_cname"+i).value.trim();
            var workno_modify = workno.substring(0,1).toUpperCase()+workno.substring(1).toLowerCase();
            var table = document.getElementById("workno_table"+i);
            var row_num = table.rows.length;
            
            for(var j=0; j< (row_num-1); j++)
            {
                var titlename = table.rows[j+1].cells[1].firstChild.value;
                var titlename_modify = titlename.substring(0,1).toUpperCase()+titlename.substring(1).toLowerCase();
                formats[index] = new Array(5);
                formats[index][0] = workno_modify; //檢測工站
                formats[index][1] = table.rows[j+1].cells[0].firstChild.value; //代碼
                formats[index][2] = titlename_modify; //檢測名稱
                formats[index][3] = table.rows[j+1].cells[2].firstChild[table.rows[j+1].cells[2].firstChild.selectedIndex].value; //類型
                formats[index][4] = workno_cname;  //檢測工站中文名
                index++;
            }
        }
        return formats;
    }
}

function extendTable_content1(mode)
{
    var workno_count = document.getElementById("workno_count").value.trim();
    var total_rownum = 0;
    
    for(var i=1; i<=workno_count; i++)
    {
        for(var j=0; j< (document.getElementById("workno_table"+i).rows.length -1); j++)
        {
            total_rownum++;
        }
    }
    
    if(mode==1)
        var formats = new Array(total_rownum);
    else
        var formats = new Array(total_rownum/2); //舊專案查詢模式下，每個檢測項目會顯示兩種型態類型，取一種就好
    
    var index = 0;
    for(var i=1; i<=workno_count; i++)
    {
        var workno = document.getElementById("workno"+i).value.trim();
        var workno_modify = workno.substring(0,1).toUpperCase()+workno.substring(1).toLowerCase();
        var workno_cname = document.getElementById("workno_cname"+i).value.trim();
        var table = document.getElementById("workno_table"+i);
        var row_num = table.rows.length;
        
        for(var j=0; j< (row_num-1); j++)
        {
            if( (mode==1) || ((mode==2) && (j%2==0)) )
            {
                var titlename = table.rows[j+1].cells[1].firstChild.value;
                var titlename_modify = titlename.substring(0,1).toUpperCase()+titlename.substring(1).toLowerCase();
                formats[index] = new Array(3);
                formats[index][0] = workno_modify;  //檢測工站
                formats[index][1] = workno_cname;  //檢測工站中文名稱
                formats[index][2] = titlename_modify;  //項目名稱
                index++;
            }
        }
    }
    return formats;
}

function checkSure(mode, project, device, $factory, workno_count)
{
    if(check1(mode, workno_count))
    {
        if(confirm("重要! 確定要進行變更?"))
            xajax_save(mode,project,device,basicTable_content(),extendTable_content(mode),$factory);
    }
}

function showContent(mode, project, workno_count)
{
    if(check1(mode, workno_count))
    {
        xajax_showFileContent(mode,project,get_unit(),basicTable_content1(),extendTable_content1(mode),workno_count);
    }
}

function start_loading()
{
    document.getElementById("preloader").style.display = "block";
    document.getElementById("result_span").style.display = "none";
}
</script>

<style type="text/css">
#format_border td{padding-left: 15px; padding-right: 15px;}

#down_btn
{
    background: url('./img/Double Down.png') no-repeat;
    cursor:pointer;
    vertical-align:middle;
}

#up_btn
{
    background: url('./img/Double Up.png') no-repeat;
    cursor:pointer;
    vertical-align:middle;
}
</style>
</head>
<body>
<H1>AOI檔案傳輸格式設定</H1><font color='red'>(僅限新專案新增修改使用)</font>
<form>
<img src="img/glo_button.gif" width=15 height=14>請輸入專案名稱:<input id="project" size="10" onkeypress="onKeyPress(event.keyCode);" value="<?=$project?>" />&nbsp;&nbsp;
<img src="img/glo_button.gif" width=15 height=14>請選擇設備名稱:<select id="device_name"><option></option>
<?
$mydb = new DataBase();
$mydb->connect_fq("sfc");

$sql = "Select * from  `device_name_mapping` where category='AOI'";
$mydb->query($sql);

$counter =0;
$dev_CName = array();
$dev_EName = array();
 
while($row = $mydb->result->fetch_row())
{
    $dev_CName[$counter] = $row[1];
    $dev_EName[$counter] = $row[2];
    $counter++;
}
$mydb->result->free_result();
$mydb->disconnect();
 
for($cnt=0;$cnt<count($dev_CName);$cnt++)
{
    if(pattern_match($dev_CName[$cnt]))
    {    
        $temp_CN_device1 = $dev_CName[$cnt]."_1";
        $temp_CN_device2 = $dev_CName[$cnt]."_2";
    }
    else
    {
        $temp_CN_device1 = $dev_CName[$cnt]."1";
        $temp_CN_device2 = $dev_CName[$cnt]."2";
    }
    
    if(strcmp($dev_EName[$cnt]."_1",$device)==0)    
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\" selected>".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\" >".$temp_CN_device2."</option>";
    }
    else if(strcmp($dev_EName[$cnt]."_2",$device)==0)    
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\" >".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\" selected>".$temp_CN_device2."</option>";
    }
    else
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\">".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\">".$temp_CN_device2."</option>";
    }
}
?>
</select>
<input id="makeSure" type="button" class="groovybutton" value="確定" onclick="start_loading();xajax_getFormat(check(),get_project(),get_device());">
<HR>
<center><div id="preloader" style="display:none;"><img src="./img/loading.gif" width="60px" height="60px" /></div></center>
<span id="result_span">
    <table id="format_border" border=1 style="display: none;">
    <tr><td valign="top"><span id="basic_span"></span></td>
    <td valign="top"><span id="extend_span"></span></td></tr>
    </table>
    <br />
    <span id="demo_span"></span>
    <span id="save_span"></span>
</span>
</form>
</body>
</html>