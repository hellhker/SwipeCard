﻿<HTML>
<BODY bgcolor="#FFFFFF" BACKGROUND="lbg.jpg" >
<CENTER>
<h3>編輯個人資料</h3>
<p>
<form>
<?php

  $usname = $_POST['usname'];
	$pwd = $_POST['pwd'];
	$chinese_name = $_POST['chinese_name'];
	$email = $_POST['email'];
	$dep_code = $_POST['dep_code'];
	$old_dep_code = $_POST['old_depcode'];
	$china_phone = $_POST['china_phone'];
	$phone_system = $_POST['phone_system'];
	if(strcmp("201",$phone_system)==0)
		$phone_system_name = "IOS";
	else if(strcmp("202",$phone_system)==0)
		$phone_system_name = "Android";	
	else
		$phone_system_name = "";	
	$phone_sn = $_POST['phone_sn'];
	$pad_system = $_POST['pad_system'];
	if(strcmp("201",$pad_system)==0)
		$pad_system_name = "IOS";
	else if(strcmp("202",$pad_system)==0)
		$pad_system_name = "Android";	
	else
		$pad_system_name = "";
	$pad_sn = $_POST['pad_sn'];
	
	
  $hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$mysqli->query("SET NAMES 'utf8'");	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 

	$sql_query = "Update `user_data` Set `Password`='$pwd',`ChineseName`='$chinese_name', `DepartmentCode`='$dep_code', `Phone_number_CN`='$china_phone', `Phone_wlan`='$phone_system', `Phone_sn`='$phone_sn', `Pad_wlan`='$pad_system', `Pad_sn`='$pad_sn' where `UserID`='".$usname."'";
  $mysqli->query($sql_query);
  
	$Subject = '製造即時系統個人資料變更通知';
  $Subject1 = "製造即時系統【".$chinese_name."】變更部門代碼";
  $Subject1 = iconv("UTF-8", "big5", $Subject1);
	$emailaddress1 = $email;
	//echo $emailaddress1;
	$Subject = "=?UTF-8?B?".base64_encode($Subject)."?=";
  $message = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head><body>";
  $message = $message."<p><table border=1>";
  $message = $message."<tr><td>帳號:</td><td>".$usname."</td></tr>";
  $message = $message."<tr><td>密碼:</td><td>".$pwd."</td></tr>";
  $message = $message."<tr><td>中文姓名:</td><td>".$chinese_name."</td></tr>";
  $message = $message."<tr><td>部門代碼:</td><td>".$dep_code."</td></tr>";
  $message = $message."<tr><td>大陸手機號碼:</td><td>".$china_phone."</td></tr>";
  /*
  $message = $message."<tr><td>手機系統:</td><td>".$phone_system_name."</td></tr>";
  $message = $message."<tr><td>手機裝置序號:</td><td>".$phone_sn."</td></tr>";
  $message = $message."<tr><td>平板系統:</td><td>".$pad_system_name."</td></tr>";
  $message = $message."<tr><td>平板裝置序號:</td><td>".$pad_sn."</td></tr>";
  */
  $message = $message."</table></p></body></html>";
  
  $message1 = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head><body><p>使用者姓名為【".$chinese_name."】，帳號為【".$usname."】，更改部門代碼從【".$old_dep_code."】=>【".$dep_code."】</p></body></html>";
	$headers = "Content-Type: text/html; ". "charset=UTF-8; format=flowed\n". "MIME-Version: 1.0\n". "Content-Transfer-Encoding: 8bit\n";
  $headers = $headers."To:".$emailaddress1."\r\n";
	$headers = $headers. "From: 製造即時系統通知<denil_chuang@foxlink.com.tw>" . "\r\n";
	$headers = iconv("UTF-8", "big5", $headers);		  
	//echo $emailaddress1;
	if(!empty($emailaddress1))
	{
			 mail($emailaddress1, $Subject, $message,$headers);						 							 
	}
	if(strcmp($dep_code,$old_dep_code)!=0)
  {
  	 mail("Vic_Pan@cn.foxlink.com.tw", $Subject1, $message1,$headers);	
	   mail("Mika_Huang@cn.foxlink.com.tw", $Subject1, $message1,$headers);
  }	
    $mysqli->close();		
?>
<CENTER>
<INPUT Type=button Name=Send Value="回首頁" onclick="window.location.href='http://scbg-iot.foxlink.com.tw/welcome.php'">
</CENTER>
</form>
</BODY>
</HTML> 
