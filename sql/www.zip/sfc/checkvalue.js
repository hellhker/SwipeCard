﻿function btnAddNew1_onclick() 
{
	var reason = new Array("塑膠裂紋","塑膠不飽模","塑膠插傷","塑膠刮傷","塑膠斷裂","塑膠毛邊","塑膠混料","塑膠異物","塑膠燒焦","塑膠縮水","塑膠壓傷","塑膠污髒");
	var	temp1 = "";
	for( var y = 0 ; y<12 ; y++)
	{
	 temp1 =  temp1 + "<OPTION value="+reason[y]+">"+reason[y]+"</OPTION>";
	}
		
	tbl1.innerHTML += "<SELECT NAME=reason[] chk=\"true\" fieldname=\"製程不良說明\"><OPTION value=\"\" selected>請選擇</OPTION>"+temp1+"</SELECT><input type=text name=Ngnum[] chk=\"true\" fieldname=\"數量\" id=\"Ngnum\" size=\"5\" value=\"\">";
} 
 
function btnDel1_onclick(Itm) 
{
 tbl1.innerHTML ="";
}

function btnAddNew2_onclick() 
{
	var reason1 = new Array("塑膠裂紋","塑膠不飽模","塑膠插傷","塑膠刮傷","塑膠斷裂","塑膠毛邊","塑膠混料","塑膠異物","塑膠燒焦","塑膠縮水","塑膠壓傷","塑膠污髒");
	var	temp2 = "";
	for( var y1 = 0 ; y1<12 ; y1++)
	{
	 temp2 =  temp2 + "<OPTION value="+reason1[y1]+">"+reason1[y1]+"</OPTION>";
	}
		
	tbl2.innerHTML += "<SELECT NAME=reason1[] chk=\"true\" fieldname=\"製程不良說明\"><OPTION value=\"\" selected>請選擇</OPTION>"+temp2+"</SELECT><input type=text name=Ngnum1[] chk=\"true\" fieldname=\"數量\" id=\"Ngnum\" size=\"5\" value=\"\">";
} 
 
function btnDel2_onclick(Itm) 
{
 tbl2.innerHTML ="";
}

function btnAddNew3_onclick() 
{
	var reason2 = new Array("塑膠裂紋","塑膠不飽模","塑膠插傷","塑膠刮傷","塑膠斷裂","塑膠毛邊","塑膠混料","塑膠異物","塑膠燒焦","塑膠縮水","塑膠壓傷","塑膠污髒");
	var	temp3 = "";
	for( var y2 = 0 ; y2<12 ; y2++)
	{
	 temp3 =  temp3 + "<OPTION value="+reason2[y2]+">"+reason2[y2]+"</OPTION>";
	}
		
	tbl3.innerHTML += "<SELECT NAME=reason2[] chk=\"true\" fieldname=\"製程不良說明\"><OPTION value=\"\" selected>請選擇</OPTION>"+temp3+"</SELECT><input type=text name=Ngnum2[] chk=\"true\" fieldname=\"數量\" id=\"Ngnum\" size=\"5\" value=\"\">";
} 
 
function btnDel3_onclick(Itm) 
{
 tbl3.innerHTML ="";
}

function checkFieldValue(f) 
{
    var msg = "欄位未填或未選擇";   

    var msgMin = "欄位至少要選擇 n 項";   

    for (var i=0;i<f.elements.length;i++) {   

        var e = f.elements[i];   

        if ((e.type == "text" || e.type == "select-one" || e.type == "textarea"|| e.type == "file") && (e.getAttribute("chk") == "true")) {   

            if (e.value == "") {   

                alert(e.getAttribute("fieldname") + msg);   

                e.focus();   

                return false;   

            } else if (e.getAttribute("regexp") != undefined) {   

                var re = eval(e.getAttribute("regexp"));   

                if (!re.test(e.value)) {   

                    alert(e.getAttribute("fieldname") + "欄位格式錯誤");   

                    e.focus();   

                    return false;   

                }   

            }    

        } else if ((e.type == "radio" || e.type == "checkbox") && (e.getAttribute("chk") == "true")) {   

            var obj = document.getElementsByName(e.name);   

            if (obj.length) {   

                var count = 0;   

                for (var j=0;j<obj.length;j++) {   

                    if (obj[j].checked) {   

                        count++;   

                    }   

                }   

                if (count == 0) {   

                    alert(obj[0].getAttribute("fieldname") + msg);   

                    obj[0].focus();   

                    return false;   

                } else if ((e.getAttribute("min") != undefined) && count < e.getAttribute("min")) {   

                    alert(e.getAttribute("fieldname") + msgMin.replace(/n/,e.getAttribute("min")));   

                    e.focus();   

                    return false;              

                }   

            } else {   

                if (!obj.checked) {   

                    alert(obj[0].getAttribute("fieldname") + msg);   

                    obj.focus();   

                    return false;   

                }   

            }   

        } else if (e.type == "select-multiple" && e.getAttribute("chk") == "true") {   

            var count = 0;   

            for (var j=0;j<e.options.length;j++) {   

                if (e.options[j].selected) {   

                    count++;   

                }   

            }   

            if (count == 0) {   

                alert(e.getAttribute("fieldname") + msg);   

                e.focus();   

                return false;              

            } else if ((e.getAttribute("min") != undefined) && count < e.getAttribute("min")) {   

                    alert(e.getAttribute("fieldname") + msgMin.replace(/n/,e.getAttribute("min")));   

                    e.focus();   

                    return false;              

            }   

        }      

    }   

    return true;       

}