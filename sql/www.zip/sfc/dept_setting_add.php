<?php
require_once("./auth.php");
if($dept_modify != 1)
{
    echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
    echo "window.alert('您無此操作權限!!')";  
    echo "</SCRIPT>"; 
    exit;
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="./includes/class.css"  rel="stylesheet" type="text/css" />
    <script language="JavaScript">
    function makeSure(theForm)
    {
        if(checkValue())
        {
            theForm.submit();
        }
    }

    function checkValue()
    {
        var dept_code = new Array();
        var dept_name = new Array();
        var count = 0;
        
        for(var i=0; i<5; i++)
        {
            var check_temp = document.getElementById("check"+(i+1)).checked;
            if(check_temp==true)
            {
                var dept_code_tmp = document.getElementById("dept_code"+(i+1)).value.trim();
                var dept_name_tmp = document.getElementById("dept_name"+(i+1)).value.trim();
                
                if(dept_code_tmp=="")
                {
                    alert("請輸入第"+(i+1)+"列部門代碼!");
                    return false;
                }
                if(dept_name_tmp=="")
                {
                    alert("請輸入第"+(i+1)+"列部門名稱!");
                    return false;
                }
                
                dept_code[count] = dept_code_tmp;
                dept_name[count] = dept_name_tmp;
                count++;
            }
        }
        
        if(dept_code.length == 0)
        {
            alert("請先勾選新增!!");
            return false;
        }
        document.myform.dept_code.value = dept_code.toString();
        document.myform.dept_name.value = dept_name.toString();
        return true;
    }
    
    if(typeof String.prototype.trim !== 'function'){
        String.prototype.trim = function() {
            return this.replace(/^\s+|\s+$/g, ''); 
        }
    }
    </script>
</head>
<body>
<form method="post" name="myform" action="dept_setting_add1.php">
<input name="dept_code" type="hidden" value="" />
<input name="dept_name" type="hidden" value="" />
<center>
<p><font size=3><b>新增部門代碼對應</b></font></p>
<table border=1>
<tr><td class="title">新增</td><td class="title">部門代碼</td><td class="title">部門名稱</td></tr>
<tr><td align="center"><input type="checkbox" id="check1" /></td><td><input type="text" id="dept_code1" size="9" maxlength="6" value=""></td><td><input type="text" id="dept_name1" size="20" maxlength="25" value=""></td></tr>
<tr><td align="center"><input type="checkbox" id="check2" /></td><td><input type="text" id="dept_code2" size="9" maxlength="6" value=""></td><td><input type="text" id="dept_name2" size="20" maxlength="25" value=""></td></tr>
<tr><td align="center"><input type="checkbox" id="check3" /></td><td><input type="text" id="dept_code3" size="9" maxlength="6" value=""></td><td><input type="text" id="dept_name3" size="20" maxlength="25" value=""></td></tr>
<tr><td align="center"><input type="checkbox" id="check4" /></td><td><input type="text" id="dept_code4" size="9" maxlength="6" value=""></td><td><input type="text" id="dept_name4" size="20" maxlength="25" value=""></td></tr>
<tr><td align="center"><input type="checkbox" id="check5" /></td><td><input type="text" id="dept_code5" size="9" maxlength="6" value=""></td><td><input type="text" id="dept_name5" size="20" maxlength="25" value=""></td></tr>
</table><br />
<input type="button" class="groovybutton" value="確定" onclick="makeSure(this.form)" />&nbsp;&nbsp;<input type="button" class="groovybutton" value="回上一頁" onClick="javascript:history.back(1)" />
</center>
<p id="demo"></p>
</form>
</body>
</html>