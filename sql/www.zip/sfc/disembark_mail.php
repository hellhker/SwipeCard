﻿
<?php
    $user=$_POST['username'];
    $psw=$_POST['password'];
    $user1=$_GET['user'];
    $psw1=$_GET['password'];
    $hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
    
    $mysqli = new mysqli($hostname,$username,$password,$database_name);
	$mysqli->query('SET NAMES utf8');	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 

require '../PHPMailer/PHPMailerAutoload.php';
    //header("content-type:text/html;charset=utf8");
$email = new PHPMailer();
$email->From      = 'test_long@foxlink.com.tw';

$email->FromName  = '製造即時系統';
$table.= "";
$table.="<div >";
$table.="<p>【部門代碼更新通知】為維護您使用製造即時系統的權益及相應功能，請於12/8前完成部門代碼更新，逾時將移除使用權限，謝謝配合</p><br />";
$table.="<p>影響的系統權限包含: <p/>";
$table.="<td>1.CABG製造即時系統 ( 連接器 )<td/><br/>";
$table.="<td>2.CABG製造即時系統 ( 電線 ) <td/><br/>";
$table.="<td>3.CABG E-Learning <td/><br/>";

$table.="<p>請點擊以下連結進行部門代碼更新程序<p/>";
$table.="<p>(以下連結只允許於公司內部網路存取，Notes若無法開啟，請使用 Internet Explorer 或 Google Chrome 瀏覽器)<p/>";
$table.="<a href='http://scbg-iot.foxlink.com.tw/sfc/disembark.php'>http://scbg-iot.foxlink.com.tw/sfc/disembark.php</a>";
$table.="<p>備註:以上郵件為系統自動發信，請勿回信。 <p/>";
$table.="<td>Contact Us<td/><br/>";
$table.="<td>數據資源部<td/><br/>";
$table.="<td>系統整合課<td/><br/>";
$table.="<td>姓名:黃祥鋒<td/><br/>";
$table.="<td>分機:33461<td/><br/>";
$table.="<td>E-mail: Huang_Xf@foxlink.com<td/><br/>";
$table.="</div>";
$email->Subject   = '【部門代碼更新通知】為維護您使用製造即時系統的權益及相應功能，請於12/8前完成部門代碼更新，逾時將移除使用權限，謝謝配合';
$message = "$table";

$email->Body  = $message;
$sql = "SELECT `EMail` FROM `user_data` WHERE `EMail`is not null ";
$email_data=$mysqli->query($sql);
$email_arr=$email_data->fetch_row();
while( $email_arr=$email_data->fetch_row() ) {
    foreach($email_arr as $value){
     $email->AddAddress("$value");
     //echo $value."<br/>";
    }
}

$email->AddAddress("Huang_Xf@foxlink.com.tw");
//$email->AddAddress("Denil_Chuang@foxlink.com.tw");
$email->AddAddress("mika_huang@foxlink.com.tw");
$email->AddAttachment("../SFC/uploads/113.pptx","製造即時系統-操作SOP.pptx");
$email->CharSet="UTF-8";
$email->ContentType="text/html";
$email->Send();

echo "Official Report發送郵件成功!";    
    




?>