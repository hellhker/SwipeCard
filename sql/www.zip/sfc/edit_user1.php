﻿<?php
require_once("mysql_scbg.php");
@require_once("includes/xajax_core/xajax.inc.php");
//建立物件
$xajax = new xajax(); 
//$xajax->setFlag("debug",true);
//註刪回應函數
$xajax->registerFunction("checkDepcode");
//處理非同步要求
$xajax->processRequest();
$xajax->configure( 'defaultMode', 'synchronous' );//設成同步


function checkDepcode($depcode)
{
    $objResponse = new xajaxResponse();    
    global $mysqli,$MYSQL_LOGIN,$MYSQL_PASSWORD,$MYSQL_HOST;
    connect_db("test");
    
    $sql = "select Depart_Code from group_structure where `Depart_Code`='".$depcode."'";
    $rows = $mysqli->query($sql);
    $num_row = $rows->num_rows;
    mysqli_free_result($rows);
    $mysqli->close();
    
    if($num_row == 0)
    {    
        $objResponse->alert("部門代碼有誤，請重新填寫!!");
        $objResponse->setReturnValue(false);
    }
    else
    {
        $objResponse->setReturnValue(true);
    }
    return $objResponse;
}
?>

<HTML>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?
$xajax->printJavascript("includes"); //輸出用戶
?>
</head>
<BODY bgcolor="#FFFFFF" BACKGROUND="lbg.jpg" >
<script>
function check()  //.......................檢查輸入的空格是否有資料
{  
  var depcode = document.main.dep_code.value;
  if (document.main.dep_code.value.length < 4) {
    window.alert("請輸入部門代碼");
    return false;
  } 
  if (isNaN(document.main.dep_code.value)) {
    window.alert("部門代碼必須是數字!");
    return false;
  } 
  if (document.main.chinese_name.value.length < 1) {
    window.alert("請輸入中文姓名");
    return false;
  } 
  
  return xajax_checkDepcode(depcode);
}
</script>
<CENTER>
<h3>編輯個人資料</h3>
<CENTER><font color=red>紅色欄位可修改。（Red Fields are modified.）</font></CENTER>
<p>
<form method=post name=main action=edit_user2.php onSubmit="return check()">
<?
	$hostname = "192.168.64.233";  		
	$username ="root";
	$password ="foxlink";
	$database_name = "sfc";
	$mysqli = new mysqli($hostname,$username,$password,$database_name);
	$counter = 1;
	$mysqli->query("SET NAMES 'utf8'");	 
	$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
	$mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
	
	$uid = $_POST['Usname'];
	$pwd = $_POST['pwd'];
	
	$sql = "select * from user_data where `UserID`='".$uid."' and `Password`='".$pwd."'";
  $rows = $mysqli->query($sql);
  $row= $rows->fetch_row();   
	//echo $sql;

	if(strcmp($row[7],"201")==0)
	{	
		$select1 = "Selected";
		$select2 = "";
	}
	else if(strcmp($row[7],"202")==0)
	{	
		$select1 = "";
		$select2 = "Selected";
	}
	else
	{
		$select1 = "";
		$select2 = "";
	}
	
	if(strcmp($row[9],"201")==0)
	{	
		$select3 = "Selected";
		$select4 = "";
	}
	else if(strcmp($row[9],"202")==0)
	{	
		$select3 = "";
		$select4 = "Selected";
	}
	else
	{
		$select3 = "";
		$select4 = "";
	}	
?>
<table border=2  width='45%' >
<td colspan=2>編輯個人資料
<tr>          
    <td><font color=black>使用者帳號:</font></td>  
    <td><INPUT Type="Text"  Name="usname"  Size="10" value="<?php echo $uid;?>" readonly></td>     
</tr>
<tr>          
    <td><font color=red>密碼:</font></td> 
<td><INPUT Type="Text"  Name="pwd"  Size="10" value="<?php echo $pwd;?>"></td> 
</tr>
<tr>          
    <td><font color=red>中文姓名:</font></td> 
<td><INPUT Type="Text"  Name="chinese_name"  Size="10" value="<?php echo $row[3];?>"></td>   
</tr> 
<tr>          
    <td><font color=black>信箱:</font></td> 
<td><INPUT Type="Text"  Name="email"  Size="10" value="<?php echo $row[4];?>" readonly></td>   
</tr>  
<tr>          
    <td><font color=red>部門代碼:</font></td> 
<td><INPUT Type="Text"  Name="dep_code"  Size="10" value="<?php echo $row[5];?>"></td>   
</tr>  
<tr>          
    <td><font color=red>大陸手機號碼:</font></td> 
<td><INPUT Type="Text"  Name="china_phone"  Size="10" value="<?php echo $row[6];?>"></td>   
</tr>
<!-- 
<tr>          
    <td><font color=red>手機系統:</font></td> 
		<td>
			<Select Name="phone_system">			
				<OPTION value="">請選擇</OPTION><OPTION value="201" <?php echo $select1;?>>IOS</OPTION><OPTION value="202" <?php echo $select2;?>>Android</OPTION>
			</SELECT>
		</td>   
</tr>  
<tr>          
    <td><font color=red>手機裝置序號:</font></td> 
<td><INPUT Type="Text"  Name="phone_sn"  Size="10" value="<?php echo $row[8];?>"></td>   
</tr> 
<tr>          
    <td><font color=red>平板系統:</font></td> 
<td><Select Name="pad_system"><OPTION value="">請選擇</OPTION><OPTION value="201" <?php echo $select3;?>>IOS</OPTION><OPTION value="202" <?php echo $select4;?>>Android</OPTION></SELECT></td>   
</tr>  
<tr>          
    <td><font color=red>平板裝置序號:</font></td> 
<td><INPUT Type="Text"  Name="pad_sn"  Size="10" value="<?php echo $row[10];?>"></td>   
</tr>
-->
<td colspan=2><CENTER><INPUT Type=Submit Name=Send Value="送出">
<input Type=Reset  Value="重寫 ">
<input Type=hidden name=old_depcode  value="<?php echo $row[5];?>">
</CENTER></td>   
</table>
<?
	
  $mysqli->close();
?>
</form>
</BODY>
</HTML> 
