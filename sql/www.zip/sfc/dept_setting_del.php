<?php
require_once("./auth.php");
if($dept_modify != 1)
{
    echo "<SCRIPT Language=javascript type=\"text/javascript\">"; 
    echo "window.alert('您無此操作權限!!')";  
    echo "</SCRIPT>"; 
    exit;
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form>
<?php
$dept_code  = $_GET['code'];

$mysqli = new mysqli($MYSQL_HOST,$MYSQL_LOGIN,$MYSQL_PASSWORD,"sfc");
$mysqli->query("SET NAMES 'utf8'");	 
$mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
$mysqli->query('SET CHARACTER_SET_RESULTS=utf8');

$sql = "delete from department_table where `department_code`='".$dept_code."'";
$mysqli->query($sql);
$mysqli->close();
?>
<center><h2>該筆資料已刪除完畢!!</h2>
<p align="center"><input type="button" VALUE="關閉視窗" onClick="javascript:window.opener.location.reload(true);self.close();"></p>
</center>
</form>
</body>
</html>