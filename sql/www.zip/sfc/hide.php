<html>
<head>
<style>
img{
   cursor: pointer;  
}
</style>
<script>
function change_frame()
{
    var attr = parent.document.getElementById("frameset").getAttribute("cols");
    if(attr.split(",")[0]=="195")
    {
        parent.document.getElementById("frameset").setAttribute("cols","0,20,*");
        document.getElementById("hide_img").src = "img/forward.png";
    }
    else
    {
        parent.document.getElementById("frameset").setAttribute("cols","195,20,*");
        document.getElementById("hide_img").src = "img/backward.png";
    }
}
</script>
</head>
<body>
<img id="hide_img" width="100%" height="30" margin="0" border="0" src="img/backward.png" onclick="change_frame();">
</body>
</html>