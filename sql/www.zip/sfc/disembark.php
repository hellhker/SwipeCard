<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="./includes/class.css"  rel="stylesheet" type="text/css" />
</style>
<script type="text/javascript">
    function check (form)
    {
        var reg = /^\s*|\s*$/g;
        if (form.username.value.replace(reg,'') == "")
        {
            alert ("请输入用户名");
            form.username.focus ();
            return false;
        }
        else if (form.password.value.replace(reg,'') == "")
        {
            alert ("请输入密码");
            form.password.focus ();
            return false;
        }
        else 
        {
            return true;
        }
    }
    function show_window()
    {
    	var newtab = window.open("http://192.168.64.233/sfc/forget_pass.php", 'SFC',config='height=200px,width=430px,scrollbars=no,resizable=no,status=no');
    	newtab.focus(); 
    }
    function show_window1()
    {
    	var newtab = window.open("http://192.168.64.233/sfc/register.php", 'SFC',config='height=500px,width=500px,scrollbars=no,resizable=yes,status=no');
    	newtab.focus(); 
    }
</script>
<style>

#login_click{ margin-top:32px; height:40px;}
#login_click a 
{
    

    text-decoration:none;
	background:#2f435e;
	color:#f2f2f2;
	
	padding: 10px 30px 10px 30px;
	font-size:16px;
	font-family: 微软雅黑,宋体,Arial,Helvetica,Verdana,sans-serif;
	font-weight:bold;
	border-radius:3px;
	
	-webkit-transition:all linear 0.30s;
	-moz-transition:all linear 0.30s;
	transition:all linear 0.30s;
	
	}
   #login_click a:hover { background:#c7a061; }

</style>
</head>
<body>
    <div class="page-container">
    <center>
        <form name="form1" id="form1" action="disembark_updata.php" method="post">
        <p><font color="red" size="10" face="新細明體"><b>請先登入系統</b></font></p>
           <td>用戶名:<input type="text" name="username" id="username" class="username" placeholder=""> </td><br /><br />
           <td>密&nbsp碼:<input type="password" name="password" id="password" class="password" placeholder=""> </td><br /><br />
            <button type="submit" class="submit_button" onclick="return check(this.form);">登录</button>
            <div class="error">
            </div><br />
            <a onclick="show_window()" style="color:blue;font-size: 10pt;text-decoration: underline;cursor: pointer;">忘記密碼？</a><br />
        </form>
    </<center>
    <center>
     <div id="login_click"><br /><br /><br />
            <a id="btlogin" href="http://scbg-iot.foxlink.com.tw/WELCOME.PHP#" id="login_click"  target="_blank">Welcome to CABG  IoT-Platform</a>
    </div>
    </<center>
    </div>
</body>
</html>