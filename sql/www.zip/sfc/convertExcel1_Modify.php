﻿<HTML>
<?php
 $form_filename = "report.xls";
 
 header("Content-Type: application/octetstream; name=$form_filename; charset=UTF-8");
 header("Content-Disposition: attachment; filename=$form_filename;"); 
 header("Content-Transfer-Encoding: binary");
 header("Cache-Control: cache, must-revalidate");
 header("Pragma: public");
 header("Pragma: no-cache");
 header("Expires: 0");
 echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; CHARSET=UTF-8\">";
 
 $hostname = "10.8.90.26";  		
 $username ="root";
 $password ="foxlink";
 $database_name = "test";
 $mysqli = new mysqli($hostname,$username,$password,$database_name);
 $counter = 1;
 $mysqli->query("SET NAMES 'utf8'");	 
 $mysqli->query('SET CHARACTER_SET_CLIENT=utf8');
 $mysqli->query('SET CHARACTER_SET_RESULTS=utf8'); 
 
 $PLine1 = $_POST['PLine1'];
 $PDLine1 = $_POST['PDLine1'];
 $pnumber = $_POST['pnumber'];
 $pjcode = $_POST['pjcode'];
 $start_testdate = $_POST['start_testdate'];
 $end_testdate = $_POST['end_testdate'];
 $classname = $_POST['classname'];
 $finishratioup = $_POST['finishratioup'];
 $finishratiolow = $_POST['finishratiolow'];
 $ngratioup = $_POST['ngratioup'];
 $ngratiolow = $_POST['ngratiolow'];
 
 
 $counter = 1 ;
 $cstr = "";
 //echo $PLine1;
 if(!empty($PLine1))
  {
   if($counter)
   		$cstr=$cstr." and `department_name`='$PLine1' ";
   else
   		$cstr="where `department_name`='$PLine1' ";
   $counter++;
  } 
  if(!empty($PDLine1))
  {
   if($counter)
   		$cstr=$cstr." and `prod_line_code`='$PDLine1' ";
   else
   		$cstr="where `prod_line_code`='$PDLine1' ";
   $counter++;
  } 
  
  if(!empty($pjcode))
  {
   if($counter)
   		$cstr=$cstr." and `project_code` like '$pjcode%' ";
   else
   		$cstr="where `project_code` like '$pjcode%' ";
   $counter++;
  }
  if(!empty($pnumber))
  {
   if($counter)
   		$cstr=$cstr." and `item_no` like '$pnumber%' ";
   else
   		$cstr="where `item_no` like '$pnumber%' ";
   $counter++;
  }
  $finishratio_up_check =false;
  $finishratio_low_check =false;
  $ngratio_up_check =false;
  $ngratio_low_check =false;
  if(!empty($finishratioup))
	{
	   $finishratio_up_check =true;
	}
	if(!empty($finishratiolow))
	{
	   $finishratio_low_check =true;
	}
	if(!empty($ngratioup))
	{
		 $ngratio_up_check =true;
	}
	if(!empty($ngratiolow))
	{
	   $ngratio_low_check =true;
  }
  
  function check_default($finishratio_up_check,$finishratio_low_check,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$itemvalue,$itemvalue1)
  {
  		if($finishratio_up_check)
			{														
					if(is_numeric($itemvalue))
					{															
							if(($itemvalue-$finishratioup)>0)
									return false;
					}
					else
						return false;
			}
			if($finishratio_low_check)
			{
					if(is_numeric($itemvalue))
					{
							if(($itemvalue-$finishratiolow)<0)
							 	 return false;
					}
					else
						return false;
			}												
			if($ngratio_up_check)
			{
					if(is_numeric($itemvalue1))
					{
							if(($itemvalue1-$ngratioup)>0)
							 	 return false;
					}
					else
						return false;
			}	
			if($ngratio_low_check)
			{
			  	if(is_numeric($itemvalue1))
					{
							if(($itemvalue1-$ngratiolow)<0)
							 	 return false;
					}
					else
						return false;
			}						
			return true;							
  }  
 
 
$sql_date = "Select creation_date from fl_bi_wip_move_qty where department_name like '組裝生產%' ORDER BY `prod_date` DESC,`prod_line_code` ASC,`rc_no` DESC,`operation_seq_num` DESC";
$date_rows = $mysqli->query($sql_date);
$date_row = $date_rows->fetch_row();
$createdate = $date_row[0];
   
$sql = "Select * from fl_bi_wip_move_qty where 1=1 and department_name like '組裝生產%' $cstr ORDER BY `prod_date` DESC,`prod_line_code` ASC,`rc_no` DESC,`operation_seq_num` DESC";
$rows = $mysqli->query($sql);
	//echo $sql."<BR>";
$num = $rows->num_rows;
	//14個顯示欄位
$itemnumber = 14;
$sortarray = array();
$finalarray = array();
$final_count = 0;
$sort_count = 0;
$itemcount = 0;
$lastfpy = 0;	
 //echo $sql;
 while( $row = $rows->fetch_row() ) 
 {          
	  $pdate = $row[5];
	  $pline = $row[8];
	  $workno = $row[10];
	  $rc_no = $row[11];
	  $seq_no = $row[12];
		$pcode = $row[13];
		$pno = $row[14];
		$prodqty = $row[16];
		$prod_totalqty = $row[17];
		$goodqty = $row[18];
		$ngqty = $row[19];
		$workhours = $row[15];
		$maxline = $row[26];
		if($prod_totalqty>0)
			$finishrate = round(($goodqty/$prod_totalqty)*100,2);
		else
			$finishrate = "---";	
						
		if($itemcount>0)
		{
				if(strcmp($workno,$sortarray[$sort_count][2])==0)
				{
						if(strcmp($sortarray[$sort_count][1],$pline)==0)
						{
								$sortarray[$sort_count][12] = $sortarray[$sort_count][12] + $ngqty;
								if(($goodqty+$ngqty)>0)
									$lastfpy = $lastfpy*($goodqty/($goodqty+$ngqty));
								else
									$lastfpy = "---";		
						}
						else
						{
								if(($sortarray[$sort_count][12]+$sortarray[$sort_count][9])>0)	
									$failedrate = round(($sortarray[$sort_count][12]/($sortarray[$sort_count][12]+$sortarray[$sort_count][9])*100),2);
								else
									$failedrate ="---";
								$sortarray[$sort_count][13] = $failedrate;
								if($lastfpy>0)
									$sortarray[$sort_count][14] = round($lastfpy*100,2);
								else
									$sortarray[$sort_count][14] = "---";	
								$sortarray[$sort_count][15] = $lastmaxline;
								if(check_default($finishratio_up_check,$finishratiolow,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$sortarray[$sort_count][11],$sortarray[$sort_count][13]))
								{	
									$count = 0;
									foreach( $sortarray[$sort_count] as $key => $value)
									{											
											$finalarray[$final_count][$count++] = $value;															
									}
									$final_count++;
									$sort_count++;
								}
								$sortarray[$sort_count][0] = $pdate;
								$sortarray[$sort_count][1] = $pline;
								$sortarray[$sort_count][2] = $workno;
								$sortarray[$sort_count][3] = $seq_no;
								$sortarray[$sort_count][4] = $pcode;
								$sortarray[$sort_count][5] = $pno;
								$sortarray[$sort_count][6] = $workhours;
								$sortarray[$sort_count][7] = $prodqty;
								$sortarray[$sort_count][8] = $prod_totalqty;
								$sortarray[$sort_count][9] = $goodqty;
								$sortarray[$sort_count][10] = $prod_totalqty-$goodqty;
								$sortarray[$sort_count][11] = $finishrate;					
								$sortarray[$sort_count][12] = $ngqty;
								$lastmaxline = $maxline;		
								if(($goodqty+$ngqty)>0)
									$lastfpy = $goodqty/($goodqty+$ngqty);
								else
									$lastfpy = "---";												
						}
				}
				else
				{
						if(($sortarray[$sort_count][12]+$sortarray[$sort_count][9])>0)	
							$failedrate = round(($sortarray[$sort_count][12]/($sortarray[$sort_count][12]+$sortarray[$sort_count][9])*100),2);
						else
							$failedrate ="---";
						$sortarray[$sort_count][13] = $failedrate;
						if($lastfpy>0)
							$sortarray[$sort_count][14] = round($lastfpy*100,2);
						else
							$sortarray[$sort_count][14] = "---";	
						$sortarray[$sort_count][15] = $lastmaxline;
						if(check_default($finishratio_up_check,$finishratiolow,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$sortarray[$sort_count][11],$sortarray[$sort_count][13]))
						{	
							$count = 0;
							foreach( $sortarray[$sort_count] as $key => $value)
							{											
									$finalarray[$final_count][$count++] = $value;															
							}
							$final_count++;
							$sort_count++;
						}									
						$sortarray[$sort_count][0] = $pdate;
						$sortarray[$sort_count][1] = $pline;
						$sortarray[$sort_count][2] = $workno;
						$sortarray[$sort_count][3] = $seq_no;
						$sortarray[$sort_count][4] = $pcode;
						$sortarray[$sort_count][5] = $pno;
						$sortarray[$sort_count][6] = $workhours;
						$sortarray[$sort_count][7] = $prodqty;
						$sortarray[$sort_count][8] = $prod_totalqty;
						$sortarray[$sort_count][9] = $goodqty;
						$sortarray[$sort_count][10] = $prod_totalqty-$goodqty;
						$sortarray[$sort_count][11] = $finishrate;					
						$sortarray[$sort_count][12] = $ngqty;				
						$lastmaxline = $maxline;
						if(($goodqty+$ngqty)>0)
							$lastfpy = $goodqty/($goodqty+$ngqty);
						else
							$lastfpy = "---";		
				}										
		}
		else
		{
			//固定的
			$sortarray[$sort_count][0] = $pdate;
			$sortarray[$sort_count][1] = $pline;
			$sortarray[$sort_count][2] = $workno;
			$sortarray[$sort_count][3] = $seq_no;
			$sortarray[$sort_count][4] = $pcode;
			$sortarray[$sort_count][5] = $pno;
			$sortarray[$sort_count][6] = $workhours;
			$sortarray[$sort_count][7] = $prodqty;
			$sortarray[$sort_count][8] = $prod_totalqty;
			$sortarray[$sort_count][9] = $goodqty;
			$sortarray[$sort_count][10] = $prod_totalqty-$goodqty;
			$sortarray[$sort_count][11] = $finishrate;					
			$sortarray[$sort_count][12] = $ngqty;
			$lastmaxline = $maxline;
			if(($goodqty+$ngqty)>0)
				$lastfpy = $goodqty/($goodqty+$ngqty);
			else
				$lastfpy = "---";		
		}	
		$itemcount++;
	}
  //最後一筆的不良率
	if(($sortarray[$sort_count][12]+$sortarray[$sort_count][9])>0)	
		$failedrate = round(($sortarray[$sort_count][12]/($sortarray[$sort_count][12]+$sortarray[$sort_count][9])*100),2);
	else
		$failedrate ="---";
	$sortarray[$sort_count][13] = $failedrate;if(($sortarray[$sort_count][12]+$sortarray[$sort_count][9])>0)	
	$failedrate = round(($sortarray[$sort_count][12]/($sortarray[$sort_count][12]+$sortarray[$sort_count][9])*100),2);
	$sortarray[$sort_count][13] = $failedrate; 
	if($lastfpy>0)
			$sortarray[$sort_count][14] = round($lastfpy*100,2);
	else
			$sortarray[$sort_count][14] = "---";	
	$sortarray[$sort_count][15] = $lastmaxline;
	if(check_default($finishratio_up_check,$finishratiolow,$ngratio_up_check,$ngratio_low_check,$finishratioup,$finishratiolow,$ngratioup,$ngratiolow,$sortarray[$sort_count][11],$sortarray[$sort_count][13]))
	{	
		$count = 0;
		foreach( $sortarray[$sort_count] as $key => $value)
		{	
			$finalarray[$final_count][$count++] = $value;															
		}
	  $final_count++;
		$sort_count++;
	}	       	 		
	function compare_ship($a, $b)
  {
    return ($a[13] > $b[13]) ? -1 : 1;
  } 
  usort($finalarray, "compare_ship");
	
  echo "<table border=1>";
 	echo "<tr><td align=center colspan=8><B>資料來源時間:</B><font color=blue>".$createdate."</font></td><td align=center colspan=8><B>截止至今</B></td></tr>";
 	echo "<tr><th bgcolor='#FFFFCC'><font size=2>生產日期</font><th bgcolor='#FFFFCC'><font size=2>主生產線</font><th bgcolor='#FFFFCC'><font size=2>工單號碼</font><th bgcolor='#FFFFCC'><font size=2>最後工序</font><th bgcolor='#FFFFCC'><font size=2>機種品名</font><th bgcolor='#FFFFCC'><font size=2>料號</font><th bgcolor='#FFFFCC'><font size=2>投入工時</font><th bgcolor='#FFFFCC'><font size=2>指示單數量</font><th bgcolor='#FFFFCC'><font size=2>累計排配量</font><th bgcolor='#FFFFCC'><font size=2>累計良品數</font><th bgcolor='#FFFFCC'><font size=2>差異數</font><th bgcolor='#FFFFCC'><font size=2>達成率</font><th bgcolor='#FFFFCC'><font size=2>累計不良品數</font><th bgcolor='#FFFFCC'><font size=2 color=red>不良率</font><th bgcolor='#FFFFCC'><font size=2>直通率</font><th bgcolor='#FFFFCC'><font size=2>總開線數</font></tr>";
	foreach( $finalarray as $key => $data)
	{
	 	echo "<tr>";
	 	foreach( $data as $key1 => $value)
		{
			if($key1==11)
			{			
				if($value<95)
					$color = "red";
				else
					$color = "black";	
				echo "<td align=right><font size=2 color=$color>".$value."%</font></td>";
			}
			else if($key1==13)
			{
					if($value>5)
						$color = "red";
					else
						$color = "black";	
					echo "<td align=right><font size=2 color=$color>".$value."%</font></td>";	
			}
			else if($key1==14)
			{
					echo "<td align=right><font size=2>".$value."%</font></td>";
			}
			else	
				echo "<td align=right><font size=2>".$value."</font></td>";
		}
		echo "</tr>";
	}		
	echo "</TABLE>";       
    $mysqli->close(); 
?>
</HTML>
