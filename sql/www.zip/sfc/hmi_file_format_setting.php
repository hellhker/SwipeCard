<?php
$project = $_GET["project"];
$device = $_GET["device"];

if($project!="" && $device!="")
    $page="hmi_file_format_setting.php?project=".$project."&device=".$device;
else
    $page="hmi_file_format_setting.php";
require_once("auth2.php");
require_once("mysql_connect.php");
@require_once("includes/xajax_core/xajax.inc.php");
//建立物件
$xajax = new xajax();
$xajax->configure( 'javascript URI', './includes' );
$xajax->configure( 'debug', false);
$xajax->configure( 'errorHandler', true );
$xajax->configure( 'logFile', 'xajax_error_log.log' ); 
//$xajax->setFlag("debug",true);
//註刪回應函數
$xajax->register(XAJAX_FUNCTION,"getFormat");
//$xajax->registerFunction("basicDataFormat");
$xajax->register(XAJAX_FUNCTION,"extendDataFormat");
$xajax->register(XAJAX_FUNCTION,"showFileContent");
$xajax->register(XAJAX_FUNCTION,"clearFileContent");
$xajax->register(XAJAX_FUNCTION,"save");
//處理非同步要求
$xajax->processRequest();

function getFormat($check,$project,$device)
{
    $objResponse = new xajaxResponse();
    
    if($check)
    {
        global $groupname;
        $mydb = new DataBase();
        $mydb->connect_fq("sfc");

        $sql="SELECT * FROM `device_setting` where project='".$project."' and Device_Name='".$device."'";
        $mydb->query($sql);
        $row = $mydb->result->fetch_array(MYSQLI_BOTH);
        $factory = $row["FAC_CODE"];
        $rows_count = $mydb->result->num_rows;
        $mydb->result->free_result();
        $mydb->disconnect();
        
        if($rows_count > 0)
        {
            $sub_sql = "";
            
            if($factory=="FQ")
                $mydb->connect_fq("hmi");
            else
                $mydb->connect_ks("hmi");
            
            $basic_num = 0;
            $sql="SELECT * FROM `measure_info` where project='".$project."' and Measure_Workno='".$device."'";
            $mydb->query($sql);
            
            if($mydb->result->num_rows == 0)
            {
                $mode = 1;
                $objResponse->confirmCommands(5,"此專案及設備名稱未設定過檔案格式，是否要進行設定?");
                $cch = basicDataFormat($factory,$basic_num);
                $objResponse->assign('basic_span','innerHTML',$cch);
                
                $cch = "<span style=\"border: gray;\"><b>進階格式設定表</b></span><br>";
                $cch .= "<table id=\"extend_table\" border=1>";
                $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\" width=150>名稱</td></tr>";
                $cch .= "</table>";
                $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row1(".$basic_num.");\">&nbsp;&nbsp;";
                $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1();\"><br><br>";
                $objResponse->assign('extend_span','innerHTML',$cch);
                
                //$cch = "<input type=\"button\" id=\"down_btn\" value=\"\" onclick=\"showContent('".$project."');\"/>模擬TXT檔案內容<br><br>";
                //$objResponse->assign('demo_span','innerHTML',$cch);
            }
            else
            {
                $mode = 2;
                $cch = basicDataFormat($factory,$basic_num);
                $objResponse->assign('basic_span','innerHTML',$cch);
                $objResponse->call('xajax_extendDataFormat', $project, $device, $basic_num, $factory);
                //$objResponse->assign('demo_span','innerHTML',"");
            }
            $mydb->result->free_result();
            
            if($groupname!="Adm" && $mode==2)
            {
                $cch = "<input type=\"button\" class=\"groovybutton\" value=\"儲存修改\" onclick=\"checkSure('".$mode."','".$project."','".$device."','".$factory."');\" disabled>";
                $objResponse->alert("若需變更檔案格式設定，請洽系統管理員進行修改!!");
            }
            else
                $cch = "<input type=\"button\" class=\"groovybutton\" value=\"儲存修改\" onclick=\"checkSure('".$mode."','".$project."','".$device."','".$factory."');\">";
                
            $objResponse->assign('save_span','innerHTML',$cch);
            $objResponse->assign('format_border', 'style.display', '');
            $objResponse->assign('result_span', 'style.display', '');
            $mydb->disconnect();
        }
        else
        {
            $objResponse->alert("此專案未進行過設備連線設定，請先至即時系統『車間資訊』=>『連線設定』進行設置!!");
            $objResponse->assign('result_span', 'style.display', 'none');
        }
    }
    $objResponse->assign('preloader', 'style.display', 'none');
    return $objResponse;
}

function basicDataFormat($factory,&$basic_num)
{
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("hmi");
    else
        $mydb->connect_ks("hmi");
    
    $sql="SELECT Code,Code_Desc FROM `data_basic_format` order by Code";
    $mydb->query($sql);
    $basic_num = $mydb->result->num_rows;
    
    $cch = "<span style=\"border: gray;\"><b>基本格式設定表</b></span>";
    $cch .= "<table id=\"basic_table\" border=1>";
    $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\">名稱</td></tr>";

    if($mydb->result->num_rows > 0)
    {
        while($row = $mydb->result->fetch_row())
        {
            $cch .= "<tr><td>".$row[0]."</td><td><input size=\"20\" value=\"".$row[1]."\" disabled /></td></tr>";
        }
    }
    $cch .= "</table>";
    $mydb->result->free_result();
    $mydb->disconnect();
    return $cch;
}

function extendDataFormat($project, $device, $basic_num, $factory)
{
    $objResponse = new xajaxResponse();
    global $groupname;
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("hmi");
    else
        $mydb->connect_ks("hmi");
        
    $sql="SELECT Code,Code_Desc FROM `data_extend_format` where project='".$project."' and Measure_Workno='".$device."' order by Code";
    $mydb->query($sql);
    
    $cch = "<span style=\"border: gray;\"><b>進階格式設定表</b></span><br>";
    $cch .= "<table id=\"extend_table\" border=1>";
    $cch .= "<tr><td class=\"title\">代碼</td><td class=\"title\">名稱</td></tr>";
    
    while($row = $mydb->result->fetch_row())
    {
        if($groupname!="Adm" && $groupname!="系統管理者")
            $cch .= "<tr><td><input size=\"2\" value=\"".$row[0]."\" disabled /></td><td><input size=\"20\" value=\"".$row[1]."\" disabled /></td></tr>";
        else
            $cch .= "<tr><td><input size=\"2\" value=\"".$row[0]."\" /></td><td><input size=\"20\" value=\"".$row[1]."\" /></td></tr>";
    }
    $mydb->result->free_result();
    $mydb->disconnect();
    $cch .= "</table>";
        
    if($groupname!="Adm" && $groupname!="系統管理者")
    {
        $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row1(".$basic_num.");\" disabled>&nbsp;&nbsp;";
        $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1();\" disabled><br><br>";
    }
    else
    {
        $cch .= "<input type=\"button\" value=\"新增檢測項目\" onclick=\"insert_row1(".$basic_num.");\">&nbsp;&nbsp;";
        $cch .= "<input type=\"button\" value=\"刪除最末列\" onclick=\"delete_last1();\"><br><br>";
    }
    $objResponse->assign('extend_span','innerHTML',$cch);
    return $objResponse;
}
/*
function showFileContent($project,$basic_formats,$extend_formats)
{
    $objResponse = new xajaxResponse();
    $cch = "";
    
    for($j=0; $j<count($extend_formats); $j++)
    {
        if($extend_formats[$j][0] != $tmp_workno) //是新的檢測工站
        {
            if($j != 0)
                $cch .= "<br>";
            //產生一筆新資料    
            $cch .= $extend_formats[$j][0]."&emsp;".($i+1)."&emsp;".$basic_formats[1][0]."&emsp;2016-01-01&emsp;22:46:02&emsp;".$basic_formats[4][0]."&emsp;".$basic_formats[5][0]."&emsp;1&emsp;1.479";
        }
        else //相同檢測工站
        {
            //往後延伸該筆資料長度
            $cch .= "&emsp;1&emsp;1.479";
        }
        $tmp_workno = $extend_formats[$j][0];
    }
    $cch .= "<br>";
    $cch .= "<br><input type=\"button\" id=\"up_btn\" value=\"\" onclick=\"xajax_clearFileContent('".$mode."','".$project."');\"/>隱藏模擬內容<br><br>";
    
    $objResponse->assign('demo_span','innerHTML',$cch);
    return $objResponse;
}

function clearFileContent($mode,$project)
{
    $objResponse = new xajaxResponse();
    $cch = "<input type=\"button\" id=\"down_btn\" value=\"\" onclick=\"showContent('".$mode."','".$project."');\"/>模擬TXT檔案內容<br><br>";
    $objResponse->assign('demo_span','innerHTML',$cch);
    return $objResponse;
}
*/
function save($mode,$project,$device,$extend_formats,$factory)
{
    $objResponse = new xajaxResponse();
    $mydb = new DataBase();
    
    if($factory=="FQ")
        $mydb->connect_fq("hmi");
    else
        $mydb->connect_ks("hmi");
        
    $sql = "replace INTO `measure_info`(`Project`,`Measure_Workno`,`Workno_Order`) VALUES('".$project."','".$device."',1)";
    $mydb->execute($sql);
    
    $sql = "delete from `data_extend_format` where project='".$project."' and Measure_Workno='".$device."'";
    $mydb->execute($sql);
    
    //先刪除data及data_new表
    $drop_sql = "drop table if exists `".$project."_".$device."_data`";
    $mydb->execute($drop_sql);
    $mydb->execute(str_replace("_data","_data_new",$drop_sql));
    
    //為新的檢測工站建立暫存的SQL指令，暫不實際執行
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_".$device."_data` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`Line` VARCHAR(2) NOT NULL,"
                ."`Code1` DATE NOT NULL, `Code2` VARCHAR(8) NOT NULL, `Code3` VARCHAR(3) NOT NULL, `Code4` VARCHAR(14) NOT NULL,"
                ."`Code5` VARCHAR(10), `Code6` DECIMAL(7,3) default 0.000, `Code7` INT(2) NOT NULL, `Code8` DECIMAL(4,3) default 0.000, `Code9` DECIMAL(4,3) default 0.000,"
                ."`Code10` VARCHAR(1), `Code11` INT(2) NOT NULL, `Code12` INT(5) ";
                        
    // 儲存進階格式設定表 & 建立data表
    for($i=0; $i<count($extend_formats); $i++)
    {
        // 儲存進階格式設定表
        $sql = "insert into `data_extend_format` (Project,Measure_Workno,Code,Code_Desc) values ('".strtoupper($project)."','".$device."',".($i+13).",'".$extend_formats[$i][0]."')";
        //$cch .= $sql."<br>";
        $mydb->execute($sql);
        
        $create_sql .= ",`Code".($i+13)."` DECIMAL(7,3) default 0.000";
    }
    
    //將最後一個檢測工站所Create SQL，進行執行動作
    $mydb->execute($create_sql.")");
    //建立日期的Index
    $mydb->query("ALTER TABLE `".$project."_".$device."_data` ADD INDEX `date_index`( `Code1`);");
    
    //建立data_new表
    $mydb->execute(str_replace("_data","_data_new",$create_sql).")");
    //建立日期的Index
    $mydb->query("ALTER TABLE `".$project."_".$device."_data_new` ADD INDEX `date_index`( `Code1`);");
    
    //insert data_new表的觸發器
    $trigger = "CREATE TRIGGER `".$project."_".$device."_data_trigger` "
            ."AFTER INSERT ON `".$project."_".$device."_data` "
            ."FOR EACH ROW "
            ."BEGIN "
            ."    INSERT INTO `".$project."_".$device."_data_new` "
            ."    SELECT * "
            ."            FROM `".$project."_".$device."_data` "
            ."            WHERE ID = new.ID; "
            ."END ;";
    $mydb->execute($trigger);
        
    //建立event表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_event` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`Line` VARCHAR(2) NOT NULL,"
                ."`Device_Name` VARCHAR(20) NOT NULL,"
                ."`Category` INT(3) UNSIGNED NOT NULL,"
                ."`Start_Time` DATETIME,"
                ."`End_Time` DATETIME,"
                ."`Message` VARCHAR(30))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    //建立Start_Time及End_Time的Index
    $mydb->query("ALTER TABLE `".$project."_event` ADD INDEX `start_index`( `Start_Time`), ADD INDEX `end_index`( `End_Time`);");
        //建立event_new表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_event_new` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`Line` VARCHAR(2) NOT NULL,"
                ."`Device_Name` VARCHAR(20) NOT NULL,"
                ."`Category` INT(3) UNSIGNED NOT NULL,"
                ."`Start_Time` DATETIME,"
                ."`End_Time` DATETIME,"
                ."`Message` VARCHAR(30))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    //建立Start_Time及End_Time的Index
    $mydb->query("ALTER TABLE `".$project."_event_new` ADD INDEX `start_index`( `Start_Time`), ADD INDEX `end_index`( `End_Time`);");
     //insert event_new表的觸發器 
     $trigger="DROP TRIGGER IF EXISTS `".$project."_event_trigger`"; 
     $mydb->execute($trigger);                
        $trigger = "CREATE TRIGGER `".$project."_event_trigger` "
                ."AFTER INSERT ON `".$project."_event` "
                ."FOR EACH ROW "
                ."BEGIN "
                ."    INSERT INTO `".$project."_event_new` "
                ."    SELECT * "
                ."            FROM `".$project."_event` "
                ."            WHERE ID = new.ID; "
                ."END ;";
        $mydb->execute($trigger);
        //update event_new表的觸發器
        $trigger="create trigger `"
        .$project."_event_update_trigger` after update on `"
        .$project."_event` for each row   
        begin 
        if new.End_Time!=old.End_Time  or (old.End_Time is null)
            then   
        update `"
        .$project."_event_new` set `"
        .$project."_event_new`.`End_Time`=new.`End_Time` where `"
        .$project."_event_new`.`ID`=new.`ID`; 
        end if;
        end ;";
        //$objResponse->alert($trigger);
        $mydb->execute($trigger);
    //建立File Record表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_file_record` ("
                ."`ID` INT(11) UNSIGNED PRIMARY KEY AUTO_INCREMENT,"
                ."`File_Path` VARCHAR(60) NOT NULL,"
                ."`File_Name` VARCHAR(20) NOT NULL,"
                ."`Reading_Time` DATETIME,"
                ."`Reading_Success` TINYINT(1) NOT NULL,"
                ."CONSTRAINT `File_Path` UNIQUE (File_Path, File_Name))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    
    //建立Data預存表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_statistics` ("
                ."`format` TINYINT(2) UNSIGNED NOT NULL,"
                ."`work_date` DATE NOT NULL,"
                ."`line` TINYINT(2) UNSIGNED NOT NULL,"
                ."`device_name` VARCHAR(15) NOT NULL,"
                ."`shift` CHAR(1) NOT NULL,"
                ."`parameter1` VARCHAR(45) NOT NULL,"
                ."`parameter2` VARCHAR(45) NOT NULL,"
                ."`qty` INT(8) UNSIGNED NOT NULL,"
                ."CONSTRAINT `KEY` PRIMARY KEY (format,work_date,line,device_name,measure_workno,shift,parameter1,parameter2))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    
    //建立Event預存表
    $create_sql = "CREATE TABLE IF NOT EXISTS `".$project."_statistics_event` ("
                ."`format` TINYINT(2) UNSIGNED NOT NULL,"
                ."`work_date` DATE NOT NULL,"
                ."`line` TINYINT(2) UNSIGNED NOT NULL,"
                ."`device_name` VARCHAR(15) NOT NULL,"
                ."`category` VARCHAR(25) NOT NULL,"
                ."`shift` CHAR(1) NOT NULL,"
                ."`parameter1` VARCHAR(45) NOT NULL,"
                ."`parameter2` VARCHAR(45) NOT NULL,"
                ."`qty` INT(8) UNSIGNED NOT NULL,"
                ."CONSTRAINT `KEY` PRIMARY KEY (format,work_date,line,device_name,category,shift,parameter1,parameter2))";
    //$cch .= $create_sql."<br>";
    $mydb->execute($create_sql);
    $mydb->disconnect();
    
    /*
    if($mode==1)
    {
        $subject = "=?UTF-8?B?".base64_encode("HMI檔案傳輸格式-新專案：".$project)."?=";
        mail("denil_chuang@cn.foxlink.com.tw",$subject,"=?UTF-8?B?請製作讀檔程式!?=");
    }
    */
    $objResponse->alert("檔案傳輸格式修改成功!!");
    return $objResponse;
}

function pattern_match($data)
{
    $pattern = "/^[A-Za-z]+$/";
    if(preg_match($pattern,$data))
        return true;
    else
        return false; 
}
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>HMI檔案傳輸格式設定</title>
    <link href="includes/class.css"  rel="stylesheet" type="text/css" />
<?
$xajax->printJavascript(); //輸出用戶
?>
<script> 
function check()
{
    if(document.getElementById("project").value.trim()=="")
    {
        alert("請填寫專案名稱!!");
        return false;
    }
    
    var sel_device = document.getElementById("device_name");
    if(sel_device.options[sel_device.selectedIndex].value=="")
    {
        alert("請選擇設備名稱!!");
        return false;
    }
    return true;
}

function check1()
{
    var table = document.getElementById("basic_table");
    var row_num = table.rows.length - 1; //扣除標題列
    
    var table1 = document.getElementById("extend_table");
    var row_num1 = table1.rows.length - 1; //扣除標題列
       
    for(var i=1; i<=row_num1; i++)
    {
        /*
        var code = table1.rows[i].cells[0].firstChild.value.trim();
        if(code=="")
        {
            alert("請填寫進階格式設定表的代碼!!");
            return false;
        }
        */
        
        if(table1.rows[i].cells[1].firstChild.value.trim()=="")
        {
            alert("請填寫進階格式設定表的名稱!!");
            return false;
        }
        /*
        if(!/^\+?[1-9][0-9]*$/.test(code))
        {
            alert("進階格式設定表的代碼請輸入正整數");
            return;
        }
        
        if(parseInt(code)<=row_num)
        {
            alert("進階格式設定表的代碼必須大於數字"+row_num+"!!");
            return false;
        }
        */
    }
    
    return true;
}

function get_project()
{
    return document.getElementById("project").value.trim();
}

function get_device()
{
    var sel_device = document.getElementById("device_name");
    return sel_device.options[sel_device.selectedIndex].value;
}

function insert_row1(basic_num)
{
    var table = document.getElementById("extend_table");
    var row_num = table.rows.length - 1; //扣除標題列
    var row = table.insertRow();

    // input text cell
    var td_code = row.insertCell();
    td_code.textContent = basic_num + row_num + 1;
    
    // input text cell
    var td_title = row.insertCell();
    var element2 = document.createElement("input");             
    element2.type = "text";
    element2.size = "20";               
    td_title.appendChild(element2);
}

function delete_last1()
{
    var table = document.getElementById("extend_table");
    if (table.rows.length > 1) 
        table.deleteRow(table.rows.length - 1);
}

function basicTable_content1()
{
    var table = document.getElementById("basic_table");
    var row_num = table.rows.length;
    var formats = new Array(row_num-1); //扣除標題列
    
    for(var i=0; i< (row_num-1); i++)
    {
        formats[i] = new Array(1);
        formats[i][0] = table.rows[i+1].cells[1].firstChild.value;
    }
    return formats;
}

function extendTable_content1()
{
    var table = document.getElementById("extend_table");
    var row_num = table.rows.length;
    var formats = new Array(row_num-1); //扣除標題列
    
    for(var i=0; i< (row_num-1); i++)
    {
        formats[i] = new Array(1);
        formats[i][0] = table.rows[i+1].cells[1].firstChild.value;
    }
    return formats;
}

function checkSure(mode, project, device, $factory)
{
    if(check1())
    {
        if(confirm("重要! 確定要進行變更?"))
            xajax_save(mode,project,device,extendTable_content1(),$factory);
    }
}

function showContent(project)
{
    if(check1())
    {
        xajax_showFileContent(project,basicTable_content1(),extendTable_content1());
    }
}

function start_loading()
{
    document.getElementById("preloader").style.display = "block";
    document.getElementById("result_span").style.display = "none";
}
</script>

<style type="text/css">
#format_border td{padding-left: 15px; padding-right: 15px;}

#down_btn
{
    background: url('./img/Double Down.png') no-repeat;
    cursor:pointer;
    vertical-align:middle;
}

#up_btn
{
    background: url('./img/Double Up.png') no-repeat;
    cursor:pointer;
    vertical-align:middle;
}
</style>
</head>
<body>
<H1>HMI檔案傳輸格式設定</H1><font color='red'>(僅限新專案新增修改使用)</font>
<form>
<img src="img/glo_button.gif" width=15 height=14>請輸入專案名稱:<input id="project" size="10" onkeypress="onKeyPress(event.keyCode);" value="<?=$project?>" />&nbsp;&nbsp;
<img src="img/glo_button.gif" width=15 height=14>請選擇設備名稱:<select id="device_name"><option></option>
<?
$mydb = new DataBase();
$mydb->connect_fq("sfc");

$sql = "Select * from  `device_name_mapping` where category='HMI'";
$mydb->query($sql);

$counter =0;
$dev_CName = array();
$dev_EName = array();
 
while($row = $mydb->result->fetch_row())
{
    $dev_CName[$counter] = $row[1];
    $dev_EName[$counter] = $row[2];
    $counter++;
}
$mydb->result->free_result();
$mydb->disconnect();
 
for($cnt=0;$cnt<count($dev_CName);$cnt++)
{
    if(pattern_match($dev_CName[$cnt]))
    {    
        $temp_CN_device1 = $dev_CName[$cnt]."_1";
        $temp_CN_device2 = $dev_CName[$cnt]."_2";
    }
    else
    {
        $temp_CN_device1 = $dev_CName[$cnt]."1";
        $temp_CN_device2 = $dev_CName[$cnt]."2";
    }
    
    if(strcmp($dev_EName[$cnt]."_1",$device)==0)    
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\" selected>".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\" >".$temp_CN_device2."</option>";
    }
    else if(strcmp($dev_EName[$cnt]."_2",$device)==0)    
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\" >".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\" selected>".$temp_CN_device2."</option>";
    }
    else
    {    
        echo "<option value=\"".$dev_EName[$cnt]."_1"."\">".$temp_CN_device1."</option>";
        echo "<option value=\"".$dev_EName[$cnt]."_2"."\">".$temp_CN_device2."</option>";
    }
}
?>
</select>
<input id="makeSure" type="button" class="groovybutton" value="確定" onclick="start_loading();xajax_getFormat(check(),get_project(),get_device());">
<HR>
<center><div id="preloader" style="display:none;"><img src="./img/loading.gif" width="60px" height="60px" /></div></center>
<span id="result_span">
    <table id="format_border" border=1 style="display: none;">
    <tr><td valign="top"><span id="basic_span"></span></td>
    <td valign="top"><span id="extend_span"></span></td></tr>
    </table>
    <br />
    <!--<span id="demo_span"></span>-->
    <span id="save_span"></span>
</span>
</form>
</body>
</html>