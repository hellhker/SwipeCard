<?php
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="./includes/tabs.css" rel="stylesheet" type="text/css" />
    <script language="JavaScript" type="text/javascript">
    </script>
</head>
<body>
<ol id="sub_tab" style="margin-top: 0px;">
    <li id="Report"><a target="context" href="user_WeChat11.php" ><span>個人通知</span></a></li>
    <li id="WeChat"><a target="context" href="user_WeChat_test.php" ><span>群聊通知</span></a></li>

</ol>
</body>
</html>
