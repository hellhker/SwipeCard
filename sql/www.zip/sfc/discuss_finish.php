<?php							  //以SESSION抓取上傳檔案者姓名;



				$email="denil_chuang@foxlink.com.tw,kochun_chen@foxlink.com.tw";
                $header = "Content-Type: text/html; ". "charset=UTF-8; format=flowed\n". "MIME-Version: 1.0\n". "Content-Transfer-Encoding: 8bit\n";
                $header = $header."To:denil_chuang@foxlink.com.tw,kochun_chen@foxlink.com.tw\r\n";
				$header = $header."From:denil_chuang@foxlink.com.tw\r\n";
                $header = iconv("UTF-8", "big5", $header);
				$subject='上傳檔案新增討論';
                $body = "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head><body><p>測試郵件</p></body></html>";
				$subject_Issue = "=?UTF-8?B?".base64_encode($Subject)."?=";
				mail($email,$subject_Issue,$body,$header);
?>