<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<form method="post" onsubmit="return confirm('確定要刪除?');">
請輸入使用者E-Mail開頭字串<font color='red'>(多組請用分號分隔)</font>  <input type="text" name="users" size="50" /><br />
<input type="submit" value="刪除" /><br /><br />
<?php
$users_str = trim($_POST["users"]);
if(strlen($users_str)>0)
{
    $mysqli = new mysqli("192.168.64.233","root","foxlink","sfc");
    $user_array = explode(";",$users_str);
    for($i=0;$i<count($user_array);$i++)
    {
        if($user_array[$i]!="")
        {
            $sql = "Delete from `user_data` where `EMail` like '".$user_array[$i]."%'";
            $mysqli->query($sql);
        }
    }
    $mysqli->close();
	echo "<CENTER>刪除完畢!</CENTER>";
}
?>
</form>
</body>
</html>