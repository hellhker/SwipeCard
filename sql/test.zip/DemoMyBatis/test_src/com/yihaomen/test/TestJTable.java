package com.yihaomen.test;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TestJTable {
	public JTable getTable() {
		DefaultTableModel dm = new DefaultTableModel();
		String isSel = "狀態";
		CheckBoxTableModelProxy cmodProxy  =  new CheckBoxTableModelProxy(dm, isSel);
		
		return null;
		
	}
}
