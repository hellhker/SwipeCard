package com.yihaomen.test;

import java.awt.Dimension;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

public class Table {

	JTable table = new JTable();

	public Table() {
		JFrame frame = new JFrame("sjh");
		frame.setLayout(null);

		table = this.gettable();
		JScrollPane src = new JScrollPane(table);
		src.setBounds(0, 0, 400, 200);
		frame.setSize(new Dimension(400, 200));
		frame.add(src);
		frame.setVisible(true);
	}

	public JTable gettable() {
		DefaultTableModel dm = new DefaultTableModel();
		dm.setDataVector(new Object[][] {
				{ new JCheckBox(), "111", "111", "111" },
				{ new JCheckBox(), "333", "333", "333" }, }, new Object[] { "",
				"选择", "结果物", "说明" });

		JTable table = new JTable(dm) {
			public void tableChanged(TableModelEvent e) {
				super.tableChanged(e);
				repaint();
			}
		};
		table.getColumn("").setCellEditor(
				new CheckButtonEditor(new JCheckBox()));
		table.getColumn("").setCellRenderer(new CheckBoxRenderer());
		return table;
	}

	public static void main(String args[]) {
		new Table();
	}

}